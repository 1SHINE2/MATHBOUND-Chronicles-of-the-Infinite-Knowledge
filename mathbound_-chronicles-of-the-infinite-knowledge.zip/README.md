# MATHBOUND: Chronicles of the Infinite Knowledge
*Foundational Prototype Vertical Slice — Version 1.0 (October 2026)*

> *"When learning becomes an adventure, even the most challenging numbers can lead to extraordinary discoveries."*  
> — Prepared for **INFINITE Club**

---

## 1. Overview

**MATHBOUND: Chronicles of the Infinite Knowledge** is a 2D educational fantasy RPG combining top-down exploration (classic Pokémon GBA-era inspiration) with responsive, telegraphed action combat (Soul Knight inspiration).

The core game philosophy is to **make mathematics part of the world's natural laws**:
- **Notice & Reason:** Ancient architecture and magical phenomena follow discoverable mathematical patterns.
- **Concrete–Representational–Abstract (CRA) Framework:** Players manipulate physical stone runes, analyze visual progression diagrams, and deduce generalized algebraic rules.
- **The Historian's Archive:** Every discovery across 5 primary categories (*People, Places, Documents, Objects, Words*) is recorded permanently for ongoing reference.

---

## 2. Controls & Hotkeys

| Action | Desktop Binding | Mobile / Touch | Description |
| :--- | :--- | :--- | :--- |
| **Move** | `W`, `A`, `S`, `D` or Arrow Keys | On-screen navigation | 8-way directional movement with collision against walls & water |
| **Interact / Confirm** | `E` or `Enter` | `[E] Interact` Button | Speak with NPCs, inspect runic obelisks, and open gates |
| **Arcane Pulse (Attack)** | `J` or Left Mouse Click | `Pulse` Button | Directional melee/energy strike with knockback and impact sparks |
| **Resonant Burst (Ability)** | `K` or Right Mouse Click | `Wave` Button | 360° harmonic wave that stuns enemies and forces vulnerability |
| **Vector Step (Dodge)** | `Shift` or `Space` | `Step` Button | Quick dash with invulnerability frames |
| **Historian's Archive** | `Tab` | Top HUD Icon | Opens the 5-category archival database with search & sorting |
| **Satchel (Inventory)** | `I` | Top HUD Icon | Inspect relics, tools, and consume Elixirs of Clarity (+45 HP) |
| **Quest Journal** | `Q` | Top HUD Icon | Track step-by-step progress and rewards for *The Silent Gate* |
| **Pause / Resume** | `Escape` | Top HUD Icon | Pause world simulation, manual save, or adjust settings |

---

## 3. Walkthrough of the Vertical Slice

1. **Arrival at the Outpost:** Begin in the cobblestone courtyard of the Magical Academy Outpost.
2. **Consult Caretaker Oron:** Speak with Caretaker Oron near the academy entrance. Learn that a mathematical tremor locked the Great Patterned Gate to the north.
3. **Inspect the Ancient Obelisk:** Head west to examine the stone inscription to unlock notes on the *Axiom of Growth* in your Historian's Archive.
4. **Solve The Patterned Gate:** Approach the northern gate and press `[E]`. Identify the doubling sequence ($4 \to 8 \to 16 \to 32 \to [64]$), examine the $\times 2$ multiplier bridge, utilize the 3-step graduated hint ladder if needed, and place the **Harmonic Core (64)** to unlock the gate!
5. **Duel the Pattern Wisps:** In the eastern grove, observe the wisps' rhythmic telegraphs, dodge their projectile volleys, and counterattack during their exhausted **Recovery Window**.
6. **Beste the Sequence Warden:** Enter the inner Sequence Sanctum. Evade the Warden's cross-beam and radial cadence attacks, strike its core while exhausted, and claim the **Warden's Resonance Sigil**.
7. **Report to Caretaker Oron:** Return to the courtyard with the Sigil to complete the quest and trigger the region completion celebration!

---

## 4. Software Architecture

- `src/types/game.ts`: Strict TypeScript models for entities, combat hitboxes, quests, CRA puzzles, the Archive, inventory, and save data.
- `src/audio/soundManager.ts`: Zero-dependency, lightweight browser Web Audio API synthesizer for 16-bit retro audio, chimes, attacks, and ambient arpeggios.
- `src/game/sprites.ts`: Procedural pixel-art rendering engine drawing the player, Caretaker Oron, Pattern Wisps, the Sequence Warden, trees, gate portcullis, and cobblestone tiles.
- `src/game/GameCanvas.tsx`: 60 FPS requestAnimationFrame canvas loop featuring camera follow, wall collision, hit detection, telegraphed hazard zones, and particle effects.
- `src/game/puzzles/patternGate.ts`: Pure mathematical sequence logic with deterministic validation and graduated hint ladder.
- `src/game/archiveData.ts`: Comprehensive canonical dataset for all 5 Historian's Archive categories with mathematical models and 3-question document investigations.
- `src/components/`: Modular React components for HUD, Title Screen, Dialogue, Puzzle modal, Archive, Inventory satchel, Quest log, Settings, and Victory screen.
- `src/App.tsx`: Central state machine with automatic milestone checkpointing to browser `localStorage`.

---

## 5. Feature Checklist

### Fully Implemented
- [x] Retro Handheld Title Screen with animated canvas backdrop, Continue, New Game confirmation, and Credits.
- [x] 8-way player movement with smooth camera follow, wall collision, and contextual proximity prompts.
- [x] Complete Introductory Region: The Magical Academy Outpost (courtyard, trees, pond, obelisk, gate, sanctum).
- [x] Full quest state loop: *The Silent Gate* (Available $\to$ Talk $\to$ Inspect $\to$ Solve $\to$ Wisps $\to$ Warden $\to$ Complete).
- [x] Caretaker Oron NPC with multi-stage dialogue, character portrait, and typewriter chirp audio.
- [x] Interactive mathematical puzzle (*The Patterned Gate*) adhering to the Concrete-Representational-Abstract (CRA) model with 3-tier graduated hint ladder.
- [x] Real-time tactical combat with player health, energy, Arcane Pulse attack, Resonant Burst ability, and Vector Step dodge.
- [x] Pattern Wisp basic enemy with telegraphed danger areas and vulnerable recovery windows.
- [x] The Sequence Warden elite encounter with cadence attacks and unique boss behaviors.
- [x] Historian's Archive with all 5 primary categories (*People, Places, Documents, Objects, Words*), search, sorting, and 3-question document inquiry (*Is it real? / What does it mean? / What can it tell us?*).
- [x] Inventory Satchel with item inspection and working Elixir of Clarity consumption (+45 HP).
- [x] Settings menu with SFX/Music volume sliders, screen shake toggle, relaxed learning mode, and high contrast.
- [x] Save & Resume system persisting all progress, quest stages, and archive entries to `localStorage`.
- [x] Region completion victory modal with performance metrics and Chapter 2 preview.

### Planned for Future Expansion (Out of Scope for Vertical Slice)
- [ ] Chapter 2: The Solarpunk Metropolis with algebraic measurement systems.
- [ ] Additional weapon tools (Scholar's Compass, Geometric Prism).
- [ ] Additional enemy archetypes (Mirror Sentinel, Measure Mite, Glyph Keeper).
