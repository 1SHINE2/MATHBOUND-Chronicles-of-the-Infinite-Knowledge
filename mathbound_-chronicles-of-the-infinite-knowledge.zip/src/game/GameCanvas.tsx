import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  Direction, 
  EnemyEntity, 
  FloatingText, 
  GameScreenState, 
  GameSettings, 
  InteractableEntity, 
  Particle, 
  PlayerStats, 
  Projectile, 
  Quest, 
  Vector2 
} from '../types/game';
import { soundManager } from '../audio/soundManager';
import { 
  drawCaretaker, 
  drawGate, 
  drawGroundTile, 
  drawObelisk, 
  drawPlayer, 
  drawPatternWisp, 
  drawSequenceWarden, 
  drawTree, 
  PALETTE 
} from './sprites';

interface GameCanvasProps {
  onOpenDialogue: (npcId: string) => void;
  onOpenPuzzle: () => void;
  onOpenObelisk: (obeliskId: string) => void;
  onPrototypeComplete: () => void;
  quest: Quest;
  gateOpened: boolean;
  settings: GameSettings;
  screenState: GameScreenState;
  onUpdateQuestStage: (stage: import('../types/game').QuestStage) => void;
  onEnemyDefeated: (enemyType: string) => void;
  onPlayerHealthChange: (hp: number, maxHp: number) => void;
  onPlayerEnergyChange: (energy: number, maxEnergy: number) => void;
  onInteractPromptChange: (prompt: string | null) => void;
  savedPlayerPos?: { x: number; y: number };
}

// World Map Dimensions
const MAP_COLS = 36;
const MAP_ROWS = 28;
const TILE_SIZE = 32;
const WORLD_WIDTH = MAP_COLS * TILE_SIZE;  // 1152px
const WORLD_HEIGHT = MAP_ROWS * TILE_SIZE; // 896px

// Viewport Virtual Dimensions
const VIEW_WIDTH = 800;
const VIEW_HEIGHT = 600;

export const GameCanvas: React.FC<GameCanvasProps> = ({
  onOpenDialogue,
  onOpenPuzzle,
  onOpenObelisk,
  onPrototypeComplete,
  quest,
  gateOpened,
  settings,
  screenState,
  onUpdateQuestStage,
  onEnemyDefeated,
  onPlayerHealthChange,
  onPlayerEnergyChange,
  onInteractPromptChange,
  savedPlayerPos
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Player State
  const playerRef = useRef({
    x: savedPlayerPos ? savedPlayerPos.x : 280,
    y: savedPlayerPos ? savedPlayerPos.y : 580,
    width: 28,
    height: 30,
    facing: 'down' as Direction,
    walkFrame: 0,
    walkTimer: 0,
    isMoving: false,
    isAttacking: false,
    attackTimer: 0,
    isDodging: false,
    dodgeTimer: 0,
    invulnTimer: 0,
    hurtTimer: 0,
    stats: {
      maxHp: 100,
      hp: 100,
      maxEnergy: 100,
      energy: 100,
      attackPower: 30,
      speed: 3.2,
      isDodging: false,
      dodgeCooldown: 0,
      attackCooldown: 0
    } as PlayerStats
  });

  // Camera State
  const cameraRef = useRef<Vector2>({ x: 0, y: 0 });
  const screenShakeRef = useRef(0);

  // Keyboard Keys State
  const keysRef = useRef<{ [key: string]: boolean }>({});

  // Entities Ref
  const interactablesRef = useRef<InteractableEntity[]>([
    {
      id: 'npc_oron',
      name: 'Caretaker Oron',
      x: 320,
      y: 560,
      width: 32,
      height: 32,
      prompt: 'Press [E] to Speak with Caretaker',
      type: 'NPC'
    },
    {
      id: 'gate_pattern',
      name: 'The Patterned Gate',
      x: 480,
      y: 352,
      width: 96,
      height: 64,
      prompt: 'Press [E] to Inspect Runic Mechanism',
      type: 'PUZZLE_GATE'
    },
    {
      id: 'obelisk_clue',
      name: 'Ancient Inscription Obelisk',
      x: 160,
      y: 520,
      width: 24,
      height: 32,
      prompt: 'Press [E] to Read Inscribed Theorem',
      type: 'LORE_OBELISK'
    },
    {
      id: 'sanctum_exit',
      name: 'Archway to Grand Archive',
      x: 520,
      y: 40,
      width: 48,
      height: 32,
      prompt: 'Press [E] to Enter Grand Archive',
      type: 'SANCTUM_EXIT'
    }
  ]);

  // Enemies Ref
  const enemiesRef = useRef<EnemyEntity[]>([
    // Pattern Wisps in East Courtyard
    {
      id: 'wisp_1',
      type: 'PATTERN_WISP',
      name: 'Pattern Wisp α',
      x: 750,
      y: 560,
      width: 32,
      height: 32,
      hp: 60,
      maxHp: 60,
      facing: 'left',
      state: 'IDLE',
      stateTimer: 0,
      attackPatternIndex: 0,
      patrolPoints: [
        { x: 750, y: 560 },
        { x: 880, y: 560 },
        { x: 820, y: 680 }
      ],
      currentPatrolIdx: 0,
      hitFlashTimer: 0,
      speed: 1.5,
      isVulnerable: false
    },
    {
      id: 'wisp_2',
      type: 'PATTERN_WISP',
      name: 'Pattern Wisp β',
      x: 880,
      y: 680,
      width: 32,
      height: 32,
      hp: 60,
      maxHp: 60,
      facing: 'up',
      state: 'IDLE',
      stateTimer: 0.6,
      attackPatternIndex: 1,
      patrolPoints: [
        { x: 880, y: 680 },
        { x: 750, y: 680 },
        { x: 810, y: 540 }
      ],
      currentPatrolIdx: 0,
      hitFlashTimer: 0,
      speed: 1.5,
      isVulnerable: false
    },
    // The Sequence Warden in North Sanctum
    {
      id: 'sequence_warden',
      type: 'SEQUENCE_WARDEN',
      name: 'The Sequence Warden',
      x: 500,
      y: 140,
      width: 48,
      height: 48,
      hp: 240,
      maxHp: 240,
      facing: 'down',
      state: 'IDLE',
      stateTimer: 0,
      attackPatternIndex: 0,
      patrolPoints: [
        { x: 500, y: 140 },
        { x: 380, y: 140 },
        { x: 640, y: 140 }
      ],
      currentPatrolIdx: 0,
      hitFlashTimer: 0,
      speed: 1.0,
      isVulnerable: false
    }
  ]);

  // Projectiles & FX
  const projectilesRef = useRef<Projectile[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const lastFootstepTime = useRef<number>(0);
  const activePromptRef = useRef<string | null>(null);

  // Walls & Collision Map definition (0: grass/open, 1: solid wall, 2: path, 3: water, 4: sanctum tile)
  const mapGrid = useRef<number[][]>([]);

  // Initialize Map Grid with Outpost Architecture
  useEffect(() => {
    const grid: number[][] = [];
    for (let r = 0; r < MAP_ROWS; r++) {
      grid[r] = [];
      for (let c = 0; c < MAP_COLS; c++) {
        // Outer boundaries are solid walls
        if (r === 0 || r === MAP_ROWS - 1 || c === 0 || c === MAP_COLS - 1) {
          grid[r][c] = 1; // Solid Wall
        } 
        // Northern Dividing Wall separating Courtyard from Sequence Sanctum (row 12)
        else if (r === 12) {
          // Gate opening at columns 15, 16, 17
          if (c >= 15 && c <= 17) {
            grid[r][c] = 2; // Gate path
          } else {
            grid[r][c] = 1; // Solid stone wall
          }
        }
        // Sequence Sanctum Floor (rows 1 to 11)
        else if (r < 12) {
          grid[r][c] = 4; // Sanctum Floor
        }
        // Main Courtyard Paths (rows 13 to 27)
        else if (
          (c >= 8 && c <= 11 && r >= 16 && r <= 22) || // South Plaza
          (c >= 15 && c <= 17 && r >= 13 && r <= 25) || // Grand Central Path leading to Gate
          (r === 19 && c >= 10 && c <= 28) // Horizontal walkway to East Grove
        ) {
          grid[r][c] = 2; // Cobblestone Path
        }
        // Small decorative pond in courtyard
        else if (c >= 4 && c <= 6 && r >= 18 && r <= 20) {
          grid[r][c] = 3; // Water
        }
        // Open lush grass
        else {
          grid[r][c] = 0; // Grass
        }
      }
    }
    mapGrid.current = grid;
  }, []);

  // Keyboard Event Handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture inputs if a modal is active
      if (screenState !== 'PLAYING') return;

      keysRef.current[e.key.toLowerCase()] = true;

      // Interaction Action (E or Enter)
      if (e.key.toLowerCase() === 'e' || e.key === 'Enter') {
        e.preventDefault();
        checkInteraction();
      }

      // Attack Action (J or Space if not used for dodge)
      if (e.key.toLowerCase() === 'j') {
        e.preventDefault();
        triggerPlayerAttack();
      }

      // Ability Action (K)
      if (e.key.toLowerCase() === 'k') {
        e.preventDefault();
        triggerPlayerAbility();
      }

      // Dodge Action (Shift or Space)
      if (e.key === ' ' || e.key === 'Shift') {
        e.preventDefault();
        triggerPlayerDodge();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [screenState, gateOpened, quest]);

  // Player Actions
  const triggerPlayerAttack = () => {
    const player = playerRef.current;
    if (player.attackTimer > 0 || player.isDodging) return;

    player.isAttacking = true;
    player.attackTimer = 0.28; // ~280ms attack swing
    soundManager.playAttack();

    // Spawn crescent energy hitbox
    let hitX = player.x;
    let hitY = player.y;
    const reach = 36;

    if (player.facing === 'down') hitY += reach;
    if (player.facing === 'up') hitY -= reach;
    if (player.facing === 'right') hitX += reach;
    if (player.facing === 'left') hitX -= reach;

    // Check hit against active enemies
    enemiesRef.current.forEach(enemy => {
      if (enemy.state === 'DEAD') return;
      const dist = Math.hypot(enemy.x + enemy.width / 2 - (hitX + 14), enemy.y + enemy.height / 2 - (hitY + 15));
      if (dist < 42) {
        // Successful Hit!
        const isBonus = enemy.isVulnerable;
        const damage = isBonus ? player.stats.attackPower * 2 : player.stats.attackPower;
        enemy.hp = Math.max(0, enemy.hp - damage);
        enemy.hitFlashTimer = 0.2;
        soundManager.playHit();

        // Screen shake
        screenShakeRef.current = 6;

        // Spawn hit particles
        for (let i = 0; i < 8; i++) {
          particlesRef.current.push({
            x: enemy.x + enemy.width / 2,
            y: enemy.y + enemy.height / 2,
            vx: (Math.random() - 0.5) * 120,
            vy: (Math.random() - 0.5) * 120,
            color: isBonus ? '#FBBF24' : '#38BDF8',
            size: 3 + Math.random() * 2,
            life: 0.35,
            maxLife: 0.35,
            alpha: 1
          });
        }

        // Damage Text
        floatingTextsRef.current.push({
          id: `dmg_${Date.now()}_${Math.random()}`,
          x: enemy.x + enemy.width / 2,
          y: enemy.y - 8,
          text: isBonus ? `CRIT -${damage}!` : `-${damage}`,
          color: isBonus ? '#FBBF24' : '#FFFFFF',
          life: 0.7,
          maxLife: 0.7
        });

        // Check if Enemy Defeated
        if (enemy.hp <= 0) {
          enemy.state = 'DEAD';
          soundManager.playEnemyDefeat();
          onEnemyDefeated(enemy.type);

          floatingTextsRef.current.push({
            id: `def_${Date.now()}`,
            x: enemy.x + enemy.width / 2,
            y: enemy.y - 20,
            text: `${enemy.name} QUELLED!`,
            color: '#10B981',
            life: 1.2,
            maxLife: 1.2
          });

          // Check if all wisps defeated to advance quest
          const remainingWisps = enemiesRef.current.filter(e => e.type === 'PATTERN_WISP' && e.state !== 'DEAD');
          if (remainingWisps.length === 0 && quest.stage === 'DEFEAT_WISPS') {
            onUpdateQuestStage('DEFEAT_WARDEN');
          }

          // If Warden defeated, trigger region completion milestone!
          if (enemy.type === 'SEQUENCE_WARDEN') {
            soundManager.playVictoryFanfare();
            onUpdateQuestStage('REPORT_TO_CARETAKER');
          }
        }
      }
    });
  };

  const triggerPlayerAbility = () => {
    const player = playerRef.current;
    if (player.stats.energy < 30 || player.isDodging) {
      soundManager.playError();
      return;
    }

    // Spend Energy
    player.stats.energy -= 30;
    onPlayerEnergyChange(player.stats.energy, player.stats.maxEnergy);
    soundManager.playAbility();

    // Screen Shake & Resonant Harmonic Wave
    screenShakeRef.current = 10;

    // Expand 360 degree pulse wave
    const waveRadius = 120;
    for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
      particlesRef.current.push({
        x: player.x + 14,
        y: player.y + 15,
        vx: Math.cos(angle) * 160,
        vy: Math.sin(angle) * 160,
        color: PALETTE.magicCyan,
        size: 4,
        life: 0.45,
        maxLife: 0.45,
        alpha: 1
      });
    }

    // Damage all nearby enemies and force them into vulnerability
    enemiesRef.current.forEach(enemy => {
      if (enemy.state === 'DEAD') return;
      const dist = Math.hypot(enemy.x + enemy.width / 2 - (player.x + 14), enemy.y + enemy.height / 2 - (player.y + 15));
      if (dist < waveRadius) {
        enemy.hp = Math.max(0, enemy.hp - 45);
        enemy.hitFlashTimer = 0.3;
        enemy.isVulnerable = true;
        enemy.state = 'RECOVERY';
        enemy.stateTimer = 2.0; // Stunned for 2s

        floatingTextsRef.current.push({
          id: `res_${Date.now()}_${Math.random()}`,
          x: enemy.x + enemy.width / 2,
          y: enemy.y - 12,
          text: 'RESONANCE! -45',
          color: '#38BDF8',
          life: 0.8,
          maxLife: 0.8
        });

        if (enemy.hp <= 0) {
          enemy.state = 'DEAD';
          soundManager.playEnemyDefeat();
          onEnemyDefeated(enemy.type);
        }
      }
    });
  };

  const triggerPlayerDodge = () => {
    const player = playerRef.current;
    if (player.isDodging || player.dodgeTimer > 0) return;

    player.isDodging = true;
    player.dodgeTimer = 0.35; // 350ms quick vector step
    player.invulnTimer = 0.38;

    // Small dash speed
    const dashDist = 28;
    if (player.facing === 'down') player.y = Math.min(WORLD_HEIGHT - 40, player.y + dashDist);
    if (player.facing === 'up') player.y = Math.max(40, player.y - dashDist);
    if (player.facing === 'left') player.x = Math.max(40, player.x - dashDist);
    if (player.facing === 'right') player.x = Math.min(WORLD_WIDTH - 40, player.x + dashDist);

    // Dust particles
    for (let i = 0; i < 5; i++) {
      particlesRef.current.push({
        x: player.x + 14,
        y: player.y + 24,
        vx: (Math.random() - 0.5) * 40,
        vy: (Math.random() - 0.5) * 40,
        color: '#E2E8F0',
        size: 3,
        life: 0.25,
        maxLife: 0.25,
        alpha: 0.8
      });
    }
  };

  // Interaction check against nearest entity
  const checkInteraction = () => {
    const player = playerRef.current;
    const px = player.x + player.width / 2;
    const py = player.y + player.height / 2;

    for (const ent of interactablesRef.current) {
      const ex = ent.x + ent.width / 2;
      const ey = ent.y + ent.height / 2;
      const dist = Math.hypot(ex - px, ey - py);

      if (dist < 64) {
        if (ent.type === 'NPC') {
          soundManager.playDialogueChirp();
          onOpenDialogue(ent.id);
          return;
        } else if (ent.type === 'PUZZLE_GATE') {
          if (gateOpened) {
            floatingTextsRef.current.push({
              id: `gate_${Date.now()}`,
              x: ent.x + ent.width / 2,
              y: ent.y - 10,
              text: 'The Gate is Unlocked & Resonating',
              color: '#38BDF8',
              life: 1.0,
              maxLife: 1.0
            });
          } else {
            soundManager.playTileSnap();
            onOpenPuzzle();
          }
          return;
        } else if (ent.type === 'LORE_OBELISK') {
          soundManager.playArchiveUnlock();
          onOpenObelisk(ent.id);
          return;
        } else if (ent.type === 'SANCTUM_EXIT') {
          const warden = enemiesRef.current.find(e => e.type === 'SEQUENCE_WARDEN');
          if (warden && warden.state !== 'DEAD') {
            floatingTextsRef.current.push({
              id: `exit_${Date.now()}`,
              x: ent.x + ent.width / 2,
              y: ent.y - 10,
              text: 'Barred by the Sequence Warden\'s trial!',
              color: '#EF4444',
              life: 1.2,
              maxLife: 1.2
            });
            soundManager.playError();
          } else {
            // Reached prototype ending!
            onPrototypeComplete();
          }
          return;
        }
      }
    }
  };

  // Main Game Loop (60 FPS requestAnimationFrame)
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;

      if (screenState === 'PLAYING') {
        updateGame(dt, currentTime);
      }
      renderGame(currentTime);

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [screenState, gateOpened, settings]);

  // Update Game Physics & AI
  const updateGame = (dt: number, currentTime: number) => {
    const player = playerRef.current;

    // Regenerate small amount of energy
    if (player.stats.energy < player.stats.maxEnergy) {
      player.stats.energy = Math.min(player.stats.maxEnergy, player.stats.energy + dt * 8);
      onPlayerEnergyChange(player.stats.energy, player.stats.maxEnergy);
    }

    // Cooldown timers
    if (player.attackTimer > 0) {
      player.attackTimer -= dt;
      if (player.attackTimer <= 0) player.isAttacking = false;
    }
    if (player.dodgeTimer > 0) {
      player.dodgeTimer -= dt;
      if (player.dodgeTimer <= 0) player.isDodging = false;
    }
    if (player.invulnTimer > 0) player.invulnTimer -= dt;
    if (player.hurtTimer > 0) player.hurtTimer -= dt;

    // Movement calculation
    let dx = 0;
    let dy = 0;

    if (!player.isAttacking && !player.isDodging) {
      const keys = keysRef.current;
      if (keys['w'] || keys['arrowup']) {
        dy -= 1;
        player.facing = 'up';
      }
      if (keys['s'] || keys['arrowdown']) {
        dy += 1;
        player.facing = 'down';
      }
      if (keys['a'] || keys['arrowleft']) {
        dx -= 1;
        player.facing = 'left';
      }
      if (keys['d'] || keys['arrowright']) {
        dx += 1;
        player.facing = 'right';
      }

      if (dx !== 0 && dy !== 0) {
        // Normalize diagonal speed
        dx *= 0.7071;
        dy *= 0.7071;
      }

      if (dx !== 0 || dy !== 0) {
        player.isMoving = true;
        player.walkTimer += dt;
        if (player.walkTimer > 0.16) {
          player.walkFrame++;
          player.walkTimer = 0;
        }

        // Footstep sound
        if (currentTime - lastFootstepTime.current > 320) {
          soundManager.playFootstep();
          lastFootstepTime.current = currentTime;
        }

        // Apply movement with solid collision checking
        const nextX = player.x + dx * player.stats.speed;
        const nextY = player.y + dy * player.stats.speed;

        if (!checkWallCollision(nextX, player.y, player.width, player.height, gateOpened)) {
          player.x = nextX;
        }
        if (!checkWallCollision(player.x, nextY, player.width, player.height, gateOpened)) {
          player.y = nextY;
        }
      } else {
        player.isMoving = false;
        player.walkFrame = 0;
      }
    }

    // Keep player in bounds
    player.x = Math.max(36, Math.min(WORLD_WIDTH - 64, player.x));
    player.y = Math.max(36, Math.min(WORLD_HEIGHT - 64, player.y));

    // Update Proximity Context Prompt
    let foundPrompt: string | null = null;
    const px = player.x + player.width / 2;
    const py = player.y + player.height / 2;

    for (const ent of interactablesRef.current) {
      const ex = ent.x + ent.width / 2;
      const ey = ent.y + ent.height / 2;
      const dist = Math.hypot(ex - px, ey - py);
      if (dist < 64) {
        foundPrompt = ent.prompt;
        break;
      }
    }

    if (foundPrompt !== activePromptRef.current) {
      activePromptRef.current = foundPrompt;
      onInteractPromptChange(foundPrompt);
    }

    // Update Enemies AI
    enemiesRef.current.forEach(enemy => {
      if (enemy.state === 'DEAD') return;

      if (enemy.hitFlashTimer > 0) enemy.hitFlashTimer -= dt;
      enemy.stateTimer -= dt;

      if (enemy.type === 'PATTERN_WISP') {
        updateWispAI(enemy, dt, player);
      } else if (enemy.type === 'SEQUENCE_WARDEN') {
        updateWardenAI(enemy, dt, player);
      }
    });

    // Update Projectiles
    for (let i = projectilesRef.current.length - 1; i >= 0; i--) {
      const p = projectilesRef.current[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;

      // Projectile vs Player
      if (!p.fromPlayer) {
        const dist = Math.hypot(p.x - (player.x + 14), p.y - (player.y + 15));
        if (dist < p.radius + 12 && player.invulnTimer <= 0) {
          // Player Hit!
          const defenseMul = settings.relaxedMode ? 0.6 : 1.0;
          const damage = Math.round(p.damage * defenseMul);
          player.stats.hp = Math.max(0, player.stats.hp - damage);
          player.invulnTimer = 0.8;
          player.hurtTimer = 0.25;
          screenShakeRef.current = 10;
          soundManager.playPlayerHurt();
          onPlayerHealthChange(player.stats.hp, player.stats.maxHp);

          floatingTextsRef.current.push({
            id: `p_hurt_${Date.now()}`,
            x: player.x + 14,
            y: player.y - 10,
            text: `-${damage} HP`,
            color: '#EF4444',
            life: 0.8,
            maxLife: 0.8
          });

          projectilesRef.current.splice(i, 1);
          continue;
        }
      }

      if (p.life <= 0) {
        projectilesRef.current.splice(i, 1);
      }
    }

    // Update Particles
    for (let i = particlesRef.current.length - 1; i >= 0; i--) {
      const pt = particlesRef.current[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life -= dt;
      pt.alpha = Math.max(0, pt.life / pt.maxLife);
      if (pt.life <= 0) {
        particlesRef.current.splice(i, 1);
      }
    }

    // Update Floating Texts
    for (let i = floatingTextsRef.current.length - 1; i >= 0; i--) {
      const ft = floatingTextsRef.current[i];
      ft.y -= dt * 25; // Float upwards
      ft.life -= dt;
      if (ft.life <= 0) {
        floatingTextsRef.current.splice(i, 1);
      }
    }

    // Camera Smooth Follow
    const targetCamX = player.x + player.width / 2 - VIEW_WIDTH / 2;
    const targetCamY = player.y + player.height / 2 - VIEW_HEIGHT / 2;

    cameraRef.current.x += (targetCamX - cameraRef.current.x) * 0.1;
    cameraRef.current.y += (targetCamY - cameraRef.current.y) * 0.1;

    // Clamp Camera within World bounds
    cameraRef.current.x = Math.max(0, Math.min(WORLD_WIDTH - VIEW_WIDTH, cameraRef.current.x));
    cameraRef.current.y = Math.max(0, Math.min(WORLD_HEIGHT - VIEW_HEIGHT, cameraRef.current.y));

    // Shake dampening
    if (screenShakeRef.current > 0) {
      screenShakeRef.current = Math.max(0, screenShakeRef.current - dt * 20);
    }
  };

  // Pattern Wisp AI: Rhythmic cycle (Patrol -> Telegraph -> Pulse Attack -> Recovery Stun)
  const updateWispAI = (enemy: EnemyEntity, dt: number, player: typeof playerRef.current) => {
    if (enemy.stateTimer <= 0) {
      if (enemy.state === 'IDLE' || enemy.state === 'RECOVERY') {
        enemy.state = 'MOVING';
        enemy.isVulnerable = false;
        enemy.stateTimer = 1.8;
        // Next patrol point
        enemy.currentPatrolIdx = (enemy.currentPatrolIdx + 1) % enemy.patrolPoints.length;
      } else if (enemy.state === 'MOVING') {
        // Transition to Telegraph
        enemy.state = 'TELEGRAPH';
        soundManager.playTelegraph();
        // Give longer telegraph in relaxed mode for learning accessibility
        enemy.stateTimer = settings.relaxedMode ? 1.6 : 1.1;
        enemy.telegraphArea = {
          type: 'circle',
          x: enemy.x + 16,
          y: enemy.y + 16,
          radius: 64
        };
      } else if (enemy.state === 'TELEGRAPH') {
        // Trigger Attack!
        enemy.state = 'ATTACK';
        enemy.stateTimer = 0.3;
        soundManager.playAttack();

        // Check if player in danger circle
        const distToPlayer = Math.hypot(enemy.x + 16 - (player.x + 14), enemy.y + 16 - (player.y + 15));
        if (distToPlayer <= 64 && player.invulnTimer <= 0 && !player.isDodging) {
          const defenseMul = settings.relaxedMode ? 0.6 : 1.0;
          const dmg = Math.round(20 * defenseMul);
          player.stats.hp = Math.max(0, player.stats.hp - dmg);
          player.invulnTimer = 0.8;
          player.hurtTimer = 0.25;
          soundManager.playPlayerHurt();
          onPlayerHealthChange(player.stats.hp, player.stats.maxHp);
        }

        // Fire 3 patterned bullets in 120-degree intervals
        for (let i = 0; i < 3; i++) {
          const angle = (i * Math.PI * 2 / 3);
          projectilesRef.current.push({
            id: `wisp_proj_${Date.now()}_${i}`,
            x: enemy.x + 16,
            y: enemy.y + 16,
            vx: Math.cos(angle) * 110,
            vy: Math.sin(angle) * 110,
            radius: 5,
            damage: 15,
            fromPlayer: false,
            color: '#38BDF8',
            life: 2.0,
            maxLife: 2.0
          });
        }
      } else if (enemy.state === 'ATTACK') {
        // Transition to Vulnerable Recovery Window (Core Learning Concept!)
        enemy.state = 'RECOVERY';
        enemy.isVulnerable = true;
        enemy.stateTimer = 2.2; // Player has 2.2s window to attack!
      }
    }

    // Moving state physics
    if (enemy.state === 'MOVING') {
      const target = enemy.patrolPoints[enemy.currentPatrolIdx];
      const dx = target.x - enemy.x;
      const dy = target.y - enemy.y;
      const dist = Math.hypot(dx, dy);

      if (dist > 4) {
        enemy.x += (dx / dist) * enemy.speed;
        enemy.y += (dy / dist) * enemy.speed;
      }
    }
  };

  // Sequence Warden AI: Elite Encounter with Cadence Attacks & Safe Zones
  const updateWardenAI = (enemy: EnemyEntity, dt: number, player: typeof playerRef.current) => {
    // Only activate Warden once player enters the Sanctum
    if (player.y > 400) return;

    if (enemy.stateTimer <= 0) {
      if (enemy.state === 'IDLE' || enemy.state === 'RECOVERY') {
        enemy.state = 'MOVING';
        enemy.isVulnerable = false;
        enemy.stateTimer = 2.0;
        enemy.currentPatrolIdx = (enemy.currentPatrolIdx + 1) % enemy.patrolPoints.length;
      } else if (enemy.state === 'MOVING') {
        // Sequence Cadence Telegraph
        enemy.state = 'TELEGRAPH';
        soundManager.playTelegraph();
        enemy.stateTimer = settings.relaxedMode ? 2.0 : 1.4;
        enemy.attackPatternIndex = (enemy.attackPatternIndex + 1) % 2;

        if (enemy.attackPatternIndex === 0) {
          // Cross Beam Telegraph
          enemy.telegraphArea = {
            type: 'line',
            x: enemy.x + 24,
            y: enemy.y + 24,
            width: 400,
            height: 36
          };
        } else {
          // Expanding Harmonic Circle Telegraph
          enemy.telegraphArea = {
            type: 'circle',
            x: enemy.x + 24,
            y: enemy.y + 24,
            radius: 110
          };
        }
      } else if (enemy.state === 'TELEGRAPH') {
        // Execute Cadence Attack
        enemy.state = 'ATTACK';
        enemy.stateTimer = 0.4;
        soundManager.playAttack();

        // Screen shake
        screenShakeRef.current = 14;

        if (enemy.attackPatternIndex === 0) {
          // Horizontal beam check
          const py = player.y + 15;
          const beamY = enemy.y + 24;
          if (Math.abs(py - beamY) < 24 && Math.abs((player.x + 14) - (enemy.x + 24)) < 220) {
            if (player.invulnTimer <= 0 && !player.isDodging) {
              const dmg = settings.relaxedMode ? 18 : 28;
              player.stats.hp = Math.max(0, player.stats.hp - dmg);
              player.invulnTimer = 0.8;
              player.hurtTimer = 0.25;
              soundManager.playPlayerHurt();
              onPlayerHealthChange(player.stats.hp, player.stats.maxHp);
            }
          }
        } else {
          // Circle burst check
          const dist = Math.hypot((enemy.x + 24) - (player.x + 14), (enemy.y + 24) - (player.y + 15));
          if (dist <= 110 && player.invulnTimer <= 0 && !player.isDodging) {
            const dmg = settings.relaxedMode ? 20 : 32;
            player.stats.hp = Math.max(0, player.stats.hp - dmg);
            player.invulnTimer = 0.8;
            player.hurtTimer = 0.25;
            soundManager.playPlayerHurt();
            onPlayerHealthChange(player.stats.hp, player.stats.maxHp);
          }
        }
      } else if (enemy.state === 'ATTACK') {
        // Extended Exhaustion Recovery Window (Opportunity to attack boss!)
        enemy.state = 'RECOVERY';
        enemy.isVulnerable = true;
        enemy.stateTimer = 2.8; // 2.8s recovery window
      }
    }

    if (enemy.state === 'MOVING') {
      const target = enemy.patrolPoints[enemy.currentPatrolIdx];
      const dx = target.x - enemy.x;
      const dy = target.y - enemy.y;
      const dist = Math.hypot(dx, dy);
      if (dist > 4) {
        enemy.x += (dx / dist) * enemy.speed;
        enemy.y += (dy / dist) * enemy.speed;
      }
    }
  };

  // Wall Collision Routine
  const checkWallCollision = (x: number, y: number, w: number, h: number, isGateOpen: boolean): boolean => {
    // If gate is closed, the gate area (row 11-12, cols 15-17) is solid
    if (!isGateOpen) {
      const gateLeft = 15 * TILE_SIZE;
      const gateRight = 18 * TILE_SIZE;
      const gateTop = 11 * TILE_SIZE;
      const gateBottom = 13 * TILE_SIZE;

      if (x + w > gateLeft && x < gateRight && y + h > gateTop && y < gateBottom) {
        return true;
      }
    }

    // Check corners against map grid
    const points = [
      { x: x + 4, y: y + 8 },
      { x: x + w - 4, y: y + 8 },
      { x: x + 4, y: y + h - 2 },
      { x: x + w - 4, y: y + h - 2 }
    ];

    for (const pt of points) {
      const col = Math.floor(pt.x / TILE_SIZE);
      const row = Math.floor(pt.y / TILE_SIZE);

      if (row < 0 || row >= MAP_ROWS || col < 0 || col >= MAP_COLS) return true;

      const tileType = mapGrid.current[row]?.[col];
      // 1: Solid wall, 3: Deep Water
      if (tileType === 1 || tileType === 3) {
        return true;
      }
    }

    return false;
  };

  // Canvas Render Frame
  const renderGame = (time: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Apply crisp nearest-neighbor pixel rendering
    ctx.imageSmoothingEnabled = false;

    // Apply Screen Shake
    let shakeX = 0;
    let shakeY = 0;
    if (settings.screenShake && screenShakeRef.current > 0) {
      shakeX = (Math.random() - 0.5) * screenShakeRef.current;
      shakeY = (Math.random() - 0.5) * screenShakeRef.current;
    }

    ctx.save();
    ctx.clearRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
    ctx.translate(-Math.round(cameraRef.current.x + shakeX), -Math.round(cameraRef.current.y + shakeY));

    // 1. Draw Visible Ground Tiles
    const startCol = Math.max(0, Math.floor(cameraRef.current.x / TILE_SIZE));
    const endCol = Math.min(MAP_COLS - 1, Math.ceil((cameraRef.current.x + VIEW_WIDTH) / TILE_SIZE));
    const startRow = Math.max(0, Math.floor(cameraRef.current.y / TILE_SIZE));
    const endRow = Math.min(MAP_ROWS - 1, Math.ceil((cameraRef.current.y + VIEW_HEIGHT) / TILE_SIZE));

    for (let r = startRow; r <= endRow; r++) {
      for (let c = startCol; c <= endCol; c++) {
        const type = mapGrid.current[r]?.[c];
        const tx = c * TILE_SIZE;
        const ty = r * TILE_SIZE;

        if (type === 1) drawGroundTile(ctx, tx, ty, 'WALL');
        else if (type === 2) drawGroundTile(ctx, tx, ty, 'PATH');
        else if (type === 3) drawGroundTile(ctx, tx, ty, 'WATER');
        else if (type === 4) drawGroundTile(ctx, tx, ty, 'SANCTUM_TILE');
        else drawGroundTile(ctx, tx, ty, 'GRASS');
      }
    }

    // 2. Draw Decorative Trees in Courtyard
    const treePositions = [
      { x: 96, y: 440 },
      { x: 220, y: 640 },
      { x: 380, y: 680 },
      { x: 680, y: 460 },
      { x: 960, y: 520 },
      { x: 980, y: 680 },
      { x: 240, y: 160 },
      { x: 800, y: 160 }
    ];
    treePositions.forEach(t => drawTree(ctx, t.x, t.y));

    // 3. Draw Lore Obelisk
    drawObelisk(ctx, 160, 520, time);

    // 4. Draw The Patterned Gate
    drawGate(ctx, 480, 352, gateOpened, time);

    // 5. Draw Telegraph Warning Decals on the ground
    enemiesRef.current.forEach(enemy => {
      if (enemy.state === 'TELEGRAPH' && enemy.telegraphArea) {
        ctx.save();
        const area = enemy.telegraphArea;

        // Animated warning pulse
        const pulse = (Math.sin(time * 0.015) + 1) * 0.5;
        ctx.fillStyle = `rgba(179, 58, 58, ${0.3 + pulse * 0.25})`;
        ctx.strokeStyle = PALETTE.archiveRed;
        ctx.lineWidth = 2;

        if (area.type === 'circle' && area.radius) {
          ctx.beginPath();
          ctx.arc(area.x, area.y, area.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Hash marks inside warning circle
          ctx.beginPath();
          ctx.arc(area.x, area.y, area.radius * 0.5, 0, Math.PI * 2);
          ctx.setLineDash([4, 4]);
          ctx.stroke();
        } else if (area.type === 'line' && area.width && area.height) {
          ctx.fillRect(area.x - area.width / 2, area.y - area.height / 2, area.width, area.height);
          ctx.strokeRect(area.x - area.width / 2, area.y - area.height / 2, area.width, area.height);
        }

        ctx.restore();
      }
    });

    // 6. Draw NPC Caretaker Oron
    drawCaretaker(ctx, 320, 560, time);

    // 7. Draw Enemies
    enemiesRef.current.forEach(enemy => {
      if (enemy.state === 'DEAD') return;

      if (enemy.type === 'PATTERN_WISP') {
        drawPatternWisp(ctx, enemy.x, enemy.y, time, enemy.isVulnerable, enemy.hitFlashTimer > 0);
      } else if (enemy.type === 'SEQUENCE_WARDEN') {
        drawSequenceWarden(ctx, enemy.x, enemy.y, time, enemy.state, enemy.hp, enemy.maxHp, enemy.hitFlashTimer > 0);
      }

      // Draw Enemy Health Bar
      if (enemy.hp < enemy.maxHp) {
        const barW = enemy.width;
        const barH = 4;
        const barX = enemy.x;
        const barY = enemy.y - 8;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);

        const hpPct = Math.max(0, enemy.hp / enemy.maxHp);
        ctx.fillStyle = enemy.isVulnerable ? '#FBBF24' : '#EF4444';
        ctx.fillRect(barX, barY, barW * hpPct, barH);
      }
    });

    // 8. Draw Player Character
    const player = playerRef.current;
    drawPlayer(
      ctx,
      player.x,
      player.y,
      player.facing,
      player.walkFrame,
      player.isAttacking,
      player.hurtTimer > 0
    );

    // 9. Draw Projectiles
    projectilesRef.current.forEach(p => {
      ctx.save();
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // 10. Draw Particles
    particlesRef.current.forEach(pt => {
      ctx.save();
      ctx.globalAlpha = pt.alpha;
      ctx.fillStyle = pt.color;
      ctx.fillRect(pt.x, pt.y, pt.size, pt.size);
      ctx.restore();
    });

    // 11. Draw Floating Texts
    floatingTextsRef.current.forEach(ft => {
      ctx.save();
      ctx.font = 'bold 11px monospace';
      ctx.fillStyle = ft.color;
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 3;
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    });

    // 12. Draw In-World Interaction Indicator when close
    if (activePromptRef.current) {
      ctx.save();
      ctx.font = 'bold 10px monospace';
      ctx.fillStyle = '#FFFFFF';
      ctx.strokeStyle = PALETTE.inkNavy;
      ctx.lineWidth = 3;
      ctx.textAlign = 'center';
      const promptY = player.y - 14 + Math.sin(time * 0.006) * 3;
      ctx.strokeText('[E] INTERACT', player.x + 14, promptY);
      ctx.fillText('[E] INTERACT', player.x + 14, promptY);
      ctx.restore();
    }

    ctx.restore();
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-slate-950 overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        width={VIEW_WIDTH}
        height={VIEW_HEIGHT}
        className="w-full max-w-[1000px] aspect-[4/3] object-contain shadow-2xl rounded-sm border-2 border-slate-800"
        style={{ imageRendering: 'pixelated' }}
        tabIndex={0}
      />
    </div>
  );
};
