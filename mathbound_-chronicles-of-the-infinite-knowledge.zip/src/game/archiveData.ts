import { ArchiveEntry } from '../types/game';

export const INITIAL_ARCHIVE_ENTRIES: ArchiveEntry[] = [
  // --- PEOPLE ---
  {
    id: 'people_oron',
    title: 'Caretaker Oron',
    category: 'People',
    summary: 'Senior archivist and groundskeeper of the Academy Outpost.',
    detailedText: 'Caretaker Oron has maintained the outer perimeter of the Magical Academy for over four decades. While not a battle mage, his mastery of fundamental runic sequences and physical mechanisms allows him to keep ancient security barriers operating. He is deeply knowledgeable about the surrounding flora and the subtle shifts in the region\'s mathematical equilibrium.',
    discovered: false,
    relatedEntryIds: ['places_outpost', 'objects_gate', 'documents_caretaker_ledger'],
    iconName: 'User'
  },
  {
    id: 'people_warden',
    title: 'The Sequence Warden',
    category: 'People',
    summary: 'Ancient automaton construct charged with testing worthy scholars.',
    detailedText: 'Constructed during the Third Golden Age of the Academy, the Sequence Warden is not malicious; it is an animate pedagogical guardian. It evaluates candidates through spatial-mathematical trials, broadcasting telegraphed cadence waves across the arena floor that follow predictable numeric ratios. Only those who discern the rhythm may survive its strikes and unlock the inner sanctum.',
    discovered: false,
    relatedEntryIds: ['places_sanctum', 'objects_warden_sigil', 'words_telegraph'],
    iconName: 'ShieldAlert'
  },
  {
    id: 'people_archon',
    title: 'Archon Valerius',
    category: 'People',
    summary: 'Legendary geometer who bound mathematics into the academy stones.',
    detailedText: 'Historical records credit Archon Valerius with proving that magical energy flows through geometric pathways. Rather than brute-force mana barriers, Valerius designed gates that draw power from mathematical truths, remaining permanently unbreachable to those who cannot decipher the core principles.',
    discovered: false,
    relatedEntryIds: ['documents_axiom', 'objects_gate', 'words_cra'],
    iconName: 'Award'
  },

  // --- PLACES ---
  {
    id: 'places_outpost',
    title: 'The Academy Outpost',
    category: 'Places',
    summary: 'The fortified threshold between the untamed wilds and the inner sanctuaries.',
    detailedText: 'Nestled between primeval forest and ancient stone cliffs, the Outpost serves as the first filter for travelers, scholars, and initiates. Cobblestone courtyards, resonant flowerbeds, and guardian lanterns create a peaceful yet disciplined atmosphere where arithmetic balance keeps wild anomalies at bay.',
    discovered: true, // Discovered on arrival
    discoveryDate: 'Day 1 of Journey',
    relatedEntryIds: ['people_oron', 'places_sanctum', 'objects_gate'],
    iconName: 'Compass'
  },
  {
    id: 'places_sanctum',
    title: 'The Sequence Sanctum',
    category: 'Places',
    summary: 'An enclosed combat trial arena paving the path to the Grand Archive.',
    detailedText: 'A circular stone chamber paved with inscribed square tiles. The ambient magical ley lines converge here, allowing the Sequence Warden to summon elemental pulses along structured coordinate lines.',
    discovered: false,
    relatedEntryIds: ['people_warden', 'objects_warden_sigil'],
    iconName: 'MapPin'
  },

  // --- DOCUMENTS ---
  {
    id: 'documents_inscription',
    title: 'The Inscription of Rhythms',
    category: 'Documents',
    summary: 'Ancient chisel marks engraved across the lintel of the Silent Gate.',
    detailedText: '"When darkness clouds the threshold, look not to strength, but to the ratio of increase. What was two becomes four, what was four doubles once more. Feed the stone its true succession, and the path shall yield."',
    mathematicalConcept: {
      topic: 'Geometric Progression',
      rule: 'Each subsequent value equals the preceding term multiplied by the common ratio r = 2.',
      formula: 'a_n = a_1 · 2^(n-1)',
      explanation: 'In a geometric sequence, the ratio between consecutive terms is constant. When the ratio is 2, the growth is exponential doubling: 2, 4, 8, 16, 32, 64.',
      concreteExample: '1 rune stone splits into 2, 2 split into 4, 4 into 8, 8 into 16, 16 into 32, and 32 into 64.'
    },
    discovered: false,
    relatedEntryIds: ['objects_gate', 'words_geometric', 'words_cra'],
    documentQuestions: {
      isItReal: 'The chisel depth, mineral weathering, and resonant aura match authentic Third-Age Academy masonry. It was carved alongside the foundation stones.',
      whatDoesItMean: 'The riddle describes a sequence defined by repeated multiplication (a common ratio of 2). The lock mechanism requires completing this doubling sequence.',
      whatCanItTellUs: 'The builders expected scholars to understand exponential scaling rather than guessing numbers at random. It confirms that all Outpost barriers use predictable mathematical rules.'
    },
    iconName: 'FileText'
  },
  {
    id: 'documents_caretaker_ledger',
    title: 'Caretaker\'s Outpost Ledger',
    category: 'Documents',
    summary: 'Handwritten observations of shifting rune frequencies.',
    detailedText: 'Entry 442: "The main gate locked up again this morning after the dawn tremor. The fourth rune socket flickers empty. The Pattern Wisps outside have grown agitated, mirroring the sequence steps in their movement vectors."',
    discovered: false,
    relatedEntryIds: ['people_oron', 'objects_gate', 'objects_wisp_core'],
    documentQuestions: {
      isItReal: 'Written in Oron\'s handwriting in dark ink on coarse parchment; smudges indicate recent inspection at the gate mechanism.',
      whatDoesItMean: 'The disruption was caused by an energy fault rather than enemy invasion; the missing rune broke the continuous circuit of the sequence.',
      whatCanItTellUs: 'Restoring the missing rune tile will re-establish the harmonic circuit and safely open the gate.'
    },
    iconName: 'BookOpen'
  },
  {
    id: 'documents_axiom',
    title: 'The Axiom of Growth',
    category: 'Documents',
    summary: 'A pristine parchment excerpt preserved from Master Valerius\'s manuscripts.',
    detailedText: '"Observe the differences between terms. If the gap is constant, addition governs the path. If the ratio of consecutive terms is identical, multiplication commands the realm."',
    mathematicalConcept: {
      topic: 'Arithmetic vs. Geometric Sequences',
      rule: 'Comparing first-order differences (d = a_{n} - a_{n-1}) versus quotients (r = a_n / a_{n-1}).',
      formula: 'Arithmetic: a_n = a_1 + (n-1)d | Geometric: a_n = a_1 · r^(n-1)',
      explanation: 'Determining whether a pattern adds or multiplies is the foundational step of sequence classification.',
      concreteExample: '+3 pattern: 3, 6, 9, 12, 15... vs ×2 pattern: 3, 6, 12, 24, 48...'
    },
    discovered: false,
    relatedEntryIds: ['words_geometric', 'words_arithmetic'],
    documentQuestions: {
      isItReal: 'An authorized parchment copy bearing the seal of the Grand Archive of Infinite Knowledge.',
      whatDoesItMean: 'It provides a systematic test method: always calculate the difference first; if irregular, test the quotient.',
      whatCanItTellUs: 'This rule unlocks every mechanism in the outpost without guesswork.'
    },
    iconName: 'Scroll'
  },

  // --- OBJECTS ---
  {
    id: 'objects_gate',
    title: 'The Patterned Gate',
    category: 'Objects',
    summary: 'A towering stone portal locked by four interlocking sequence slots.',
    detailedText: 'Carved from monolithic granite and veined with azure lapis lazuli, this portal bars the path between the Outpost Courtyard and the Sequence Sanctum. It will only swing open when the energy sequence matches the resonant frequency inscribed in its runic sockets.',
    discovered: false,
    relatedEntryIds: ['documents_inscription', 'words_geometric'],
    iconName: 'DoorClosed'
  },
  {
    id: 'objects_focus',
    title: 'Resonant Focus',
    category: 'Objects',
    summary: 'The scholar\'s starter wand capable of casting concentrated Arcane Pulses.',
    detailedText: 'Forged from polished silver and crowned with a cut topaz. When swung, it discharges a focused crescent pulse that disrupts magical manifestations and breaks low-density barrier crystals.',
    discovered: true, // Player starts with this tool
    discoveryDate: 'Starting Equipment',
    relatedEntryIds: ['people_archon', 'words_telegraph'],
    iconName: 'Sparkles'
  },
  {
    id: 'objects_wisp_core',
    title: 'Wisp Essence Core',
    category: 'Objects',
    summary: 'A glowing polyhedral crystal recovered from a quelled Pattern Wisp.',
    detailedText: 'A geometric crystal that pulses with gentle emerald luminescence. Scholars use these cores to recharge vital health and stabilize harmonic mechanisms.',
    discovered: false,
    relatedEntryIds: ['people_oron', 'places_outpost'],
    iconName: 'Gem'
  },
  {
    id: 'objects_warden_sigil',
    title: 'Warden\'s Resonance Sigil',
    category: 'Objects',
    summary: 'Master key and symbol of mathematical competence granted by the Warden.',
    detailedText: 'A heavy brass emblem engraved with an interlocking Fibonacci spiral and geometric polygons. Carrying this sigil grants passage through all regional gates and identifies the bearer as an acknowledged scholar of the Infinite Knowledge.',
    discovered: false,
    relatedEntryIds: ['people_warden', 'places_sanctum'],
    iconName: 'Key'
  },

  // --- WORDS ---
  {
    id: 'words_geometric',
    title: 'Geometric Sequence',
    category: 'Words',
    summary: 'A progression of numbers where each term is produced by multiplying by a constant factor.',
    detailedText: 'In mathematics, a geometric progression is a sequence of non-zero numbers where each term after the first is found by multiplying the previous one by a fixed, non-zero number called the common ratio.',
    mathematicalConcept: {
      topic: 'Geometric Progression Definition',
      rule: 'Multiply the preceding number by the common ratio r.',
      formula: 'a_n = a_1 · r^(n-1)',
      explanation: 'Geometric sequences appear across nature in cell division, tree branching, acoustic octave frequencies, and financial compound interest.',
      concreteExample: 'Start with 2, multiply by 3: 2, 6, 18, 54, 162...'
    },
    discovered: false,
    relatedEntryIds: ['documents_inscription', 'words_arithmetic'],
    iconName: 'Hash'
  },
  {
    id: 'words_arithmetic',
    title: 'Arithmetic Progression',
    category: 'Words',
    summary: 'A sequence where the difference between any two consecutive terms is constant.',
    detailedText: 'An arithmetic progression (or arithmetic sequence) is a sequence of numbers such that the difference between consecutive terms is constant, known as the common difference d.',
    mathematicalConcept: {
      topic: 'Arithmetic Progression Definition',
      rule: 'Add the common difference d to the preceding term.',
      formula: 'a_n = a_1 + (n-1)d',
      explanation: 'Represents steady linear growth, such as measuring steps, uniform distance intervals, or steady clock ticks.',
      concreteExample: 'Start with 5, add 4: 5, 9, 13, 17, 21...'
    },
    discovered: false,
    relatedEntryIds: ['words_geometric'],
    iconName: 'Layers'
  },
  {
    id: 'words_cra',
    title: 'Concrete–Representational–Abstract',
    category: 'Words',
    summary: 'The three-phase pedagogical pipeline for enduring mathematical insight.',
    detailedText: 'The CRA instructional model guides a learner from tactile manipulation of physical objects (Concrete), to visual diagrams and models (Representational), and finally to symbolic notation and generalized equations (Abstract). MATHBOUND anchors every puzzle in this progression.',
    mathematicalConcept: {
      topic: 'Pedagogical Framework',
      rule: 'Hands-on tokens -> Visual charts/diagrams -> Algebraic formulae.',
      explanation: 'By experiencing the concept across all three modalities, understanding becomes intuitive, transferable, and resilient to anxiety.',
      concreteExample: 'Holding 4 coins -> Drawing 4 dots on paper -> Writing the digit "4".'
    },
    discovered: true,
    discoveryDate: 'Academy Handbook',
    relatedEntryIds: ['people_archon', 'documents_inscription'],
    iconName: 'GraduationCap'
  },
  {
    id: 'words_telegraph',
    title: 'Algorithmic Telegraph',
    category: 'Words',
    summary: 'The visual forewarning of enemy actions based on predictable geometric rhythm.',
    detailedText: 'In top-down tactical combat, an enemy telegraph communicates impending danger zones before damage is dealt. In MATHBOUND, telegraphs follow mathematically predictable durations and geometric safe vectors, allowing calm observation to defeat frantic button-mashing.',
    discovered: true,
    discoveryDate: 'Academy Handbook',
    relatedEntryIds: ['people_warden'],
    iconName: 'Activity'
  }
];

export const INITIAL_INVENTORY: import('../types/game').InventoryItem[] = [
  {
    id: 'tool_focus',
    name: 'Resonant Focus',
    type: 'TOOL',
    description: 'Scholar wand for discharging Arcane Pulses (Press J or Left-Click).',
    quantity: 1,
    icon: 'Sparkles'
  },
  {
    id: 'item_elixir',
    name: 'Elixir of Clarity',
    type: 'CONSUMABLE',
    description: 'Ancient herbal brew that restores 45 HP and calms mathematical anxiety.',
    quantity: 3,
    icon: 'FlaskRound',
    effect: 'HEAL',
    effectValue: 45
  },
  {
    id: 'item_chalk',
    name: 'Scholar\'s Chalk',
    type: 'TOOL',
    description: 'Enchanted chalk used to draw geometric proofs and highlight floor runes.',
    quantity: 1,
    icon: 'Edit3',
    effect: 'REVEAL_HINT'
  }
];

export const INITIAL_QUEST: import('../types/game').Quest = {
  id: 'THE_SILENT_GATE',
  title: 'The Silent Gate',
  summary: 'Investigate the locked academy gate, decode its mathematical rune sequence, quell the agitated wisps, and prove your insight to the Sequence Warden.',
  stage: 'TALK_TO_CARETAKER',
  objectives: [
    {
      stage: 'TALK_TO_CARETAKER',
      description: 'Speak with Caretaker Oron in the Academy Outpost courtyard.',
      completed: false
    },
    {
      stage: 'INSPECT_GATE',
      description: 'Inspect the ancient Patterned Gate at the northern courtyard border.',
      completed: false
    },
    {
      stage: 'SOLVE_PUZZLE',
      description: 'Arrange the rune sequence correctly to restore harmonic power to the gate.',
      completed: false
    },
    {
      stage: 'DEFEAT_WISPS',
      description: 'Clear the agitated Pattern Wisps pacing in the outer perimeter.',
      completed: false
    },
    {
      stage: 'DEFEAT_WARDEN',
      description: 'Confront the Sequence Warden in the Sanctum and decipher its cadence attacks.',
      completed: false
    },
    {
      stage: 'REPORT_TO_CARETAKER',
      description: 'Return to Caretaker Oron with the Warden\'s Resonance Sigil.',
      completed: false
    }
  ],
  rewards: {
    experience: 250,
    items: ['Warden\'s Resonance Sigil', 'Master Scholar\'s Compass'],
    archiveEntries: ['people_warden', 'objects_warden_sigil', 'places_sanctum']
  }
};
