import React from 'react';
import { Quest } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { ScrollText, X, CheckCircle2, Circle, Award, Sparkles, Compass } from 'lucide-react';

interface QuestJournalModalProps {
  quest: Quest;
  onClose: () => void;
}

export const QuestJournalModal: React.FC<QuestJournalModalProps> = ({
  quest,
  onClose
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-2xl max-w-xl w-full p-5 shadow-2xl flex flex-col gap-4 text-white">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ScrollText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">Scholar\'s Quest Log</h2>
              <p className="text-[11px] text-slate-400">Active Investigations & Educational Milestones</p>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quest Info */}
        <div className="space-y-4">
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                <Compass className="w-4 h-4 text-amber-400" />
                {quest.title}
              </h3>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                quest.stage === 'COMPLETED'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}>
                {quest.stage === 'COMPLETED' ? 'Completed' : 'In Progress'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-serif">
              {quest.summary}
            </p>
          </div>

          {/* Objectives Checklist */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
              Investigation Steps
            </h4>
            <div className="space-y-1.5">
              {quest.objectives.map((obj, idx) => {
                const isCurrent = obj.stage === quest.stage;
                return (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-lg border text-xs flex items-center gap-3 transition-colors ${
                      obj.completed
                        ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-200'
                        : isCurrent
                        ? 'bg-amber-500/10 border-amber-500/40 text-amber-100 font-semibold shadow-sm'
                        : 'bg-slate-950/40 border-slate-800/60 text-slate-500'
                    }`}
                  >
                    {obj.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : isCurrent ? (
                      <Sparkles className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-600 shrink-0" />
                    )}
                    <span>{obj.description}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Rewards Card */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Completion Bounty:</span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-amber-300">
              <span>+{quest.rewards.experience} Scholar EXP</span>
              <span>·</span>
              <span>Warden\'s Sigil</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
