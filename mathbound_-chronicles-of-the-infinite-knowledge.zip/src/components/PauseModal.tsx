import React, { useState } from 'react';
import { soundManager } from '../audio/soundManager';
import { 
  Play, 
  BookOpen, 
  Briefcase, 
  ScrollText, 
  Settings, 
  Save, 
  Home, 
  Check, 
  AlertTriangle 
} from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onOpenArchive: () => void;
  onOpenInventory: () => void;
  onOpenQuestJournal: () => void;
  onOpenSettings: () => void;
  onSaveGame: () => void;
  onReturnToTitle: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onOpenArchive,
  onOpenInventory,
  onOpenQuestJournal,
  onOpenSettings,
  onSaveGame,
  onReturnToTitle
}) => {
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showConfirmTitle, setShowConfirmTitle] = useState(false);

  const handleSave = () => {
    soundManager.playPuzzleSuccess();
    onSaveGame();
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-2xl max-w-sm w-full p-6 shadow-2xl flex flex-col gap-3 text-white">
        {/* Title */}
        <div className="text-center pb-2 border-b border-slate-800">
          <h2 className="text-xl font-black text-amber-300 tracking-wider">EXPEDITION PAUSED</h2>
          <p className="text-xs text-slate-400 mt-0.5">The Academy Outpost · Safe Rest</p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 pt-2">
          {/* Resume */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onResume();
            }}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-98 transition-all"
          >
            <Play className="w-4 h-4 fill-current" />
            Resume Adventure
          </button>

          {/* Archive */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenArchive();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2.5 transition-colors"
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            Historian\'s Archive [Tab]
          </button>

          {/* Satchel */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenInventory();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2.5 transition-colors"
          >
            <Briefcase className="w-4 h-4 text-emerald-400" />
            Satchel & Items [I]
          </button>

          {/* Quest Log */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenQuestJournal();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2.5 transition-colors"
          >
            <ScrollText className="w-4 h-4 text-sky-400" />
            Quest Journal [Q]
          </button>

          {/* Settings */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenSettings();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2.5 transition-colors"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            Settings & Controls
          </button>

          {/* Save Progress */}
          <button
            onClick={handleSave}
            className={`w-full py-2.5 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
              saveSuccess
                ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
            }`}
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                Progress Saved Locally!
              </>
            ) : (
              <>
                <Save className="w-4 h-4 text-amber-400" />
                Save Adventure Now
              </>
            )}
          </button>

          {/* Return to Title */}
          {!showConfirmTitle ? (
            <button
              onClick={() => {
                soundManager.playTileSnap();
                setShowConfirmTitle(true);
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-red-950/40 border border-slate-800 hover:border-red-800/60 text-slate-400 hover:text-red-300 text-xs font-semibold flex items-center justify-center gap-2 transition-colors mt-2"
            >
              <Home className="w-4 h-4" />
              Return to Title Menu
            </button>
          ) : (
            <div className="bg-red-950/40 border border-red-800/60 rounded-xl p-3 text-center space-y-2 mt-2">
              <span className="text-[11px] text-red-200 flex items-center justify-center gap-1.5 font-medium">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                Unsaved progress since last checkpoint will be lost!
              </span>
              <div className="flex gap-2 justify-center">
                <button
                  onClick={() => setShowConfirmTitle(false)}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs"
                >
                  Cancel
                </button>
                <button
                  onClick={onReturnToTitle}
                  className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white font-bold rounded text-xs"
                >
                  Confirm Exit
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
