import React, { useState, useEffect, useCallback } from 'react';
import { 
  ArchiveEntry, 
  GameScreenState, 
  GameSettings, 
  InventoryItem, 
  Quest, 
  QuestStage, 
  SaveData 
} from './types/game';
import { 
  INITIAL_ARCHIVE_ENTRIES, 
  INITIAL_INVENTORY, 
  INITIAL_QUEST 
} from './game/archiveData';
import { createGatePuzzle } from './game/puzzles/patternGate';
import { soundManager } from './audio/soundManager';
import { TitleScreen } from './components/TitleScreen';
import { GameCanvas } from './game/GameCanvas';
import { GameHUD } from './components/GameHUD';
import { DialogueModal } from './components/DialogueModal';
import { PuzzleModal } from './components/PuzzleModal';
import { ArchiveModal } from './components/ArchiveModal';
import { InventoryModal } from './components/InventoryModal';
import { QuestJournalModal } from './components/QuestJournalModal';
import { PauseModal } from './components/PauseModal';
import { SettingsModal } from './components/SettingsModal';
import { VictoryModal } from './components/VictoryModal';

const SAVE_STORAGE_KEY = 'MATHBOUND_SAVE_DATA_v1.0';

export default function App() {
  const [screenState, setScreenState] = useState<GameScreenState>('TITLE');
  const [hasSaveData, setHasSaveData] = useState<boolean>(false);

  // Core Game State
  const [playerHp, setPlayerHp] = useState<number>(100);
  const [playerMaxHp] = useState<number>(100);
  const [playerEnergy, setPlayerEnergy] = useState<number>(100);
  const [playerMaxEnergy] = useState<number>(100);
  const [playerPos, setPlayerPos] = useState<{ x: number; y: number }>({ x: 280, y: 580 });

  const [quest, setQuest] = useState<Quest>(INITIAL_QUEST);
  const [gateOpened, setGateOpened] = useState<boolean>(false);
  const [wispsDefeated, setWispsDefeated] = useState<boolean>(false);
  const [wardenDefeated, setWardenDefeated] = useState<boolean>(false);

  const [archiveEntries, setArchiveEntries] = useState<ArchiveEntry[]>(INITIAL_ARCHIVE_ENTRIES);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [activeDialogueNpc, setActiveDialogueNpc] = useState<string | null>(null);
  const [interactPrompt, setInteractPrompt] = useState<string | null>(null);
  const [newArchiveNotification, setNewArchiveNotification] = useState<string | null>(null);

  // Settings
  const [settings, setSettings] = useState<GameSettings>({
    sfxVolume: 80,
    musicVolume: 45,
    screenShake: true,
    relaxedMode: false,
    highContrast: false
  });

  // Puzzle State
  const [gatePuzzle, setGatePuzzle] = useState(createGatePuzzle());

  // Check LocalStorage on initial load
  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVE_STORAGE_KEY);
      if (saved) {
        setHasSaveData(true);
      }
    } catch {
      // LocalStorage access fallback
    }
  }, []);

  // Save Progress Routine
  const saveGame = useCallback(() => {
    const saveData: SaveData = {
      version: 1,
      timestamp: Date.now(),
      player: {
        x: playerPos.x,
        y: playerPos.y,
        hp: playerHp,
        maxHp: playerMaxHp,
        energy: playerEnergy
      },
      quest,
      gateOpened,
      wispsDefeated,
      wardenDefeated,
      archiveEntries,
      inventory,
      settings,
      prototypeCompleted: quest.stage === 'COMPLETED'
    };

    try {
      localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(saveData));
      setHasSaveData(true);
    } catch (e) {
      console.warn('Failed to save progress to localStorage', e);
    }
  }, [playerPos, playerHp, playerMaxHp, playerEnergy, quest, gateOpened, wispsDefeated, wardenDefeated, archiveEntries, inventory, settings]);

  // Load Saved Progress Routine
  const loadGame = () => {
    try {
      const raw = localStorage.getItem(SAVE_STORAGE_KEY);
      if (!raw) return;
      const data: SaveData = JSON.parse(raw);

      if (data.player) {
        setPlayerHp(data.player.hp || 100);
        setPlayerEnergy(data.player.energy || 100);
        setPlayerPos({ x: data.player.x || 280, y: data.player.y || 580 });
      }
      if (data.quest) setQuest(data.quest);
      if (data.gateOpened !== undefined) setGateOpened(data.gateOpened);
      if (data.wispsDefeated !== undefined) setWispsDefeated(data.wispsDefeated);
      if (data.wardenDefeated !== undefined) setWardenDefeated(data.wardenDefeated);
      if (data.archiveEntries) setArchiveEntries(data.archiveEntries);
      if (data.inventory) setInventory(data.inventory);
      if (data.settings) {
        setSettings(data.settings);
        soundManager.setVolumes(data.settings.sfxVolume, data.settings.musicVolume);
      }

      setScreenState('PLAYING');
      soundManager.startBGM();
    } catch (e) {
      console.error('Error loading save data', e);
      handleStartNewGame();
    }
  };

  // Start Fresh New Game Routine
  const handleStartNewGame = () => {
    setPlayerHp(100);
    setPlayerEnergy(100);
    setPlayerPos({ x: 280, y: 580 });
    setQuest(INITIAL_QUEST);
    setGateOpened(false);
    setWispsDefeated(false);
    setWardenDefeated(false);
    setArchiveEntries(INITIAL_ARCHIVE_ENTRIES);
    setInventory(INITIAL_INVENTORY);
    setGatePuzzle(createGatePuzzle());

    setScreenState('PLAYING');
    soundManager.startBGM();

    // Unlock opening Outpost location & start equipment
    unlockArchiveEntry('places_outpost');
    unlockArchiveEntry('objects_focus');
    unlockArchiveEntry('words_cra');
  };

  // Helper to safely unlock Archive entries
  const unlockArchiveEntry = useCallback((entryId: string) => {
    setArchiveEntries(prev => {
      const target = prev.find(e => e.id === entryId);
      if (!target || target.discovered) return prev;

      soundManager.playArchiveUnlock();
      setNewArchiveNotification(`New Archive Entry: ${target.title}`);
      setTimeout(() => setNewArchiveNotification(null), 3500);

      return prev.map(e => e.id === entryId ? { ...e, discovered: true, discoveryDate: 'Recorded' } : e);
    });
  }, []);

  // Advance Quest Stage with Automatic Checkpointing
  const handleUpdateQuestStage = useCallback((newStage: QuestStage) => {
    setQuest(prev => {
      const updatedObjectives = prev.objectives.map(obj => {
        if (obj.stage === prev.stage) {
          return { ...obj, completed: true };
        }
        return obj;
      });

      const updatedQuest: Quest = {
        ...prev,
        stage: newStage,
        objectives: updatedObjectives
      };

      // Auto-save at milestone
      setTimeout(saveGame, 50);
      return updatedQuest;
    });
  }, [saveGame]);

  // Handle NPC Dialogue Trigger
  const handleOpenDialogue = (npcId: string) => {
    setActiveDialogueNpc(npcId);
    setScreenState('DIALOGUE');

    if (npcId === 'npc_oron') {
      unlockArchiveEntry('people_oron');
      unlockArchiveEntry('documents_caretaker_ledger');
    }
  };

  // Handle Obelisk Lore Inspection
  const handleOpenObelisk = (obeliskId: string) => {
    unlockArchiveEntry('documents_inscription');
    unlockArchiveEntry('documents_axiom');
    unlockArchiveEntry('words_arithmetic');
    setScreenState('ARCHIVE');
  };

  // Handle Puzzle Open
  const handleOpenPuzzle = () => {
    setScreenState('PUZZLE');
  };

  // Handle Puzzle Solved Success
  const handlePuzzleSuccess = (explanation: string) => {
    setGateOpened(true);
    soundManager.playGateRumble();
    unlockArchiveEntry('objects_gate');
    unlockArchiveEntry('words_geometric');
    handleUpdateQuestStage('DEFEAT_WISPS');
    setScreenState('PLAYING');
  };

  // Handle Enemy Defeated drops & unlocks
  const handleEnemyDefeated = (enemyType: string) => {
    if (enemyType === 'PATTERN_WISP') {
      unlockArchiveEntry('objects_wisp_core');
      // Add health elixir drop
      setInventory(prev => prev.map(item => item.id === 'item_elixir' ? { ...item, quantity: item.quantity + 1 } : item));
    } else if (enemyType === 'SEQUENCE_WARDEN') {
      setWardenDefeated(true);
      unlockArchiveEntry('people_warden');
      unlockArchiveEntry('places_sanctum');
      unlockArchiveEntry('objects_warden_sigil');
      unlockArchiveEntry('people_archon');
      // Add Warden Sigil to inventory
      setInventory(prev => [
        ...prev,
        {
          id: 'item_sigil',
          name: 'Warden\'s Resonance Sigil',
          type: 'KEY',
          description: 'Ancient brass medal certifying mastery of geometric progression.',
          quantity: 1,
          icon: 'Key'
        }
      ]);
    }
  };

  // Consume Inventory Items
  const handleUseItem = (itemId: string) => {
    const item = inventory.find(i => i.id === itemId);
    if (!item) return;

    if (item.type === 'CONSUMABLE' && item.effect === 'HEAL') {
      const healAmount = item.effectValue || 45;
      setPlayerHp(prev => Math.min(playerMaxHp, prev + healAmount));

      setInventory(prev => prev.map(i => {
        if (i.id === itemId) {
          return { ...i, quantity: Math.max(0, i.quantity - 1) };
        }
        return i;
      }).filter(i => i.quantity > 0 || i.type !== 'CONSUMABLE'));
    }
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when on Title
      if (screenState === 'TITLE') return;

      // Close modal on Escape
      if (e.key === 'Escape') {
        e.preventDefault();
        if (screenState === 'PLAYING') {
          setScreenState('PAUSE');
        } else {
          setScreenState('PLAYING');
        }
        return;
      }

      // Open Modals only when in PLAYING state
      if (screenState === 'PLAYING') {
        if (e.key === 'Tab') {
          e.preventDefault();
          soundManager.playTileSnap();
          setScreenState('ARCHIVE');
        } else if (e.key.toLowerCase() === 'i') {
          e.preventDefault();
          soundManager.playTileSnap();
          setScreenState('INVENTORY');
        } else if (e.key.toLowerCase() === 'q') {
          e.preventDefault();
          soundManager.playTileSnap();
          setScreenState('QUEST_JOURNAL');
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [screenState]);

  // Unread Archive entries calculation
  const unreadArchiveCount = archiveEntries.filter(e => e.discovered && e.discoveryDate === 'Recorded').length;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 flex items-center justify-center font-sans antialiased">
      {/* 1. Title Screen */}
      {screenState === 'TITLE' && (
        <TitleScreen
          onNewGame={handleStartNewGame}
          onContinue={loadGame}
          onOpenSettings={() => setScreenState('SETTINGS')}
          hasSaveData={hasSaveData}
        />
      )}

      {/* 2. Active Game Engine & Canvas (Rendered when in gameplay or overlay modal) */}
      {screenState !== 'TITLE' && (
        <div className="relative w-full h-full flex flex-col items-center justify-center">
          <GameCanvas
            onOpenDialogue={handleOpenDialogue}
            onOpenPuzzle={handleOpenPuzzle}
            onOpenObelisk={handleOpenObelisk}
            onPrototypeComplete={() => setScreenState('VICTORY')}
            quest={quest}
            gateOpened={gateOpened}
            settings={settings}
            screenState={screenState}
            onUpdateQuestStage={handleUpdateQuestStage}
            onEnemyDefeated={handleEnemyDefeated}
            onPlayerHealthChange={(hp) => setPlayerHp(hp)}
            onPlayerEnergyChange={(energy) => setPlayerEnergy(energy)}
            onInteractPromptChange={(prompt) => setInteractPrompt(prompt)}
            savedPlayerPos={playerPos}
          />

          {/* In-Game Heads-Up Display */}
          <GameHUD
            hp={playerHp}
            maxHp={playerMaxHp}
            energy={playerEnergy}
            maxEnergy={playerMaxEnergy}
            quest={quest}
            interactPrompt={interactPrompt}
            unreadArchiveCount={unreadArchiveCount}
            onOpenArchive={() => setScreenState('ARCHIVE')}
            onOpenInventory={() => setScreenState('INVENTORY')}
            onOpenQuestJournal={() => setScreenState('QUEST_JOURNAL')}
            onOpenPause={() => setScreenState('PAUSE')}
            onInteract={() => {
              window.dispatchEvent(new KeyboardEvent('keydown', { key: 'e' }));
            }}
          />

          {/* New Archive Entry Toast Notification */}
          {newArchiveNotification && (
            <div className="fixed top-20 left-1/2 -translate-x-1/2 z-40 bg-gradient-to-r from-amber-600 to-amber-500 text-slate-950 px-4 py-2 rounded-xl shadow-2xl font-bold text-xs tracking-wide flex items-center gap-2 border border-amber-300 animate-slide-down">
              <span>📜</span>
              <span>{newArchiveNotification}</span>
            </div>
          )}
        </div>
      )}

      {/* 3. Modals */}
      {screenState === 'DIALOGUE' && activeDialogueNpc && (
        <DialogueModal
          npcId={activeDialogueNpc}
          questStage={quest.stage}
          onAdvanceQuest={(stage) => {
            handleUpdateQuestStage(stage);
            if (stage === 'COMPLETED') {
              setScreenState('VICTORY');
            }
          }}
          onClose={() => setScreenState('PLAYING')}
        />
      )}

      {screenState === 'PUZZLE' && (
        <PuzzleModal
          puzzle={gatePuzzle}
          onSolveSuccess={handlePuzzleSuccess}
          onClose={() => setScreenState('PLAYING')}
        />
      )}

      {screenState === 'ARCHIVE' && (
        <ArchiveModal
          entries={archiveEntries}
          onClose={() => setScreenState('PLAYING')}
        />
      )}

      {screenState === 'INVENTORY' && (
        <InventoryModal
          items={inventory}
          playerHp={playerHp}
          playerMaxHp={playerMaxHp}
          onUseItem={handleUseItem}
          onClose={() => setScreenState('PLAYING')}
        />
      )}

      {screenState === 'QUEST_JOURNAL' && (
        <QuestJournalModal
          quest={quest}
          onClose={() => setScreenState('PLAYING')}
        />
      )}

      {screenState === 'PAUSE' && (
        <PauseModal
          onResume={() => setScreenState('PLAYING')}
          onOpenArchive={() => setScreenState('ARCHIVE')}
          onOpenInventory={() => setScreenState('INVENTORY')}
          onOpenQuestJournal={() => setScreenState('QUEST_JOURNAL')}
          onOpenSettings={() => setScreenState('SETTINGS')}
          onSaveGame={saveGame}
          onReturnToTitle={() => {
            soundManager.stopBGM();
            setScreenState('TITLE');
          }}
        />
      )}

      {screenState === 'SETTINGS' && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newSettings) => setSettings(newSettings)}
          onClose={() => {
            if (screenState === 'SETTINGS' && !hasSaveData) {
              setScreenState('TITLE');
            } else {
              setScreenState('PLAYING');
            }
          }}
        />
      )}

      {screenState === 'VICTORY' && (
        <VictoryModal
          onContinueExploring={() => setScreenState('PLAYING')}
          onReturnToTitle={() => {
            soundManager.stopBGM();
            setScreenState('TITLE');
          }}
          archiveCount={archiveEntries.filter(e => e.discovered).length}
          totalArchiveCount={archiveEntries.length}
        />
      )}
    </div>
  );
}
