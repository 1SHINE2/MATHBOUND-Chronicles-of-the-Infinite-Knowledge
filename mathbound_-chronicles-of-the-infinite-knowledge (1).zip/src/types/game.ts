export type GameScreenState = 
  | 'TITLE'
  | 'PROLOGUE'
  | 'CHARACTER_SELECT'
  | 'PLAYING'
  | 'DIALOGUE'
  | 'PUZZLE'
  | 'DIGITAL_BOOK'
  | 'TWO_TABLE_MAGIC'
  | 'CHALKBOARD'
  | 'DEFEAT'
  | 'INVENTORY'
  | 'QUEST_JOURNAL'
  | 'PAUSE'
  | 'SETTINGS'
  | 'VICTORY'
  | 'GAME_OVER';

export type ProtagonistId = 'SAMANTHA' | 'MIGUEL';

export interface ProtagonistProfile {
  id: ProtagonistId;
  name: string;
  age: number;
  height: string;
  thinkingStyle: 'Meditative' | 'Calculative';
  thinkingQuestion: string;
  summary: string;
  perspectiveNote: string;
  specialty: string;
  color: string;
}

export type DigitalBookLayer = 'CHRONICLE' | 'KNOWLEDGE' | 'ARCHIVE';

export interface ChronicleChapter {
  id: string;
  bookNumber: 1 | 2;
  bookTitle: string;
  chapterNumber: number;
  title: string;
  subtitle: string;
  unlocked: boolean;
  narrativeText: string[];
  keyEvent: string;
  protagonistReflection: {
    samantha: string;
    miguel: string;
  };
}

export interface TwoTableSpell {
  id: string;
  name: string;
  envision: {
    intent: string;
    targetEffect: string;
    conceptualShape: string;
  };
  command: {
    instruction: string;
    mathematicalFormula: string;
    channelMedium: string;
  };
  interpretation: string;
  response: string;
  element: 'Ice' | 'Resonance' | 'Neutral';
}

export interface PlayerStats {
  maxHp: number;
  hp: number;
  maxEnergy: number;
  energy: number;
  attackPower: number;
  speed: number;
  isDodging: boolean;
  dodgeCooldown: number;
  attackCooldown: number;
}

export type Direction = 'up' | 'down' | 'left' | 'right';

export interface Vector2 {
  x: number;
  y: number;
}

export interface HitBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type EnemyType = 'PATTERN_WISP' | 'SEQUENCE_WARDEN';

export interface EnemyEntity {
  id: string;
  type: EnemyType;
  name: string;
  species?: string;
  x: number;
  y: number;
  width: number;
  height: number;
  hp: number;
  maxHp: number;
  facing: Direction;
  state: 'IDLE' | 'MOVING' | 'TELEGRAPH' | 'ATTACK' | 'RECOVERY' | 'HURT' | 'DEAD' | 'CALMED';
  stateTimer: number;
  attackPatternIndex: number;
  telegraphArea?: {
    type: 'circle' | 'rect' | 'line';
    x: number;
    y: number;
    radius?: number;
    width?: number;
    height?: number;
    targetX?: number;
    targetY?: number;
  };
  targetPos?: Vector2;
  patrolPoints: Vector2[];
  currentPatrolIdx: number;
  hitFlashTimer: number;
  speed: number;
  isVulnerable: boolean;
}

export interface CompanionState {
  x: number;
  y: number;
  facing: Direction;
  walkFrame: number;
  isMoving: boolean;
  activeComment?: string;
}

export interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  fromPlayer: boolean;
  color: string;
  life: number;
  maxLife: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  alpha: number;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
}

export interface InteractableEntity {
  id: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  prompt: string;
  type: 'NPC' | 'PUZZLE_GATE' | 'CHEST' | 'LORE_OBELISK' | 'SANCTUM_EXIT';
  unlocked?: boolean;
}

// Quests
export type QuestId = 'THE_SILENT_GATE';

export type QuestStage = 
  | 'NOT_STARTED'
  | 'TALK_TO_CARETAKER'
  | 'INSPECT_GATE'
  | 'SOLVE_PUZZLE'
  | 'DEFEAT_WISPS'
  | 'DEFEAT_WARDEN'
  | 'REPORT_TO_CARETAKER'
  | 'COMPLETED';

export interface Quest {
  id: QuestId;
  title: string;
  summary: string;
  stage: QuestStage;
  objectives: {
    stage: QuestStage;
    description: string;
    completed: boolean;
  }[];
  rewards: {
    experience: number;
    items: string[];
    archiveEntries: string[];
  };
}

// Archive
export type ArchiveCategory = 'People' | 'Places' | 'Documents' | 'Objects' | 'Words';

export interface ArchiveEntry {
  id: string;
  title: string;
  category: ArchiveCategory;
  summary: string;
  detailedText: string;
  mathematicalConcept?: {
    topic: string;
    rule: string;
    formula?: string;
    explanation: string;
    concreteExample: string;
  };
  discovered: boolean;
  discoveryDate?: string;
  relatedEntryIds: string[];
  documentQuestions?: {
    isItReal: string;
    whatDoesItMean: string;
    whatCanItTellUs: string;
  };
  iconName: string;
}

// Inventory
export interface InventoryItem {
  id: string;
  name: string;
  type: 'KEY' | 'TOOL' | 'CONSUMABLE';
  description: string;
  quantity: number;
  icon: string;
  effect?: 'HEAL' | 'REVEAL_HINT' | 'ENERGY_RESTORE';
  effectValue?: number;
}

// Puzzle
export interface PuzzleRune {
  id: string;
  value: number;
  symbol: string;
  sides: number;
  color: string;
  label: string;
}

export interface PatternPuzzleState {
  id: string;
  title: string;
  description: string;
  curriculumCompetency: string;
  sequence: (PuzzleRune | null)[];
  missingIndices: number[];
  availableRunes: PuzzleRune[];
  correctAnswers: number[];
  playerAnswers: { [index: number]: PuzzleRune | null };
  ruleExplanation: string;
  hintLadder: [string, string, string]; // 1. Observation, 2. Relationship, 3. Guided Step
  hintsUsed: number;
  isSolved: boolean;
}

// Settings
export interface GameSettings {
  sfxVolume: number; // 0 - 100
  musicVolume: number; // 0 - 100
  screenShake: boolean;
  relaxedMode: boolean; // grants more defense and longer telegraph windows
  highContrast: boolean;
}

// Save Data structure
export interface SaveData {
  version: number;
  timestamp: number;
  protagonist: ProtagonistId;
  player: {
    x: number;
    y: number;
    hp: number;
    maxHp: number;
    energy: number;
  };
  quest: Quest;
  gateOpened: boolean;
  wispsDefeated: boolean;
  wardenDefeated: boolean;
  archiveEntries: ArchiveEntry[];
  chronicleChapters: ChronicleChapter[];
  inventory: InventoryItem[];
  settings: GameSettings;
  prototypeCompleted: boolean;
}
