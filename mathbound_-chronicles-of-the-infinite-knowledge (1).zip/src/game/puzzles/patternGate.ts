import { PatternPuzzleState, PuzzleRune } from '../../types/game';

// Preset runes with clear visual traits (nodes, color, geometric form)
export const ALL_RUNES: Record<string, PuzzleRune> = {
  RUNE_2: {
    id: 'rune_2',
    value: 2,
    symbol: 'ᚠ',
    sides: 2,
    color: '#527A67', // Forest green
    label: 'Di-Rune (2)'
  },
  RUNE_4: {
    id: 'rune_4',
    value: 4,
    symbol: 'ᚢ',
    sides: 4,
    color: '#2A7B9B', // Slate blue
    label: 'Tetra-Rune (4)'
  },
  RUNE_8: {
    id: 'rune_8',
    value: 8,
    symbol: 'ᚦ',
    sides: 8,
    color: '#8A4F7D', // Violet
    label: 'Octa-Rune (8)'
  },
  RUNE_16: {
    id: 'rune_16',
    value: 16,
    symbol: 'ᚨ',
    sides: 16,
    color: '#D9A441', // Warm gold
    label: 'Hexadeca-Rune (16)'
  },
  RUNE_32: {
    id: 'rune_32',
    value: 32,
    symbol: 'ᚱ',
    sides: 32,
    color: '#B33A3A', // Archive red
    label: 'Triaconta-Rune (32)'
  },
  RUNE_64: {
    id: 'rune_64',
    value: 64,
    symbol: 'ᚲ',
    sides: 64,
    color: '#E07A5F', // Solar amber
    label: 'Harmonic Core (64)'
  },
  // Distractor Runes
  RUNE_48: {
    id: 'rune_48',
    value: 48,
    symbol: 'ᚷ',
    sides: 12,
    color: '#6B7280',
    label: 'Dodeca-Rune (48)'
  },
  RUNE_50: {
    id: 'rune_50',
    value: 50,
    symbol: 'ᚹ',
    sides: 10,
    color: '#9CA3AF',
    label: 'Deca-Rune (50)'
  },
  RUNE_36: {
    id: 'rune_36',
    value: 36,
    symbol: 'ᚺ',
    sides: 6,
    color: '#4B5563',
    label: 'Hexa-Rune (36)'
  }
};

export function createGatePuzzle(): PatternPuzzleState {
  return {
    id: 'GATE_PUZZLE_EXPONENTIAL',
    title: 'The Patterned Gate: Harmonic Doubling',
    description: 'The ancient stone gate requires restoring the continuous energy ratio. Observe the sequence of illuminated runes and place the missing harmonic tile.',
    curriculumCompetency: 'Pattern Recognition & Geometric Sequences (Recognizing Common Ratio r = 2)',
    sequence: [
      ALL_RUNES.RUNE_4,
      ALL_RUNES.RUNE_8,
      ALL_RUNES.RUNE_16,
      ALL_RUNES.RUNE_32,
      null // Player must supply 64!
    ],
    missingIndices: [4],
    availableRunes: [
      ALL_RUNES.RUNE_36,
      ALL_RUNES.RUNE_48,
      ALL_RUNES.RUNE_50,
      ALL_RUNES.RUNE_64
    ],
    correctAnswers: [64],
    playerAnswers: {
      4: null
    },
    ruleExplanation: 'The sequence follows an exponential geometric growth where each term is twice the preceding term: a_n = 4 · 2^(n-1). Since 32 × 2 = 64, the 64-energy Harmonic Core restores the circuit.',
    hintLadder: [
      'Observation: Look at the numbers in the consecutive active sockets: 4, then 8, then 16, then 32. Do they increase by a steady addition or by multiplication?',
      'Relationship: Test the ratio: 8 ÷ 4 = 2, 16 ÷ 8 = 2, 32 ÷ 16 = 2. Each socket doubles the energy of the previous socket (×2 multiplier).',
      'Guided Step: To find the 5th term, multiply the 4th term (32) by 2: 32 × 2 = 64. Place the Harmonic Core (64) into the empty socket.'
    ],
    hintsUsed: 0,
    isSolved: false
  };
}

export function validatePuzzle(state: PatternPuzzleState): { isCorrect: boolean; message: string } {
  for (let i = 0; i < state.missingIndices.length; i++) {
    const slotIdx = state.missingIndices[i];
    const placed = state.playerAnswers[slotIdx];
    const expectedVal = state.correctAnswers[i];

    if (!placed) {
      return {
        isCorrect: false,
        message: 'The sequence socket is still empty. Select a candidate rune to place into the slot.'
      };
    }

    if (placed.value !== expectedVal) {
      return {
        isCorrect: false,
        message: `Energy mismatch! Placing ${placed.value} disrupted the ratio. Remember to test whether the gap is addition (+4) or multiplication (×2).`
      };
    }
  }

  return {
    isCorrect: true,
    message: 'Harmonic resonance achieved! The geometric ratio has aligned, and the stone mechanism releases.'
  };
}
