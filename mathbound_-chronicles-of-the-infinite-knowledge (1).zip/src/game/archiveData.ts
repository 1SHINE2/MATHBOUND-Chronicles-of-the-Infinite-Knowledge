import { 
  ArchiveEntry, 
  ChronicleChapter, 
  InventoryItem, 
  ProtagonistProfile, 
  Quest, 
  TwoTableSpell 
} from '../types/game';

// Protagonist Profiles from Version 0.07
export const PROTAGONIST_PROFILES: Record<string, ProtagonistProfile> = {
  SAMANTHA: {
    id: 'SAMANTHA',
    name: 'Samantha Yu',
    age: 10,
    height: '4\'11"',
    thinkingStyle: 'Meditative',
    thinkingQuestion: 'What does it mean?',
    summary: 'A 10-year-old childhood friend with intuitive, reflective perception and an eye for meaning.',
    perspectiveNote: 'Approaches problems through reflection, intuition, and asking why structures exist. Notices symbolic connections and philosophical meaning behind mathematical phenomena.',
    specialty: 'Meditative Insight & Pattern Resonance',
    color: '#38BDF8'
  },
  MIGUEL: {
    id: 'MIGUEL',
    name: 'Miguel Perez',
    age: 11,
    height: '5\'4"',
    thinkingStyle: 'Calculative',
    thinkingQuestion: 'How does it work?',
    summary: 'An 11-year-old childhood friend with analytical, logical precision and structured inquiry.',
    perspectiveNote: 'Approaches problems through logic, measurable calculations, and step-by-step structural analysis. Focuses on quantifiable relationships and mechanical laws.',
    specialty: 'Calculative Precision & Vector Analysis',
    color: '#FBBF24'
  }
};

// Two-Table Command System Spells (Locked Canon)
export const CANONICAL_SPELLS: TwoTableSpell[] = [
  {
    id: 'spell_arcane_pulse',
    name: 'Frost-Cadence Pulse',
    envision: {
      intent: 'Project a focused crescent blade of chilling harmonic energy in facing direction',
      targetEffect: 'Disrupt physical trajectory and chill target entity',
      conceptualShape: 'Acute Circular Arc (120° sweep)'
    },
    command: {
      instruction: 'VECTOR_PROJECT(θ, velocity=140, damage=30)',
      mathematicalFormula: 'v(t) = v_0 · [cos(θ), sin(θ)]',
      channelMedium: 'Resonant Focus Topaz Wand'
    },
    interpretation: 'Magical entities condense along the projected vector, creating a kinetic ice shockwave that respects physical collision.',
    response: 'Discharges 30 damage, pushes targets back, and leaves a crystalline frost trail.',
    element: 'Ice'
  },
  {
    id: 'spell_wave_burst',
    name: 'Harmonic Resonance Ring',
    envision: {
      intent: 'Envision an expanding uniform radius that forces all entities into vibrational phase equilibrium',
      targetEffect: 'Expose enemy recovery states and dispel hostile projectiles',
      conceptualShape: 'Concentric Circumference expanding outward r(t) = r_0 + vt'
    },
    command: {
      instruction: 'RADIAL_EXPAND(r=120, harmonic_ratio=2.0)',
      mathematicalFormula: 'x^2 + y^2 ≤ r(t)^2, r(t) = 160 · t',
      channelMedium: 'Resonant Focus Core Chamber'
    },
    interpretation: 'Ambient magic synchronizes with the mathematical ratio, destabilizing chaotic entities and exposing their vulnerability windows.',
    response: 'Deals 45 damage in 360° and immediately stuns affected adversaries for 2 seconds.',
    element: 'Resonance'
  }
];

// Chronicle Chapters (Digital Book Narrative Layer)
export const INITIAL_CHRONICLE_CHAPTERS: ChronicleChapter[] = [
  {
    id: 'chronicle_ch1',
    bookNumber: 1,
    bookTitle: 'Book I — Foundations',
    chapterNumber: 1,
    title: 'The Library of Shadows',
    subtitle: 'Ordinary World & The Ancient Engraving',
    unlocked: true,
    narrativeText: [
      'In an ordinary school on an ordinary weekday afternoon, Samantha Yu (10) and Miguel Perez (11) found themselves drawn to the quietest corridor of the campus library.',
      'Neither was chosen by destiny; neither sought to fulfill a grand prophecy. They were simply two curious childhood friends who noticed an odd series of anomalies—books aligned to geometric proportions and dust motes settling in perfect Fibonacci spirals.',
      'Tucked behind the reference stacks lay the first volume: Chronicles of the Infinite Knowledge. On its heavy parchment cover rested an ancient engraving that pulsed with a faint, crystalline chill.',
      'Curiosity overcame caution. As their fingers touched the interlocking runic circles, a blinding flash of mysterious light enveloped them, lifting them beyond ordinary reality.'
    ],
    keyEvent: 'Activation of the Book I Portal Engraving in the School Library',
    protagonistReflection: {
      samantha: '"It wasn\'t magic pulling us in—it felt like we were opening an invitation to understand what had always been right in front of us."',
      miguel: '"The engraving wasn\'t random decoration. The grooves formed a complete closed circuit. When we touched it, we simply completed the calculation."'
    }
  },
  {
    id: 'chronicle_ch2',
    bookNumber: 1,
    bookTitle: 'Book I — Foundations',
    chapterNumber: 2,
    title: 'The Voice and the Five Rules',
    subtitle: 'Arrival in the Magical Academy Outpost',
    unlocked: true,
    narrativeText: [
      'When the light settled, Samantha and Miguel stood upon ancient cobblestones framed by primeval pines and monolithic stone arches. The air was crisp with frost.',
      'Before they could take a step, an unknown voice resonated through the courtyard—neither commanding nor divine, but sounding like the gentle clarity of an undeniable truth.',
      'The voice spoke the Five Foundational Rules of MATHBOUND:',
      '1. "What you see, you can understand. What you cannot see, you must question."',
      '2. "What you believe may be true. It may also be wrong."',
      '3. "Question what you know. Question what you don\'t know."',
      '4. "The unknown is not something to fear. It is something to uncover."',
      '5. "Open your minds, have fun... and let\'s find out."',
      'The voice vanished, leaving them with an explorer\'s wand—the Resonant Focus—and the expanse of the Academy Outpost.'
    ],
    keyEvent: 'Imparting of the Five Rules upon arrival in Book I',
    protagonistReflection: {
      samantha: '"Rule 2 hit me immediately. Believing something doesn\'t make it reality. Truth exists whether we agree or not."',
      miguel: '"The rules don\'t give us answers. They give us a method to test everything we observe."'
    }
  },
  {
    id: 'chronicle_ch3',
    bookNumber: 1,
    bookTitle: 'Book I — Foundations',
    chapterNumber: 3,
    title: 'The Silent Gate of Foundations',
    subtitle: 'Deciphering the Doubling Ratio',
    unlocked: false,
    narrativeText: [
      'Caretaker Oron greeted them at the outpost threshold. A dawn tremor had locked the Great Patterned Gate, fracturing the harmonic circuit.',
      'Examining the sequence sockets—4, 8, 16, 32—the children applied the Concrete-Representational-Abstract framework.',
      'By placing the Harmonic Core of 64, the constant common ratio (r = 2) was satisfied. The heavy stone portcullis released with a resonant hum, proving that reality yields to mathematical understanding.'
    ],
    keyEvent: 'Restoration of the Patterned Gate through Geometric Progression',
    protagonistReflection: {
      samantha: '"When the stone swung open, I saw that numbers weren\'t an obstacle; they were the language the gate had been waiting to hear."',
      miguel: '"Each socket doubled the preceding energy: 32 multiplied by 2 equals 64. The math wasn\'t arbitrary—it was mechanical truth."'
    }
  },
  {
    id: 'chronicle_ch4',
    bookNumber: 1,
    bookTitle: 'Book I — Foundations',
    chapterNumber: 4,
    title: 'Trial of the Sequence Warden',
    subtitle: 'The Cadence of Tactical Geometry',
    unlocked: false,
    narrativeText: [
      'Inside the Sequence Sanctum, the ancient automaton guardian awakened not in malice, but as an impartial evaluator of mathematical insight.',
      'The Warden broadcast telegraphed cadence waves across coordinate tiles. By observing the safe intervals, Samantha and Miguel avoided the hazards, striking during the exhausted recovery window.',
      'Upon defeat, the Warden disengaged, presenting the Warden\'s Resonance Sigil and affirming their progress toward Book II.'
    ],
    keyEvent: 'Attainment of the Warden\'s Resonance Sigil',
    protagonistReflection: {
      samantha: '"The Warden wasn\'t trying to hurt us; it was testing whether we would panic or think clearly under pressure."',
      miguel: '"Combat in MATHBOUND is just another equation in motion: identify the danger vector, position in the safe set, and strike during the recovery phase."'
    }
  }
];

// Historian's Archive Entries (Reference Layer - 5 Categories)
export const INITIAL_ARCHIVE_ENTRIES: ArchiveEntry[] = [
  // --- PEOPLE ---
  {
    id: 'people_samantha',
    title: 'Samantha Yu (Age 10)',
    category: 'People',
    summary: 'Childhood friend and co-protagonist; practitioner of Meditative Thinking.',
    detailedText: 'Samantha Yu is a 10-year-old school student (approx. 4\'11") who entered MATHBOUND alongside her childhood friend Miguel Perez after discovering Book I in their school library. Samantha possesses a reflective, intuitive nature and naturally asks "What does it mean?". She perceives deep connections between philosophical truths, human feelings, and the underlying mathematical harmony of the universe. She is not a "chosen one"; her agency comes entirely from her curiosity.',
    discovered: true,
    discoveryDate: 'Protagonist',
    relatedEntryIds: ['people_miguel', 'documents_five_rules', 'places_outpost'],
    iconName: 'User'
  },
  {
    id: 'people_miguel',
    title: 'Miguel Perez (Age 11)',
    category: 'People',
    summary: 'Childhood friend and co-protagonist; practitioner of Calculative Thinking.',
    detailedText: 'Miguel Perez is an 11-year-old school student (approx. 5\'4") who entered MATHBOUND with his lifelong friend Samantha Yu. Miguel embodies Calculative Thinking, continually asking "How does it work?". He excels at structural logic, measurable precision, and breaking complex problems into verifiable components. His analytical mindset balances Samantha\'s intuitive reflections. Neither thinking style is superior; true comprehension requires both.',
    discovered: true,
    discoveryDate: 'Protagonist',
    relatedEntryIds: ['people_samantha', 'documents_five_rules', 'places_outpost'],
    iconName: 'User'
  },
  {
    id: 'people_oron',
    title: 'Caretaker Oron',
    category: 'People',
    summary: 'Senior archivist and groundskeeper of the Academy Outpost.',
    detailedText: 'Caretaker Oron has maintained the outer perimeter of the Magical Academy for over four decades. While not a battle mage, his mastery of fundamental runic sequences and physical mechanisms allows him to keep ancient security barriers operating. He is deeply knowledgeable about the surrounding flora and the subtle shifts in the region\'s mathematical equilibrium.',
    discovered: false,
    relatedEntryIds: ['places_outpost', 'objects_gate', 'documents_caretaker_ledger'],
    iconName: 'User'
  },
  {
    id: 'people_warden',
    title: 'The Sequence Warden',
    category: 'People',
    summary: 'Ancient automaton construct charged with testing worthy scholars.',
    detailedText: 'Constructed during the Third Golden Age of the Academy, the Sequence Warden is not malicious; it is an animate pedagogical guardian. It evaluates candidates through spatial-mathematical trials, broadcasting telegraphed cadence waves across the arena floor that follow predictable numeric ratios. Only those who discern the rhythm may survive its strikes and unlock the inner sanctum.',
    discovered: false,
    relatedEntryIds: ['places_sanctum', 'objects_warden_sigil', 'words_telegraph'],
    iconName: 'ShieldAlert'
  },
  {
    id: 'people_intelligent_races',
    title: 'Intelligent Populations of MATHBOUND',
    category: 'People',
    summary: 'The diverse cultures and sentient peoples coexisting within the mathematical universe.',
    detailedText: 'While humans are the primary established population in the Academy Outpost, MATHBOUND is home to diverse intelligent peoples including Elves, Dwarves, and Demi-humans. Each culture maintains its own historical, practical, and philosophical relationship to mathematics and ambient magic, from intuitive qualitative traditions to rigorous quantitative engineering.',
    discovered: false,
    relatedEntryIds: ['people_the_order', 'places_outpost'],
    iconName: 'User'
  },
  {
    id: 'people_the_order',
    title: 'The Order',
    category: 'People',
    summary: 'The civil governmental institution overseeing public administration and magical safety.',
    detailedText: 'The Order is the established governing body in MATHBOUND. It carries out ordinary administrative duties—public safety, infrastructure, education, and legal codification—alongside specialized responsibilities necessitated by magic, such as managing magical incidents and licensing specialized tools. The Order is neither purely heroic nor villainous; public perception varies widely depending on local citizens\' experiences.',
    discovered: false,
    relatedEntryIds: ['places_book_two', 'documents_five_rules'],
    iconName: 'Award'
  },

  // --- PLACES ---
  {
    id: 'places_outpost',
    title: 'The Academy Outpost (Book I)',
    category: 'Places',
    summary: 'The fortified threshold between the untamed wilds and the inner Academy sanctuaries.',
    detailedText: 'Nestled between primeval forest and ancient stone cliffs, the Outpost serves as the first filter for travelers, scholars, and initiates. Cobblestone courtyards, resonant flowerbeds, and guardian lanterns create a peaceful yet disciplined atmosphere where arithmetic balance keeps wild anomalies at bay. It represents Book I: Foundations of Mathematics, where the element is Ice and the ailment is Bleed.',
    discovered: true,
    discoveryDate: 'Arrival in MATHBOUND',
    relatedEntryIds: ['people_oron', 'places_sanctum', 'objects_gate', 'places_book_one'],
    iconName: 'Compass'
  },
  {
    id: 'places_four_books',
    title: 'The Four-Book Mainline',
    category: 'Places',
    summary: 'The overarching architectural progression of MATHBOUND\'s four major volumes.',
    detailedText: 'The Chronicles span four progressive Books:\n• Book I — Foundations: The Magical Academy (Grades 1–6, Ice / Bleed)\n• Book II — Mastery: The Solarpunk Metropolis (Grades 7–10, Fire / Poison)\n• Book III — Synthesis & Relations: Senior Mathematics (Grades 11–12, World: Open)\n• Book IV — The Finale: Culmination of Discovery & The Unfinished Chronicle.',
    discovered: true,
    discoveryDate: 'Chronicle Overview',
    relatedEntryIds: ['places_book_one', 'places_book_two', 'documents_creator_mystery'],
    iconName: 'Layers'
  },
  {
    id: 'places_book_one',
    title: 'Book I — Foundations (The Academy)',
    category: 'Places',
    summary: 'The domain representing Mathematics as something being systematically learned.',
    detailedText: 'Book I takes place within the Fantasy Mathematical Academy. Its elemental affinity is Ice, and its associated ailment is Bleed. Here, classrooms, lecture halls, courtyards, and crystalline structures teach foundational number sense, geometric sequences, and the distinction between perception and reality.',
    discovered: true,
    discoveryDate: 'Book I Opening',
    relatedEntryIds: ['places_outpost', 'places_book_two', 'words_cra'],
    iconName: 'MapPin'
  },
  {
    id: 'places_book_two',
    title: 'Book II — Mastery (The Metropolis)',
    category: 'Places',
    summary: 'The domain representing Mathematics as something being actively used across civilization.',
    detailedText: 'Book II shifts from learning to application. Set in the sprawling Mathematical Metropolis, it embodies mathematics embedded in transit systems, energy networks, statistics, and commerce. Its elemental affinity is Fire, and its associated ailment is Poison.',
    discovered: false,
    relatedEntryIds: ['places_book_one', 'people_the_order'],
    iconName: 'MapPin'
  },
  {
    id: 'places_sanctum',
    title: 'The Sequence Sanctum',
    category: 'Places',
    summary: 'An enclosed combat trial arena paving the path to the Grand Archive.',
    detailedText: 'A circular stone chamber paved with inscribed square tiles. The ambient magical ley lines converge here, allowing the Sequence Warden to summon elemental pulses along structured coordinate lines.',
    discovered: false,
    relatedEntryIds: ['people_warden', 'objects_warden_sigil'],
    iconName: 'MapPin'
  },

  // --- DOCUMENTS ---
  {
    id: 'documents_five_rules',
    title: 'The Five Foundational Rules',
    category: 'Documents',
    summary: 'The sacred conditions of exploration spoken by the unknown voice upon arrival.',
    detailedText: '1. "What you see, you can understand. What you cannot see, you must question." (Perception)\n2. "What you believe may be true. It may also be wrong." (Doubt)\n3. "Question what you know. Question what you don\'t know." (Question)\n4. "The unknown is not something to fear. It is something to uncover." (Discovery)\n5. "Open your minds, have fun... and let\'s find out." (Invitation)',
    discovered: true,
    discoveryDate: 'Arrival Decree',
    relatedEntryIds: ['people_samantha', 'people_miguel', 'documents_creator_mystery'],
    documentQuestions: {
      isItReal: 'Heard universally by both children upon their transition into MATHBOUND. It leaves no physical parchment, but the stones themselves echo its cadence.',
      whatDoesItMean: 'It establishes that understanding is an open, iterative journey. Failure and doubt are natural steps toward insight, not weaknesses.',
      whatCanItTellUs: 'The world of MATHBOUND is not an exam room; it is an interconnected reality that invites curiosity and welcomes questioning.'
    },
    iconName: 'Scroll'
  },
  {
    id: 'documents_creator_mystery',
    title: 'The Creator & The Unfinished Chronicle',
    category: 'Documents',
    summary: 'Philosophical observations concerning the origin of the Chronicles and the Creator.',
    detailedText: 'Citizens of MATHBOUND hold varied beliefs about the Creator—some revere it as an ancient deity, others view it as the natural architecture of reality. In truth, the Creator is an abstract representation of Mathematics itself and the endlessness of discovery. At the end of the known journey rests an unfinished Book with a resting quill, symbolizing that humanity can record what it discovers, but can never finish discovery itself: there is always more to discover.',
    discovered: false,
    relatedEntryIds: ['documents_five_rules', 'documents_inscription'],
    documentQuestions: {
      isItReal: 'References exist across ancient treatises and the final pages of the Chronicles.',
      whatDoesItMean: 'The Creator does not rule like a king or hand down prophecies. The Creator represents the infinite horizon of human inquiry.',
      whatCanItTellUs: 'Samantha and Miguel\'s journey will not end with a final closed door, but with the realization that discovery continues indefinitely.'
    },
    iconName: 'BookOpen'
  },
  {
    id: 'documents_inscription',
    title: 'The Inscription of Rhythms',
    category: 'Documents',
    summary: 'Ancient chisel marks engraved across the lintel of the Silent Gate.',
    detailedText: '"When darkness clouds the threshold, look not to strength, but to the ratio of increase. What was two becomes four, what was four doubles once more. Feed the stone its true succession, and the path shall yield."',
    mathematicalConcept: {
      topic: 'Geometric Progression',
      rule: 'Each subsequent value equals the preceding term multiplied by the common ratio r = 2.',
      formula: 'a_n = a_1 · 2^(n-1)',
      explanation: 'In a geometric sequence, the ratio between consecutive terms is constant. When the ratio is 2, the growth is exponential doubling: 2, 4, 8, 16, 32, 64.',
      concreteExample: '1 rune stone splits into 2, 2 split into 4, 4 into 8, 8 into 16, 16 into 32, and 32 into 64.'
    },
    discovered: false,
    relatedEntryIds: ['objects_gate', 'words_geometric', 'words_cra'],
    documentQuestions: {
      isItReal: 'The chisel depth, mineral weathering, and resonant aura match authentic Third-Age Academy masonry.',
      whatDoesItMean: 'The riddle describes a sequence defined by repeated multiplication (r = 2). The lock mechanism requires completing this doubling sequence.',
      whatCanItTellUs: 'The builders expected scholars to understand exponential scaling rather than guessing numbers at random.'
    },
    iconName: 'FileText'
  },
  {
    id: 'documents_caretaker_ledger',
    title: 'Caretaker\'s Outpost Ledger',
    category: 'Documents',
    summary: 'Handwritten observations of shifting rune frequencies.',
    detailedText: 'Entry 442: "The main gate locked up again this morning after the dawn tremor. The fourth rune socket flickers empty. The Pattern Wisps outside have grown agitated, mirroring the sequence steps in their movement vectors."',
    discovered: false,
    relatedEntryIds: ['people_oron', 'objects_gate', 'objects_wisp_core'],
    documentQuestions: {
      isItReal: 'Written in Oron\'s handwriting in dark ink on coarse parchment; smudges indicate recent inspection at the gate mechanism.',
      whatDoesItMean: 'The disruption was caused by an energy fault rather than enemy invasion; the missing rune broke the continuous circuit of the sequence.',
      whatCanItTellUs: 'Restoring the missing rune tile will re-establish the harmonic circuit and safely open the gate.'
    },
    iconName: 'BookOpen'
  },
  {
    id: 'documents_axiom',
    title: 'The Axiom of Growth',
    category: 'Documents',
    summary: 'A pristine parchment excerpt preserved from Master Valerius\'s manuscripts.',
    detailedText: '"Observe the differences between terms. If the gap is constant, addition governs the path. If the ratio of consecutive terms is identical, multiplication commands the realm."',
    mathematicalConcept: {
      topic: 'Arithmetic vs. Geometric Sequences',
      rule: 'Comparing first-order differences (d = a_{n} - a_{n-1}) versus quotients (r = a_n / a_{n-1}).',
      formula: 'Arithmetic: a_n = a_1 + (n-1)d | Geometric: a_n = a_1 · r^(n-1)',
      explanation: 'Determining whether a pattern adds or multiplies is the foundational step of sequence classification.',
      concreteExample: '+3 pattern: 3, 6, 9, 12, 15... vs ×2 pattern: 3, 6, 12, 24, 48...'
    },
    discovered: false,
    relatedEntryIds: ['words_geometric', 'words_arithmetic'],
    documentQuestions: {
      isItReal: 'An authorized parchment copy bearing the seal of the Grand Archive of Infinite Knowledge.',
      whatDoesItMean: 'It provides a systematic test method: always calculate the difference first; if irregular, test the quotient.',
      whatCanItTellUs: 'This rule unlocks every mechanism in the outpost without guesswork.'
    },
    iconName: 'Scroll'
  },

  // --- OBJECTS ---
  {
    id: 'objects_gate',
    title: 'The Patterned Gate',
    category: 'Objects',
    summary: 'A towering stone portal locked by four interlocking sequence slots.',
    detailedText: 'Carved from monolithic granite and veined with azure lapis lazuli, this portal bars the path between the Outpost Courtyard and the Sequence Sanctum. It will only swing open when the energy sequence matches the resonant frequency inscribed in its runic sockets.',
    discovered: false,
    relatedEntryIds: ['documents_inscription', 'words_geometric'],
    iconName: 'DoorClosed'
  },
  {
    id: 'objects_focus',
    title: 'Resonant Focus (Magical Interface)',
    category: 'Objects',
    summary: 'A scholar wand serving as an interface to communicate intentions to magical reality.',
    detailedText: 'Humans do not have internal mana pools or battery organs. The Resonant Focus is an interface that translates mental ENVISION into formal mathematical COMMAND. Magical entities in the environment interpret this command and generate the physical response.',
    discovered: true,
    discoveryDate: 'Starting Tool',
    relatedEntryIds: ['words_two_table_magic', 'words_telegraph'],
    iconName: 'Sparkles'
  },
  {
    id: 'objects_wisp_core',
    title: 'Wisp Essence Core',
    category: 'Objects',
    summary: 'A glowing polyhedral crystal recovered from a quelled Pattern Wisp.',
    detailedText: 'A geometric crystal that pulses with gentle emerald luminescence. Scholars use these cores to recharge vital health and stabilize harmonic mechanisms.',
    discovered: false,
    relatedEntryIds: ['people_oron', 'places_outpost'],
    iconName: 'Gem'
  },
  {
    id: 'objects_warden_sigil',
    title: 'Warden\'s Resonance Sigil',
    category: 'Objects',
    summary: 'Master key and symbol of mathematical competence granted by the Warden.',
    detailedText: 'A heavy brass emblem engraved with an interlocking Fibonacci spiral and geometric polygons. Carrying this sigil grants passage through all regional gates and identifies the bearer as an acknowledged scholar of the Infinite Knowledge.',
    discovered: false,
    relatedEntryIds: ['people_warden', 'places_sanctum'],
    iconName: 'Key'
  },

  // --- WORDS ---
  {
    id: 'words_magic_sprites',
    title: 'Magic Sprites (Living Manifestations)',
    category: 'Words',
    summary: 'Living creatures that manifest ambient magical properties and inhabit specific habitats.',
    detailedText: 'Magic Sprites are living manifestations of natural magical properties in MATHBOUND. In Book I, Frost Pattern Sprites inhabit the cold crystal pine groves, moving in geometric orbital cadences. They are not mindless monsters; they possess distinct temperaments. When scholars communicate with them through understanding rather than brute force, their agitated oscillations stabilize, deepening the scholar\'s capacity for spellcasting.',
    mathematicalConcept: {
      topic: 'Living Mathematical Manifestations',
      rule: 'Properties of environment ↔ Biological manifestation ↔ Harmonic communication.',
      explanation: 'Sprites embody the principle that magic and mathematics are part of the living fabric of reality.',
      concreteExample: 'Observing a Frost Sprite\'s 3-step orbital rhythm reveals the safe pause in its cadence.'
    },
    discovered: true,
    discoveryDate: 'Book I Codex',
    relatedEntryIds: ['objects_wisp_core', 'words_two_table_magic'],
    iconName: 'Sparkles'
  },
  {
    id: 'words_progression_hierarchy',
    title: 'Progression Hierarchy: Book, Volume, Chapter',
    category: 'Words',
    summary: 'The tripartite structural framework governing story milestones and trials.',
    detailedText: 'In MATHBOUND, all progression culminates through three nested milestones:\n• CHAPTER → ELITE: Focuses on the chapter\'s developing mathematical idea (e.g. The Sequence Warden testing geometric progression).\n• VOLUME → SUB-BOSS: Synthesizes multiple related competencies across a thematic cluster.\n• BOOK → BOSS: Culminates the overarching grade band and world trial.',
    mathematicalConcept: {
      topic: 'Modular Progression Framework',
      rule: 'Chapter Elite ⊂ Volume Sub-boss ⊂ Book Boss',
      explanation: 'Encounters provide narrative and mathematical significance rather than merely functioning as artificial roadblocks.',
      concreteExample: 'Mastering doubling patterns in Chapter 1 prepares scholars for multi-dimensional spatial trials in subsequent volumes.'
    },
    discovered: true,
    discoveryDate: 'Academy Guidelines',
    relatedEntryIds: ['places_four_books', 'people_warden'],
    iconName: 'Layers'
  },
  {
    id: 'words_two_table_magic',
    title: 'Two-Table Command System',
    category: 'Words',
    summary: 'The canonical structure through which humans interact with magical reality.',
    detailedText: 'Magic consists of two paired tables: Left Side (ENVISION — what the caster intends conceptually) and Right Side (COMMAND — how that intention is formally communicated to reality). The complete sequence is: ENVISION → COMMAND → MAGICAL INTERPRETATION → RESPONSE. Reality constrains vision: wishing for something does not force reality to obey if the command or properties are inconsistent.',
    mathematicalConcept: {
      topic: 'Formal Communication Model',
      rule: 'Vision → Command → Interpretation → Response',
      explanation: 'A vision does not determine reality. Reality determines what a vision can become.',
      concreteExample: 'Envision: Radial shockwave -> Command: RADIAL_EXPAND(r=120) -> Entity response: Harmonic Wave.'
    },
    discovered: true,
    discoveryDate: 'Canonical Law',
    relatedEntryIds: ['objects_focus', 'documents_five_rules'],
    iconName: 'Activity'
  },
  {
    id: 'words_geometric',
    title: 'Geometric Sequence',
    category: 'Words',
    summary: 'A progression of numbers where each term is produced by multiplying by a constant factor.',
    detailedText: 'In mathematics, a geometric progression is a sequence of non-zero numbers where each term after the first is found by multiplying the previous one by a fixed, non-zero number called the common ratio.',
    mathematicalConcept: {
      topic: 'Geometric Progression Definition',
      rule: 'Multiply the preceding number by the common ratio r.',
      formula: 'a_n = a_1 · r^(n-1)',
      explanation: 'Geometric sequences appear across nature in cell division, tree branching, acoustic octave frequencies, and financial compound interest.',
      concreteExample: 'Start with 2, multiply by 3: 2, 6, 18, 54, 162...'
    },
    discovered: false,
    relatedEntryIds: ['documents_inscription', 'words_arithmetic'],
    iconName: 'Hash'
  },
  {
    id: 'words_arithmetic',
    title: 'Arithmetic Progression',
    category: 'Words',
    summary: 'A sequence where the difference between any two consecutive terms is constant.',
    detailedText: 'An arithmetic progression (or arithmetic sequence) is a sequence of numbers such that the difference between consecutive terms is constant, known as the common difference d.',
    mathematicalConcept: {
      topic: 'Arithmetic Progression Definition',
      rule: 'Add the common difference d to the preceding term.',
      formula: 'a_n = a_1 + (n-1)d',
      explanation: 'Represents steady linear growth, such as measuring steps, uniform distance intervals, or steady clock ticks.',
      concreteExample: 'Start with 5, add 4: 5, 9, 13, 17, 21...'
    },
    discovered: false,
    relatedEntryIds: ['words_geometric'],
    iconName: 'Layers'
  },
  {
    id: 'words_cra',
    title: 'Concrete–Representational–Abstract',
    category: 'Words',
    summary: 'The three-phase pedagogical pipeline for enduring mathematical insight.',
    detailedText: 'The CRA instructional model guides a learner from tactile manipulation of physical objects (Concrete), to visual diagrams and models (Representational), and finally to symbolic notation and generalized equations (Abstract). MATHBOUND anchors every puzzle in this progression.',
    mathematicalConcept: {
      topic: 'Pedagogical Framework',
      rule: 'Hands-on tokens -> Visual charts/diagrams -> Algebraic formulae.',
      explanation: 'By experiencing the concept across all three modalities, understanding becomes intuitive, transferable, and resilient to anxiety.',
      concreteExample: 'Holding 4 coins -> Drawing 4 dots on paper -> Writing the digit "4".'
    },
    discovered: true,
    discoveryDate: 'Academy Handbook',
    relatedEntryIds: ['documents_inscription'],
    iconName: 'GraduationCap'
  },
  {
    id: 'words_telegraph',
    title: 'Algorithmic Telegraph',
    category: 'Words',
    summary: 'The visual forewarning of enemy actions based on predictable geometric rhythm.',
    detailedText: 'In top-down tactical combat, an enemy telegraph communicates impending danger zones before damage is dealt. In MATHBOUND, telegraphs follow mathematically predictable durations and geometric safe vectors, allowing calm observation to defeat frantic button-mashing.',
    discovered: true,
    discoveryDate: 'Academy Handbook',
    relatedEntryIds: ['people_warden'],
    iconName: 'Activity'
  }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: 'tool_focus',
    name: 'Resonant Focus (Topaz)',
    type: 'TOOL',
    description: 'Scholar wand interface for communicating intentions to ambient magic (Press J or Left-Click).',
    quantity: 1,
    icon: 'Sparkles'
  },
  {
    id: 'item_elixir',
    name: 'Elixir of Clarity',
    type: 'CONSUMABLE',
    description: 'Ancient herbal brew that restores 45 HP and calms mathematical anxiety.',
    quantity: 3,
    icon: 'FlaskRound',
    effect: 'HEAL',
    effectValue: 45
  },
  {
    id: 'item_chalk',
    name: 'Scholar\'s Chalk',
    type: 'TOOL',
    description: 'Enchanted chalk used to draw geometric proofs and highlight floor runes.',
    quantity: 1,
    icon: 'Edit3',
    effect: 'REVEAL_HINT'
  }
];

export const INITIAL_QUEST: Quest = {
  id: 'THE_SILENT_GATE',
  title: 'The Silent Gate',
  summary: 'Investigate the locked academy gate in Book I: Foundations, decode its geometric doubling sequence, quell the agitated wisps, and prove your insight to the Sequence Warden.',
  stage: 'TALK_TO_CARETAKER',
  objectives: [
    {
      stage: 'TALK_TO_CARETAKER',
      description: 'Speak with Caretaker Oron in the Academy Outpost courtyard.',
      completed: false
    },
    {
      stage: 'INSPECT_GATE',
      description: 'Inspect the ancient Patterned Gate at the northern courtyard border.',
      completed: false
    },
    {
      stage: 'SOLVE_PUZZLE',
      description: 'Arrange the rune sequence correctly to restore harmonic power to the gate.',
      completed: false
    },
    {
      stage: 'DEFEAT_WISPS',
      description: 'Clear the agitated Pattern Wisps pacing in the outer perimeter.',
      completed: false
    },
    {
      stage: 'DEFEAT_WARDEN',
      description: 'Confront the Sequence Warden in the Sanctum and decipher its cadence attacks.',
      completed: false
    },
    {
      stage: 'REPORT_TO_CARETAKER',
      description: 'Return to Caretaker Oron with the Warden\'s Resonance Sigil.',
      completed: false
    }
  ],
  rewards: {
    experience: 250,
    items: ['Warden\'s Resonance Sigil', 'Master Scholar\'s Compass'],
    archiveEntries: ['people_warden', 'objects_warden_sigil', 'places_sanctum']
  }
};
