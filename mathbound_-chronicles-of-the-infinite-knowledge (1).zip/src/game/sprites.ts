import { Direction } from '../types/game';

// Color Palette Constants from GDD
export const PALETTE = {
  inkNavy: '#202C46',
  archiveRed: '#B33A3A',
  warmGold: '#D9A441',
  parchment: '#F4F0E8',
  slateBlueGray: '#E8EDF3',
  forestGreen: '#527A67',
  bodyCharcoal: '#263238',
  grassGreen: '#4A7C59',
  grassHighlight: '#68A678',
  stoneDark: '#2E3842',
  stoneMid: '#4E5D6C',
  stoneLight: '#8091A5',
  cobble1: '#A09D95',
  cobble2: '#8C8981',
  woodBrown: '#6B4226',
  magicCyan: '#38BDF8',
  magicGold: '#FBBF24',
  dangerRed: 'rgba(179, 58, 58, 0.45)',
  dangerBorder: '#B33A3A'
};

// Procedural Sprite Drawing Utilities

export function drawPlayer(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  facing: Direction,
  walkFrame: number,
  isAttacking: boolean,
  isHurting: boolean,
  protagonist: 'SAMANTHA' | 'MIGUEL' = 'SAMANTHA'
) {
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  ctx.beginPath();
  ctx.ellipse(16, 28, 10, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  if (isHurting) {
    ctx.filter = 'brightness(2) drop-shadow(0 0 4px #B33A3A)';
  }

  const bounce = walkFrame % 2 === 1 ? -1 : 0;
  const isSamantha = protagonist === 'SAMANTHA';

  // Robe / Body
  ctx.fillStyle = isSamantha ? '#1E3A8A' : '#1E293B'; // Deep royal blue for Samantha, slate navy for Miguel
  ctx.fillRect(8, 14 + bounce, 16, 12);

  // Robe Trim (Sky Blue for Samantha, Warm Gold for Miguel)
  ctx.fillStyle = isSamantha ? '#38BDF8' : PALETTE.warmGold;
  ctx.fillRect(14, 14 + bounce, 4, 12);
  ctx.fillRect(8, 24 + bounce, 16, 2);

  // Legs / Boots
  ctx.fillStyle = '#0F172A';
  if (facing === 'left' || facing === 'right') {
    const legOffset = (walkFrame % 4) * 2 - 2;
    ctx.fillRect(10 + legOffset, 26, 4, 4);
    ctx.fillRect(18 - legOffset, 26, 4, 4);
  } else {
    const legOffset = (walkFrame % 2) * 2;
    ctx.fillRect(10, 26 + (legOffset ? 0 : -1), 4, 4);
    ctx.fillRect(18, 26 + (legOffset ? -1 : 0), 4, 4);
  }

  // Head / Skin
  ctx.fillStyle = '#FCD34D'; // Stylized skin
  ctx.fillRect(10, 6 + bounce, 12, 8);

  // Hair / Styling
  if (isSamantha) {
    // Samantha: Dark tied hair with cyan hairband, approx 4'11" proportion
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(8, 4 + bounce, 16, 4);
    ctx.fillRect(7, 6 + bounce, 3, 8); // Side bangs
    ctx.fillRect(22, 6 + bounce, 3, 8);
    // Hairband
    ctx.fillStyle = '#0284C7';
    ctx.fillRect(9, 4 + bounce, 14, 2);
  } else {
    // Miguel: Dark short textured hair, amber scarf, approx 5'4"
    ctx.fillStyle = '#18181B';
    ctx.fillRect(8, 3 + bounce, 16, 5);
    ctx.fillRect(8, 7 + bounce, 2, 5);
    ctx.fillRect(22, 7 + bounce, 2, 5);
  }

  // Face features based on facing
  ctx.fillStyle = '#0F172A';
  if (facing === 'down') {
    ctx.fillRect(12, 10 + bounce, 2, 2);
    ctx.fillRect(18, 10 + bounce, 2, 2);
    // Scarf knot
    ctx.fillStyle = isSamantha ? '#38BDF8' : PALETTE.archiveRed;
    ctx.fillRect(14, 13 + bounce, 4, 3);
  } else if (facing === 'up') {
    // Back of head
    ctx.fillStyle = isSamantha ? '#0F172A' : '#18181B';
    ctx.fillRect(10, 6 + bounce, 12, 8);
  } else if (facing === 'left') {
    ctx.fillRect(11, 10 + bounce, 2, 2);
    ctx.fillStyle = isSamantha ? '#38BDF8' : PALETTE.archiveRed;
    ctx.fillRect(10, 13 + bounce, 4, 3);
  } else if (facing === 'right') {
    ctx.fillRect(19, 10 + bounce, 2, 2);
    ctx.fillStyle = isSamantha ? '#38BDF8' : PALETTE.archiveRed;
    ctx.fillRect(18, 13 + bounce, 4, 3);
  }

  // Resonant Wand / Staff
  ctx.fillStyle = '#D97706'; // Wooden shaft
  let wandX = 24;
  let wandY = 10 + bounce;

  if (facing === 'left') {
    wandX = 4;
  }

  ctx.fillRect(wandX, wandY, 3, 14);
  // Crystal Gem Head
  ctx.fillStyle = PALETTE.magicCyan;
  ctx.fillRect(wandX - 1, wandY - 3, 5, 4);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(wandX, wandY - 2, 2, 2);

  // Arcane Attack Swirl
  if (isAttacking) {
    ctx.strokeStyle = PALETTE.magicCyan;
    ctx.lineWidth = 3;
    ctx.beginPath();
    if (facing === 'right') {
      ctx.arc(32, 16, 16, -Math.PI / 3, Math.PI / 3);
    } else if (facing === 'left') {
      ctx.arc(0, 16, 16, (2 * Math.PI) / 3, (4 * Math.PI) / 3);
    } else if (facing === 'up') {
      ctx.arc(16, 0, 16, (7 * Math.PI) / 6, (11 * Math.PI) / 6);
    } else {
      ctx.arc(16, 32, 16, Math.PI / 6, (5 * Math.PI) / 6);
    }
    ctx.stroke();

    // Arcane sparkle
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(facing === 'right' ? 36 : facing === 'left' ? -4 : 16, facing === 'up' ? -4 : facing === 'down' ? 36 : 16, 4, 4);
  }

  ctx.restore();
}

export function drawCaretaker(ctx: CanvasRenderingContext2D, x: number, y: number, idleTime: number) {
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));

  const bob = Math.sin(idleTime * 0.003) > 0 ? 0 : 1;

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  ctx.beginPath();
  ctx.ellipse(16, 28, 10, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  // Brown scholar robe
  ctx.fillStyle = '#4A3B32';
  ctx.fillRect(6, 12 + bob, 20, 16);

  // Red cowl
  ctx.fillStyle = PALETTE.archiveRed;
  ctx.fillRect(8, 12 + bob, 16, 5);

  // Beard (White)
  ctx.fillStyle = '#E2E8F0';
  ctx.fillRect(11, 14 + bob, 10, 8);
  ctx.fillRect(13, 22 + bob, 6, 3);

  // Face
  ctx.fillStyle = '#F6AD55';
  ctx.fillRect(10, 6 + bob, 12, 7);

  // Eyes & Eyebrows
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(10, 5 + bob, 4, 2);
  ctx.fillRect(18, 5 + bob, 4, 2);
  ctx.fillStyle = '#1A202C';
  ctx.fillRect(12, 8 + bob, 2, 2);
  ctx.fillRect(18, 8 + bob, 2, 2);

  // Lantern Staff
  ctx.fillStyle = '#92400E';
  ctx.fillRect(25, 6 + bob, 3, 22);

  // Glowing Lantern
  ctx.fillStyle = PALETTE.warmGold;
  ctx.fillRect(23, 2 + bob, 7, 7);
  ctx.fillStyle = '#FEF08A';
  ctx.fillRect(24, 3 + bob, 5, 5);

  // Lantern Glow
  const glow = 10 + Math.sin(idleTime * 0.005) * 2;
  const grad = ctx.createRadialGradient(26, 5 + bob, 2, 26, 5 + bob, glow);
  grad.addColorStop(0, 'rgba(254, 240, 138, 0.4)');
  grad.addColorStop(1, 'rgba(254, 240, 138, 0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(26, 5 + bob, glow, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

export function drawPatternWisp(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  time: number,
  isVulnerable: boolean,
  isHurting: boolean
) {
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));

  const floatY = Math.sin(time * 0.005) * 3;

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  ctx.beginPath();
  ctx.ellipse(16, 26, 8, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  if (isHurting) {
    ctx.filter = 'brightness(2.2)';
  }

  // Outer Aura
  const auraGrad = ctx.createRadialGradient(16, 14 + floatY, 2, 16, 14 + floatY, 14);
  auraGrad.addColorStop(0, isVulnerable ? 'rgba(234, 179, 8, 0.6)' : 'rgba(56, 189, 248, 0.6)');
  auraGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = auraGrad;
  ctx.beginPath();
  ctx.arc(16, 14 + floatY, 14, 0, Math.PI * 2);
  ctx.fill();

  // Core Diamond Body
  ctx.fillStyle = isVulnerable ? '#EAB308' : '#0284C7';
  ctx.beginPath();
  ctx.moveTo(16, 6 + floatY);
  ctx.lineTo(24, 14 + floatY);
  ctx.lineTo(16, 22 + floatY);
  ctx.lineTo(8, 14 + floatY);
  ctx.closePath();
  ctx.fill();

  // Bright Inner Core
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(14, 12 + floatY, 4, 4);

  // 3 Orbiting Geometric Motes (Sequence Pattern: 3 satellites!)
  for (let i = 0; i < 3; i++) {
    const angle = (time * 0.004) + (i * (Math.PI * 2 / 3));
    const dist = 12;
    const ox = 16 + Math.cos(angle) * dist;
    const oy = 14 + floatY + Math.sin(angle) * (dist * 0.6);

    ctx.fillStyle = isVulnerable ? '#FDE047' : '#38BDF8';
    ctx.fillRect(ox - 1.5, oy - 1.5, 3, 3);
  }

  // Vulnerability indicator banner
  if (isVulnerable) {
    ctx.font = 'bold 8px monospace';
    ctx.fillStyle = '#FBBF24';
    ctx.textAlign = 'center';
    ctx.fillText('STUNNED', 16, 2);
  }

  ctx.restore();
}

export function drawSequenceWarden(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  time: number,
  state: string,
  hp: number,
  maxHp: number,
  isHurting: boolean
) {
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.beginPath();
  ctx.ellipse(24, 44, 18, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  if (isHurting) {
    ctx.filter = 'brightness(2) drop-shadow(0 0 6px #B33A3A)';
  }

  const hoverY = Math.sin(time * 0.003) * 2;

  // Massive Golem Chassis (48x48 bounds)
  // Floating Shoulder Pauldron (Left)
  ctx.fillStyle = PALETTE.stoneDark;
  ctx.fillRect(4, 14 + hoverY, 10, 16);
  ctx.fillStyle = PALETTE.warmGold;
  ctx.fillRect(6, 16 + hoverY, 6, 3);

  // Floating Shoulder Pauldron (Right)
  ctx.fillStyle = PALETTE.stoneDark;
  ctx.fillRect(34, 14 + hoverY, 10, 16);
  ctx.fillStyle = PALETTE.warmGold;
  ctx.fillRect(36, 16 + hoverY, 6, 3);

  // Torso / Monolith Body
  ctx.fillStyle = PALETTE.stoneMid;
  ctx.fillRect(14, 10 + hoverY, 20, 26);
  ctx.strokeStyle = PALETTE.stoneDark;
  ctx.lineWidth = 2;
  ctx.strokeRect(14, 10 + hoverY, 20, 26);

  // Carved Inscriptions on Chest
  ctx.fillStyle = PALETTE.magicCyan;
  ctx.fillRect(20, 14 + hoverY, 8, 2);
  ctx.fillRect(23, 16 + hoverY, 2, 8);
  ctx.fillRect(18, 24 + hoverY, 12, 2);

  // Pulsing Central Core (The Fibonacci Heart)
  const coreGlow = (Math.sin(time * 0.006) + 1) * 0.5;
  ctx.fillStyle = state === 'RECOVERY' ? '#EAB308' : state === 'TELEGRAPH' ? '#EF4444' : '#06B6D4';
  ctx.beginPath();
  ctx.arc(24, 28 + hoverY, 5 + coreGlow * 2, 0, Math.PI * 2);
  ctx.fill();

  // Head / Runic Visor
  ctx.fillStyle = PALETTE.stoneDark;
  ctx.fillRect(16, 2 + hoverY, 16, 9);
  // Visor Eye Glow
  ctx.fillStyle = state === 'TELEGRAPH' ? '#F87171' : '#38BDF8';
  ctx.fillRect(18, 5 + hoverY, 12, 3);

  // Floating Runes Orbiting Head
  for (let i = 0; i < 4; i++) {
    const angle = (time * 0.002) + (i * (Math.PI / 2));
    const rx = 24 + Math.cos(angle) * 22;
    const ry = 18 + hoverY + Math.sin(angle) * 8;
    ctx.fillStyle = PALETTE.warmGold;
    ctx.fillRect(rx - 2, ry - 2, 4, 4);
  }

  // Recovery Stun Warning
  if (state === 'RECOVERY') {
    ctx.font = 'bold 9px monospace';
    ctx.fillStyle = '#F59E0B';
    ctx.textAlign = 'center';
    ctx.fillText('EXHAUSTED', 24, -4);
  }

  ctx.restore();
}

// Environmental Tile Drawing

export function drawGroundTile(ctx: CanvasRenderingContext2D, x: number, y: number, type: 'GRASS' | 'PATH' | 'SANCTUM_TILE' | 'WALL' | 'WATER') {
  if (type === 'GRASS') {
    ctx.fillStyle = PALETTE.grassGreen;
    ctx.fillRect(x, y, 32, 32);
    // Subtle blade dots
    ctx.fillStyle = PALETTE.grassHighlight;
    ctx.fillRect(x + 6, y + 8, 2, 4);
    ctx.fillRect(x + 20, y + 18, 2, 4);
    ctx.fillRect(x + 14, y + 26, 2, 3);
  } else if (type === 'PATH') {
    ctx.fillStyle = PALETTE.cobble1;
    ctx.fillRect(x, y, 32, 32);
    // Cobblestone outlines
    ctx.strokeStyle = PALETTE.cobble2;
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 2, y + 2, 12, 12);
    ctx.strokeRect(x + 16, y + 2, 14, 12);
    ctx.strokeRect(x + 2, y + 16, 14, 14);
    ctx.strokeRect(x + 18, y + 16, 12, 14);
  } else if (type === 'SANCTUM_TILE') {
    ctx.fillStyle = '#1E293B';
    ctx.fillRect(x, y, 32, 32);
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 1, y + 1, 30, 30);
    // Central geometric inlay
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(x + 10, y + 10, 12, 12);
    ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
    ctx.fillRect(x + 14, y + 14, 4, 4);
  } else if (type === 'WALL') {
    ctx.fillStyle = PALETTE.stoneDark;
    ctx.fillRect(x, y, 32, 32);
    // Stone brick lines
    ctx.fillStyle = PALETTE.stoneLight;
    ctx.fillRect(x, y, 32, 2);
    ctx.fillRect(x, y + 10, 32, 1);
    ctx.fillRect(x, y + 20, 32, 1);
    ctx.fillRect(x + 15, y, 1, 10);
    ctx.fillRect(x + 8, y + 10, 1, 10);
    ctx.fillRect(x + 24, y + 10, 1, 10);
    ctx.fillRect(x + 16, y + 20, 1, 12);
    // Ivy leaves
    ctx.fillStyle = '#2D6A4F';
    ctx.fillRect(x + 2, y + 4, 4, 4);
    ctx.fillRect(x + 5, y + 7, 3, 3);
  } else if (type === 'WATER') {
    ctx.fillStyle = '#1E40AF';
    ctx.fillRect(x, y, 32, 32);
    ctx.fillStyle = '#60A5FA';
    ctx.fillRect(x + 4, y + 10, 8, 2);
    ctx.fillRect(x + 18, y + 22, 10, 2);
  }
}

export function drawTree(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.translate(x, y);

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  ctx.beginPath();
  ctx.ellipse(24, 52, 16, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Trunk
  ctx.fillStyle = PALETTE.woodBrown;
  ctx.fillRect(20, 36, 8, 18);

  // Canopy layers
  ctx.fillStyle = '#2D5A27';
  ctx.beginPath();
  ctx.arc(24, 28, 20, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#408235';
  ctx.beginPath();
  ctx.arc(24, 20, 16, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#5CA64E';
  ctx.beginPath();
  ctx.arc(21, 14, 11, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

export function drawGate(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  isOpen: boolean,
  time: number
) {
  ctx.save();
  ctx.translate(x, y);

  // Gate Frame (Pillars left and right, archway top) - 96px wide x 64px tall
  ctx.fillStyle = PALETTE.stoneDark;
  // Left Pillar
  ctx.fillRect(0, 0, 20, 64);
  // Right Pillar
  ctx.fillRect(76, 0, 20, 64);
  // Arch lintel
  ctx.fillRect(0, 0, 96, 20);

  // Runic Arch Engravings
  ctx.fillStyle = isOpen ? '#38BDF8' : PALETTE.warmGold;
  ctx.fillRect(24, 6, 48, 8);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 8px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('4 · 8 · 16 · 32 · [?]', 48, 13);

  // Portcullis Bars
  if (!isOpen) {
    ctx.fillStyle = '#475569';
    for (let bx = 22; bx < 76; bx += 8) {
      ctx.fillRect(bx, 20, 4, 44);
    }
    // Crossbar
    ctx.fillRect(20, 38, 56, 4);

    // Central Glowing Rune Lock
    const pulse = (Math.sin(time * 0.005) + 1) * 0.5;
    ctx.fillStyle = PALETTE.archiveRed;
    ctx.beginPath();
    ctx.arc(48, 38, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#FEF08A';
    ctx.fillRect(45, 35, 6, 6);
  } else {
    // Open Gate passage glow
    ctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
    ctx.fillRect(20, 20, 56, 44);

    ctx.fillStyle = '#10B981';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('UNLOCKED', 48, 42);
  }

  ctx.restore();
}

export function drawObelisk(ctx: CanvasRenderingContext2D, x: number, y: number, time: number) {
  ctx.save();
  ctx.translate(x, y);

  // Shadow
  ctx.fillStyle = 'rgba(0,0,0,0.2)';
  ctx.beginPath();
  ctx.ellipse(12, 30, 10, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  // Stone Needle
  ctx.fillStyle = PALETTE.stoneMid;
  ctx.beginPath();
  ctx.moveTo(12, 2);
  ctx.lineTo(20, 28);
  ctx.lineTo(4, 28);
  ctx.closePath();
  ctx.fill();

  // Glowing Inscriptions
  const glow = (Math.sin(time * 0.004) + 1) * 0.5;
  ctx.fillStyle = `rgba(217, 164, 65, ${0.4 + glow * 0.5})`;
  ctx.fillRect(10, 10, 4, 2);
  ctx.fillRect(9, 14, 6, 2);
  ctx.fillRect(8, 18, 8, 2);

  ctx.restore();
}

export function drawChalkboard(ctx: CanvasRenderingContext2D, x: number, y: number, time: number) {
  ctx.save();
  ctx.translate(x, y);

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  ctx.beginPath();
  ctx.ellipse(18, 36, 14, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Wooden Easel Legs
  ctx.fillStyle = '#78350F';
  ctx.fillRect(4, 10, 4, 28);
  ctx.fillRect(28, 10, 4, 28);
  ctx.fillRect(16, 6, 4, 32);

  // Slate Board (32x24)
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(2, 4, 32, 22);
  ctx.strokeStyle = '#92400E';
  ctx.lineWidth = 2;
  ctx.strokeRect(2, 4, 32, 22);

  // Chalk Markings & Diagrams
  ctx.fillStyle = '#F8FAFC';
  ctx.font = 'bold 6px monospace';
  ctx.fillText('a_n = a_1·r', 6, 12);
  ctx.fillText('4 · 8 · 16 · ?', 5, 20);

  // Gentle chalk glow
  const glow = (Math.sin(time * 0.005) + 1) * 0.5;
  ctx.fillStyle = `rgba(56, 189, 248, ${0.2 + glow * 0.3})`;
  ctx.fillRect(22, 14, 8, 8);

  ctx.restore();
}

