import React, { useState, useEffect } from 'react';
import { soundManager } from '../audio/soundManager';
import { User, ChevronRight, Sparkles, MessageSquare } from 'lucide-react';
import { QuestStage } from '../types/game';

interface DialogueModalProps {
  npcId: string;
  questStage: QuestStage;
  protagonist?: import('../types/game').ProtagonistId;
  onAdvanceQuest: (nextStage: QuestStage) => void;
  onClose: () => void;
}

export const DialogueModal: React.FC<DialogueModalProps> = ({
  npcId,
  questStage,
  protagonist = 'SAMANTHA',
  onAdvanceQuest,
  onClose
}) => {
  const [dialogueIndex, setDialogueIndex] = useState(0);

  const isSamantha = protagonist === 'SAMANTHA';
  const name = isSamantha ? 'Samantha' : 'Miguel';
  const thinkingStyle = isSamantha ? 'meditative inquiry ("What does it mean?")' : 'calculative logic ("How does it work?")';

  // Content configuration based on NPC and current quest state
  const getDialogueScript = () => {
    if (npcId === 'npc_oron') {
      if (questStage === 'TALK_TO_CARETAKER' || questStage === 'NOT_STARTED') {
        return {
          speaker: 'Caretaker Oron',
          role: 'Groundskeeper of Book I: Foundations',
          avatarColor: 'bg-amber-600',
          lines: [
            `Ah, welcome to the Academy Outpost, ${name}! I heard the unknown voice echo across the stones as you arrived from Book I's engraving.`,
            `You brought no prophecies and no divine destiny—only your natural curiosity and your ${thinkingStyle}. That is the only true way anyone enters MATHBOUND.`,
            'A dawn tremor rippled across the courtyard. Look north—the Great Patterned Gate of Foundations has locked solid, and its harmonic circuit is fractured.',
            'Remember Rule 2 of the Five Rules: "What you believe may be true. It may also be wrong." Test your hypothesis against the stone sockets! The Digital Book [Tab] holds the Chronicle and Knowledge to guide you.'
          ],
          onComplete: () => onAdvanceQuest('INSPECT_GATE')
        };
      } else if (questStage === 'INSPECT_GATE' || questStage === 'SOLVE_PUZZLE') {
        return {
          speaker: 'Caretaker Oron',
          role: 'Groundskeeper of Book I: Foundations',
          avatarColor: 'bg-amber-600',
          lines: [
            'Have you examined the gate sockets yet? Look closely at the progression of values: 4, 8, 16, 32...',
            'Apply the Mathematical Discovery Loop: Observe, Question, Measure, Represent, Understand, Apply!',
            'Ask yourself: does the energy grow by adding a constant difference, or by multiplying by a constant factor?'
          ],
          onComplete: () => {}
        };
      } else if (questStage === 'DEFEAT_WISPS') {
        return {
          speaker: 'Caretaker Oron',
          role: 'Groundskeeper of the Academy Outpost',
          avatarColor: 'bg-amber-600',
          lines: [
            'By the Archons, the gate is open! You discovered the doubling ratio of 64!',
            'However, the sudden rush of harmonic resonance has energized the wild Pattern Wisps in the eastern grove.',
            'Observe their movement rhythms before striking. Each wisp telegraphs a danger zone, then becomes sluggish and vulnerable during recovery. Quell them with your Resonant Focus [J] or Wave Burst [K]!'
          ],
          onComplete: () => {}
        };
      } else if (questStage === 'DEFEAT_WARDEN') {
        return {
          speaker: 'Caretaker Oron',
          role: 'Groundskeeper of the Academy Outpost',
          avatarColor: 'bg-amber-600',
          lines: [
            'The wisps are calmed! Now, only one trial remains before the Grand Archive beyond.',
            'The Sequence Warden has awakened in the inner sanctum to test your tactical geometry.',
            'Watch its telegraphed cadence zones across the floor tiles. Stand in the safe pattern coordinates and strike while its core is exhausted. May mathematical clarity guide your wand!'
          ],
          onComplete: () => {}
        };
      } else if (questStage === 'REPORT_TO_CARETAKER') {
        return {
          speaker: 'Caretaker Oron',
          role: 'Groundskeeper of the Academy Outpost',
          avatarColor: 'bg-amber-600',
          lines: [
            'You hold the Warden\'s Resonance Sigil! Incredible! You have demonstrated true mastery over exponential patterns and tactical geometry.',
            'The entire Outpost acknowledges your achievement. The path to the Grand Infinite Library is now open.',
            'Accept this commendation into your Historian\'s Archive. You have proven that mathematics is not merely calculation, but the living architecture of our world!'
          ],
          onComplete: () => onAdvanceQuest('COMPLETED')
        };
      } else if (questStage === 'COMPLETED') {
        return {
          speaker: 'Caretaker Oron',
          role: 'Groundskeeper of the Academy Outpost',
          avatarColor: 'bg-amber-600',
          lines: [
            `Peace has returned to the Academy Outpost, ${name}! The Great Patterned Gate hums in perfect resonance at ratio 2.`,
            'Take your time exploring the Outpost. You can review your mathematical hypotheses at the Scholastic Blackboard, study the Five Rules, or browse the Historian\'s Archive [Tab].',
            'Beyond the northern sanctum lies the vast expanse of the Grand Infinite Library. Whenever you are ready, continue your journey!'
          ],
          onComplete: () => {}
        };
      }
    }

    return {
      speaker: 'Mysterious Inscription',
      role: 'Ancient Stone Lore',
      avatarColor: 'bg-slate-700',
      lines: [
        'An ancient text carved in stone.',
        'It speaks of numbers as living patterns across time and space.'
      ],
      onComplete: () => {}
    };
  };

  const script = getDialogueScript();

  // Play sound on line change
  useEffect(() => {
    soundManager.playDialogueChirp();
  }, [dialogueIndex]);

  const handleNext = () => {
    soundManager.playDialogueChirp();
    if (dialogueIndex < script.lines.length - 1) {
      setDialogueIndex(prev => prev + 1);
    } else {
      script.onComplete();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center pb-8 px-4 bg-black/60 backdrop-blur-[2px] select-none font-sans">
      <div className="bg-slate-900 border-2 border-amber-500/70 rounded-2xl max-w-2xl w-full p-5 shadow-2xl flex flex-col gap-3 text-white animate-slide-up">
        {/* Speaker Profile Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl ${script.avatarColor} border-2 border-amber-400 flex items-center justify-center text-white shadow-md`}>
              <User className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-amber-300 flex items-center gap-1.5">
                {script.speaker}
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </h3>
              <p className="text-[11px] text-slate-400">{script.role}</p>
            </div>
          </div>

          <div className="text-[11px] font-mono text-slate-400">
            {dialogueIndex + 1} / {script.lines.length}
          </div>
        </div>

        {/* Dialogue Speech Body */}
        <div className="py-2 min-h-[72px] text-sm text-slate-200 leading-relaxed font-serif">
          {script.lines[dialogueIndex]}
        </div>

        {/* Continue Action Button */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
          <span className="text-[10px] font-mono text-slate-400">
            Press <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 text-slate-300">Space</kbd> or <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 text-slate-300">Enter</kbd>
          </span>

          <button
            onClick={handleNext}
            className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md"
          >
            {dialogueIndex < script.lines.length - 1 ? (
              <>
                Next
                <ChevronRight className="w-4 h-4" />
              </>
            ) : (
              'Accept & Close'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
