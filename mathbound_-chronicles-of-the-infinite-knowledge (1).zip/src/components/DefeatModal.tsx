import React from 'react';
import { soundManager } from '../audio/soundManager';
import { Heart, RotateCcw, Shield, Sparkles, HelpCircle } from 'lucide-react';
import { ProtagonistId } from '../types/game';

interface DefeatModalProps {
  protagonist: ProtagonistId;
  onRecover: () => void;
}

export const DefeatModal: React.FC<DefeatModalProps> = ({
  protagonist,
  onRecover
}) => {
  const isSamantha = protagonist === 'SAMANTHA';
  const name = isSamantha ? 'Samantha' : 'Miguel';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-red-500/80 rounded-3xl max-w-lg w-full p-6 shadow-2xl flex flex-col items-center gap-4 text-white text-center animate-scale-in">
        {/* Heart Icon */}
        <div className="w-14 h-14 rounded-2xl bg-red-950/60 border-2 border-red-500 flex items-center justify-center text-red-400 shadow-xl shadow-red-500/20">
          <Heart className="w-7 h-7 fill-current" />
        </div>

        <div>
          <span className="text-[10px] font-mono uppercase tracking-widest text-red-400 font-bold block mb-1">
            ACADEMY PROTECTIVE WARD ACTIVATED
          </span>
          <h2 className="text-2xl font-black text-slate-100">
            Vitality Exhausted
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto leading-relaxed">
            The mathematical resonance overwhelmed your physical stamina. Caretaker Oron's harmonic ward has shielded you from harm.
          </p>
        </div>

        {/* Foundational Philosophy Reminder (Rule 2 & Version 0.09) */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 text-left text-xs space-y-2 w-full">
          <div className="flex items-center gap-1.5 text-amber-300 font-bold font-mono text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Rule 2 of the Five Rules:
          </div>
          <p className="text-slate-200 italic font-serif">
            "What you believe may be true. It may also be wrong." Failure is not the opposite of discovery; it is a legitimate part of learning.
          </p>
        </div>

        {/* Tactical Guidance */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-left text-xs space-y-1.5 w-full">
          <span className="text-[10px] font-mono uppercase text-sky-400 font-bold block">
            Scholar\'s Tactical Recovery Advice:
          </span>
          <ul className="list-disc pl-4 space-y-1 text-slate-300 text-[11px]">
            <li><strong>Observe Telegraphs:</strong> Red hazard decals appear before attacks. Step out of marked zones before impact!</li>
            <li><strong>Exploit Recovery Windows:</strong> After attacking, enemies become sluggish and vulnerable for 2–3 seconds. Strike then!</li>
            <li><strong>Use Elixirs:</strong> Open your Satchel (<kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-200">I</kbd>) to drink Elixirs of Clarity (+45 HP).</li>
            <li><strong>Accessibility:</strong> Enable <em>Relaxed Learning Mode</em> in Settings (<kbd className="px-1 py-0.5 bg-slate-800 rounded text-slate-200">Esc</kbd>) for reduced damage.</li>
          </ul>
        </div>

        {/* Recover Button */}
        <button
          onClick={() => {
            soundManager.playPuzzleSuccess();
            onRecover();
          }}
          className="w-full py-3 px-5 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-red-500/20 active:scale-95 transition-all mt-1"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Recover Vitality at Outpost Checkpoint</span>
        </button>
      </div>
    </div>
  );
};
