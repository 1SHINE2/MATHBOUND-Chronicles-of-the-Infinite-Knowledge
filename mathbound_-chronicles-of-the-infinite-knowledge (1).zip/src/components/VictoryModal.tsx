import React from 'react';
import { soundManager } from '../audio/soundManager';
import { Trophy, Award, CheckCircle2, BookOpen, Compass, ArrowRight, RotateCcw } from 'lucide-react';

interface VictoryModalProps {
  onContinueExploring: () => void;
  onReturnToTitle: () => void;
  archiveCount: number;
  totalArchiveCount: number;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  onContinueExploring,
  onReturnToTitle,
  archiveCount,
  totalArchiveCount
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-amber-400 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-center text-white flex flex-col items-center gap-5 animate-scale-in">
        {/* Hero Trophy Icon */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-slate-950 shadow-xl shadow-amber-500/30">
          <Trophy className="w-8 h-8 fill-current" />
        </div>

        {/* Title */}
        <div>
          <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 font-bold block mb-1">
            VERTICAL SLICE PROTOTYPE ACCOMPLISHED
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500">
            The Silent Gate Restored!
          </h1>
          <p className="text-xs text-slate-300 mt-2 max-w-md mx-auto leading-relaxed">
            You deciphered the geometric doubling sequence, opened the ancient Academy Outpost gate, quelled the Pattern Wisps, and proved your insight to the Sequence Warden.
          </p>
        </div>

        {/* Milestone Accomplishments Grid */}
        <div className="w-full grid grid-cols-2 gap-3 text-left">
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col gap-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Pattern Solved
            </span>
            <span className="text-xs font-bold text-slate-200">Geometric Ratio (×2)</span>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col gap-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              Elite Trial
            </span>
            <span className="text-xs font-bold text-slate-200">Sequence Warden Bested</span>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col gap-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5 text-sky-400" />
              Historian\'s Archive
            </span>
            <span className="text-xs font-bold text-slate-200">{archiveCount} / {totalArchiveCount} Discovered</span>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex flex-col gap-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase flex items-center gap-1">
              <Compass className="w-3.5 h-3.5 text-purple-400" />
              Academic Status
            </span>
            <span className="text-xs font-bold text-amber-300">Junior Geometer</span>
          </div>
        </div>

        {/* Next Chapter Teaser from GDD */}
        <div className="w-full bg-amber-500/10 border border-amber-500/30 rounded-xl p-3.5 text-left text-xs space-y-1">
          <div className="font-bold text-amber-300 flex items-center gap-1.5 font-mono text-[11px]">
            <span>Next Journey: Chapter 2 — The Solarpunk Metropolis</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Green rooftops, solar transit systems, and multi-tier energy networks awaiting algebraic modeling and spatial optimization.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col sm:flex-row gap-2.5 pt-2">
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onContinueExploring();
            }}
            className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            Continue Exploring
          </button>

          <button
            onClick={() => {
              soundManager.playTileSnap();
              onReturnToTitle();
            }}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all active:scale-95"
          >
            <span>Return to Menu</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
