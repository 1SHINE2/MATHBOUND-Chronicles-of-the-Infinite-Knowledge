import React, { useState } from 'react';
import { 
  ArchiveCategory, 
  ArchiveEntry, 
  ChronicleChapter, 
  DigitalBookLayer, 
  ProtagonistId 
} from '../types/game';
import { soundManager } from '../audio/soundManager';
import { 
  BookOpen, 
  Layers, 
  Sparkles, 
  X, 
  Search, 
  User, 
  MapPin, 
  FileText, 
  Hash, 
  Lock, 
  Link2, 
  HelpCircle, 
  Brain, 
  Compass, 
  CheckCircle2,
  Bookmark
} from 'lucide-react';

interface DigitalBookModalProps {
  initialLayer?: DigitalBookLayer;
  chapters: ChronicleChapter[];
  archiveEntries: ArchiveEntry[];
  protagonist: ProtagonistId;
  onClose: () => void;
}

export const DigitalBookModal: React.FC<DigitalBookModalProps> = ({
  initialLayer = 'CHRONICLE',
  chapters,
  archiveEntries,
  protagonist,
  onClose
}) => {
  const [activeLayer, setActiveLayer] = useState<DigitalBookLayer>(initialLayer);

  // Chronicle state
  const [selectedChapterId, setSelectedChapterId] = useState<string>(chapters[0]?.id || '');

  // Archive state
  const [selectedCategory, setSelectedCategory] = useState<ArchiveCategory | 'All'>('All');
  const [archiveSearch, setArchiveSearch] = useState('');
  const firstDiscovered = archiveEntries.find(e => e.discovered);
  const [selectedEntryId, setSelectedEntryId] = useState<string>(firstDiscovered ? firstDiscovered.id : archiveEntries[0]?.id);

  const categories: (ArchiveCategory | 'All')[] = ['All', 'People', 'Places', 'Documents', 'Objects', 'Words'];

  const getCategoryIcon = (category: ArchiveCategory) => {
    switch (category) {
      case 'People': return <User className="w-3.5 h-3.5 text-sky-400" />;
      case 'Places': return <MapPin className="w-3.5 h-3.5 text-emerald-400" />;
      case 'Documents': return <FileText className="w-3.5 h-3.5 text-amber-400" />;
      case 'Objects': return <Sparkles className="w-3.5 h-3.5 text-purple-400" />;
      case 'Words': return <Hash className="w-3.5 h-3.5 text-pink-400" />;
    }
  };

  const selectedChapter = chapters.find(c => c.id === selectedChapterId) || chapters[0];

  const filteredArchive = archiveEntries.filter(entry => {
    const matchCat = selectedCategory === 'All' || entry.category === selectedCategory;
    const matchQuery = archiveSearch === '' ||
      entry.title.toLowerCase().includes(archiveSearch.toLowerCase()) ||
      entry.summary.toLowerCase().includes(archiveSearch.toLowerCase());
    return matchCat && matchQuery;
  });

  const selectedEntry = archiveEntries.find(e => e.id === selectedEntryId);

  // Educational Knowledge entries extracted from discovered mathematical concepts
  const knowledgeEntries = archiveEntries.filter(e => e.mathematicalConcept);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl max-w-5xl w-full h-[90vh] shadow-2xl flex flex-col text-white overflow-hidden">
        {/* Top Header with Three Canonical Layers */}
        <div className="flex flex-col sm:flex-row items-center justify-between px-6 py-3.5 bg-slate-950 border-b border-slate-800 gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-md">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                Chronicles of the Infinite Knowledge
                <span className="text-[10px] font-mono font-normal text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  Book I: Foundations
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Experience the Story · Understand What Was Discovered · Explore What Exists
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
            {/* Three-Layer Segmented Selector */}
            <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-xl">
              <button
                onClick={() => {
                  soundManager.playTileSnap();
                  setActiveLayer('CHRONICLE');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  activeLayer === 'CHRONICLE'
                    ? 'bg-amber-600 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                1. Chronicle
              </button>
              <button
                onClick={() => {
                  soundManager.playTileSnap();
                  setActiveLayer('KNOWLEDGE');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  activeLayer === 'KNOWLEDGE'
                    ? 'bg-amber-600 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Brain className="w-3.5 h-3.5" />
                2. Knowledge
              </button>
              <button
                onClick={() => {
                  soundManager.playTileSnap();
                  setActiveLayer('ARCHIVE');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  activeLayer === 'ARCHIVE'
                    ? 'bg-amber-600 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                3. Archive
              </button>
            </div>

            <button
              onClick={() => {
                soundManager.playTileSnap();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* LAYER 1: CHRONICLE (Experience the Story) */}
        {activeLayer === 'CHRONICLE' && (
          <div className="flex-1 flex overflow-hidden">
            {/* Chapters Sidebar */}
            <div className="w-full sm:w-72 border-r border-slate-800 p-3 space-y-2 bg-slate-950/40 overflow-y-auto">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block px-2 mb-1">
                Story Progression & Chapters
              </span>
              {chapters.map(ch => (
                <button
                  key={ch.id}
                  onClick={() => {
                    soundManager.playTileSnap();
                    setSelectedChapterId(ch.id);
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex flex-col gap-1 ${
                    selectedChapterId === ch.id
                      ? 'bg-amber-500/15 border-amber-400/80 shadow-md'
                      : ch.unlocked
                      ? 'bg-slate-800/60 border-slate-800 hover:bg-slate-800'
                      : 'bg-slate-950/40 border-slate-900 opacity-50'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-amber-400">
                    <span>Chapter {ch.chapterNumber}</span>
                    {ch.unlocked ? (
                      <span className="text-emerald-400">Unlocked</span>
                    ) : (
                      <span className="text-slate-500">Locked</span>
                    )}
                  </div>
                  <h4 className="text-xs font-bold text-slate-100 truncate">{ch.title}</h4>
                  <span className="text-[10px] text-slate-400 truncate">{ch.subtitle}</span>
                </button>
              ))}
            </div>

            {/* Chapter Text Reading Pane */}
            <div className="hidden sm:flex flex-1 flex-col overflow-y-auto p-6 bg-slate-900 space-y-5">
              <div className="pb-4 border-b border-slate-800">
                <div className="text-xs font-mono text-amber-400 mb-1">
                  {selectedChapter.bookTitle} · Chapter {selectedChapter.chapterNumber}
                </div>
                <h2 className="text-2xl font-bold text-slate-100">{selectedChapter.title}</h2>
                <p className="text-xs text-slate-400 mt-1">{selectedChapter.subtitle}</p>
              </div>

              {/* Narrative Text */}
              <div className="space-y-3 font-serif text-slate-200 text-sm leading-relaxed max-w-2xl bg-slate-950/50 p-5 rounded-2xl border border-slate-800">
                {selectedChapter.narrativeText.map((paragraph, pIdx) => (
                  <p key={pIdx}>{paragraph}</p>
                ))}
              </div>

              {/* Key Story Milestone */}
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3.5 max-w-2xl flex items-center gap-3 text-xs">
                <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <span className="font-mono text-[10px] uppercase text-amber-400 block font-bold">Key Chronicle Milestone</span>
                  <span className="text-slate-200">{selectedChapter.keyEvent}</span>
                </div>
              </div>

              {/* Dual Perspective Reflections (Calculative vs Meditative) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl">
                <div className="p-3.5 bg-sky-950/30 border border-sky-800/40 rounded-xl space-y-1 text-xs">
                  <div className="flex items-center gap-1.5 text-sky-400 font-bold font-mono text-[11px]">
                    <Brain className="w-3.5 h-3.5" />
                    Samantha\'s Meditative Reflection
                  </div>
                  <p className="text-slate-300 italic font-serif">
                    {selectedChapter.protagonistReflection.samantha}
                  </p>
                </div>

                <div className="p-3.5 bg-amber-950/30 border border-amber-800/40 rounded-xl space-y-1 text-xs">
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold font-mono text-[11px]">
                    <Compass className="w-3.5 h-3.5" />
                    Miguel\'s Calculative Reflection
                  </div>
                  <p className="text-slate-300 italic font-serif">
                    {selectedChapter.protagonistReflection.miguel}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* LAYER 2: KNOWLEDGE (Understand What Was Discovered) */}
        {activeLayer === 'KNOWLEDGE' && (
          <div className="flex-1 overflow-y-auto p-6 bg-slate-900 space-y-6">
            <div className="pb-3 border-b border-slate-800">
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Brain className="w-5 h-5 text-amber-400" />
                The Knowledge Layer: Underlying Mathematical Structures
              </h3>
              <p className="text-xs text-slate-400">
                "Mathematics is the underlying structure through which reality in MATHBOUND can be understood." (Version 0.07)
              </p>
            </div>

            {/* The Discovery Loop Diagram */}
            <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-xs font-mono font-bold text-amber-400 uppercase">
                The Canonical Mathematical Discovery Loop:
              </span>
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-300 pt-1">
                {['Observe', 'Question', 'Measure', 'Represent', 'Understand', 'Apply', 'Discover', 'Question Again'].map((step, idx, arr) => (
                  <React.Fragment key={step}>
                    <span className="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-amber-300 font-bold">
                      {step}
                    </span>
                    {idx < arr.length - 1 && <span className="text-slate-500">→</span>}
                  </React.Fragment>
                ))}
              </div>
            </div>

            {/* Mathematical Knowledge Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {knowledgeEntries.map(entry => (
                <div key={entry.id} className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-amber-300">{entry.mathematicalConcept?.topic}</h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded">
                      {entry.category}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs">
                    <div className="p-2 bg-slate-900 rounded border border-slate-800">
                      <strong className="text-slate-400 block text-[10px] uppercase font-mono">Governing Rule</strong>
                      <span className="text-slate-200">{entry.mathematicalConcept?.rule}</span>
                    </div>

                    {entry.mathematicalConcept?.formula && (
                      <div className="p-2 bg-slate-900 rounded border border-slate-800">
                        <strong className="text-slate-400 block text-[10px] uppercase font-mono">Mathematical Formula</strong>
                        <span className="text-sky-300 font-mono font-bold">{entry.mathematicalConcept.formula}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed font-serif">
                    {entry.mathematicalConcept?.explanation}
                  </p>

                  <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                    <strong>Concrete Example:</strong> {entry.mathematicalConcept?.concreteExample}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LAYER 3: ARCHIVE (Explore What Exists Within the World) */}
        {activeLayer === 'ARCHIVE' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Category Filter & Search Bar */}
            <div className="px-6 py-2.5 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1 overflow-x-auto py-1">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => {
                      soundManager.playTileSnap();
                      setSelectedCategory(cat);
                    }}
                    className={`px-3 py-1 rounded-lg text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                      selectedCategory === cat
                        ? 'bg-amber-600 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {cat !== 'All' && getCategoryIcon(cat as ArchiveCategory)}
                    {cat}
                  </button>
                ))}
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={archiveSearch}
                  onChange={e => setArchiveSearch(e.target.value)}
                  placeholder="Search Archive..."
                  className="pl-8 pr-3 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-amber-400 w-48 sm:w-56"
                />
              </div>
            </div>

            {/* Split List & Details Pane */}
            <div className="flex-1 flex overflow-hidden">
              <div className="w-full sm:w-80 border-r border-slate-800 p-2.5 space-y-1.5 bg-slate-950/40 overflow-y-auto">
                {filteredArchive.map(entry => {
                  const isSelected = entry.id === selectedEntryId;
                  return (
                    <button
                      key={entry.id}
                      onClick={() => {
                        soundManager.playTileSnap();
                        setSelectedEntryId(entry.id);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-start gap-2.5 ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-400/80 shadow-md'
                          : entry.discovered
                          ? 'bg-slate-800/60 border-slate-800 hover:bg-slate-800'
                          : 'bg-slate-950/60 border-slate-900 opacity-60'
                      }`}
                    >
                      <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 shrink-0 mt-0.5">
                        {entry.discovered ? getCategoryIcon(entry.category) : <Lock className="w-3.5 h-3.5 text-slate-500" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-xs font-bold text-slate-200 truncate block">
                          {entry.discovered ? entry.title : 'Undiscovered Inscription'}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate block">{entry.category}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Detail Pane */}
              <div className="hidden sm:flex flex-1 flex-col overflow-y-auto p-6 bg-slate-900 space-y-5">
                {selectedEntry && selectedEntry.discovered ? (
                  <div className="space-y-5 max-w-2xl">
                    <div className="pb-3 border-b border-slate-800">
                      <div className="text-xs font-mono text-amber-400 mb-1 flex items-center gap-1.5">
                        {getCategoryIcon(selectedEntry.category)}
                        <span>{selectedEntry.category}</span>
                        <span>·</span>
                        <span className="text-slate-400">{selectedEntry.id}</span>
                      </div>
                      <h3 className="text-2xl font-bold text-slate-100">{selectedEntry.title}</h3>
                      <p className="text-xs text-amber-200/80 italic mt-1">{selectedEntry.summary}</p>
                    </div>

                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 font-serif text-slate-200 text-xs leading-relaxed">
                      {selectedEntry.detailedText}
                    </div>

                    {/* Document Inquiry */}
                    {selectedEntry.documentQuestions && (
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                          <HelpCircle className="w-3.5 h-3.5" />
                          Document Three-Question Inquiry
                        </h4>
                        <div className="space-y-1.5 text-xs">
                          <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                            <span className="font-semibold text-amber-300 block">1. Is it real?</span>
                            <span className="text-slate-300">{selectedEntry.documentQuestions.isItReal}</span>
                          </div>
                          <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                            <span className="font-semibold text-amber-300 block">2. What does it mean?</span>
                            <span className="text-slate-300">{selectedEntry.documentQuestions.whatDoesItMean}</span>
                          </div>
                          <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
                            <span className="font-semibold text-amber-300 block">3. What can it tell us?</span>
                            <span className="text-slate-300">{selectedEntry.documentQuestions.whatCanItTellUs}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-500 text-xs">
                    Select a discovered archive record to read its findings.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
