import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Play, RotateCcw, Settings, Info, BookOpen, Volume2, Shield } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface TitleScreenProps {
  onNewGame: () => void;
  onContinue: () => void;
  onOpenSettings: () => void;
  hasSaveData: boolean;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onNewGame,
  onContinue,
  onOpenSettings,
  hasSaveData
}) => {
  const [showConfirmNewGame, setShowConfirmNewGame] = useState(false);
  const [showCredits, setShowCredits] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Animated background for Title Screen
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const runes = [
      { x: 120, y: 180, speed: 0.6, char: 'ᚠ' },
      { x: 260, y: 280, speed: 0.4, char: 'ᚢ' },
      { x: 540, y: 160, speed: 0.5, char: 'ᚦ' },
      { x: 680, y: 240, speed: 0.7, char: 'ᚨ' },
      { x: 400, y: 320, speed: 0.3, char: 'ᚱ' }
    ];

    const leaves = Array.from({ length: 25 }, () => ({
      x: Math.random() * 800,
      y: Math.random() * 600,
      vx: 0.4 + Math.random() * 0.8,
      vy: 0.6 + Math.random() * 0.8,
      size: 3 + Math.random() * 3,
      color: Math.random() > 0.5 ? '#D9A441' : '#527A67'
    }));

    const render = () => {
      time += 0.02;
      ctx.clearRect(0, 0, 800, 600);

      // Deep Ink Navy gradient backdrop
      const bgGrad = ctx.createLinearGradient(0, 0, 0, 600);
      bgGrad.addColorStop(0, '#10172A');
      bgGrad.addColorStop(0.5, '#1E293B');
      bgGrad.addColorStop(1, '#0F172A');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 800, 600);

      // Distant Academy silhouette
      ctx.fillStyle = '#172033';
      // Academy spires
      ctx.beginPath();
      ctx.moveTo(320, 420);
      ctx.lineTo(360, 260);
      ctx.lineTo(400, 420);
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(390, 420);
      ctx.lineTo(440, 220);
      ctx.lineTo(490, 420);
      ctx.fill();

      // Forest silhouette
      ctx.fillStyle = '#1E293B';
      for (let x = 0; x < 800; x += 40) {
        ctx.beginPath();
        ctx.arc(x + 20, 480, 35, 0, Math.PI * 2);
        ctx.fill();
      }

      // Foreground Cobblestone courtyard
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 480, 800, 120);
      ctx.fillStyle = '#202C46';
      ctx.fillRect(0, 480, 800, 4);

      // Ancient Gate Archway Pillars in Foreground
      ctx.fillStyle = '#1A2234';
      ctx.fillRect(80, 280, 48, 220);
      ctx.fillRect(672, 280, 48, 220);
      ctx.fillRect(80, 280, 640, 32);

      // Lintel Runic Glow
      const runeGlow = (Math.sin(time) + 1) * 0.5;
      ctx.fillStyle = `rgba(217, 164, 65, ${0.3 + runeGlow * 0.4})`;
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('• 2 · 4 · 8 · 16 · 32 · 64 • AXIOM OF INFINITE HARMONY •', 400, 302);

      // Floating mystical runes
      runes.forEach(r => {
        const floatY = r.y + Math.sin(time * r.speed) * 12;
        ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
        ctx.font = '24px serif';
        ctx.fillText(r.char, r.x, floatY);
      });

      // Drifting leaves
      leaves.forEach(l => {
        l.x += l.vx;
        l.y += l.vy;
        if (l.x > 800) l.x = 0;
        if (l.y > 600) l.y = 0;

        ctx.fillStyle = l.color;
        ctx.beginPath();
        ctx.ellipse(l.x, l.y, l.size, l.size * 0.5, time, 0, Math.PI * 2);
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, []);

  const handleStartNewGame = () => {
    soundManager.playTileSnap();
    if (hasSaveData) {
      setShowConfirmNewGame(true);
    } else {
      onNewGame();
    }
  };

  const handleConfirmNewGame = () => {
    soundManager.playTileSnap();
    setShowConfirmNewGame(false);
    onNewGame();
  };

  const handleContinueGame = () => {
    if (!hasSaveData) {
      soundManager.playError();
      return;
    }
    soundManager.playTileSnap();
    onContinue();
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between bg-slate-950 text-white overflow-hidden select-none font-sans">
      {/* Background Canvas */}
      <canvas
        ref={canvasRef}
        width={800}
        height={600}
        className="absolute inset-0 w-full h-full object-cover pointer-events-none opacity-85"
      />

      {/* Vignette Overlay */}
      <div className="absolute inset-0 bg-radial from-transparent via-slate-950/40 to-slate-950/90 pointer-events-none" />

      {/* Header & Logo Section */}
      <div className="relative z-10 pt-10 text-center max-w-2xl px-4 animate-fade-in">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded text-amber-300 text-xs tracking-wider uppercase font-mono mb-3">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          INFINITE Club · Prototype v1.0
        </div>
        <h1 className="text-4xl md:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-amber-100 via-amber-300 to-amber-600 drop-shadow-md">
          MATHBOUND
        </h1>
        <p className="text-sm md:text-base text-slate-300 font-medium tracking-wide mt-1">
          Chronicles of the Infinite Knowledge
        </p>
        <p className="text-xs text-slate-400 italic mt-2 max-w-lg mx-auto">
          "When learning becomes an adventure, even the most challenging numbers lead to extraordinary discoveries."
        </p>
      </div>

      {/* Main Action Menu */}
      <div className="relative z-10 w-full max-w-sm px-6 flex flex-col gap-3 my-auto">
        {/* Continue Button */}
        <button
          onClick={handleContinueGame}
          disabled={!hasSaveData}
          className={`group flex items-center justify-between px-5 py-3.5 rounded-lg border text-sm font-semibold tracking-wide transition-all ${
            hasSaveData
              ? 'bg-gradient-to-r from-amber-600 to-amber-500 text-slate-950 border-amber-400 hover:from-amber-500 hover:to-amber-400 hover:scale-[1.02] shadow-lg shadow-amber-500/20 active:scale-[0.98]'
              : 'bg-slate-900/60 text-slate-500 border-slate-800 cursor-not-allowed opacity-60'
          }`}
        >
          <span className="flex items-center gap-3">
            <Play className={`w-4 h-4 ${hasSaveData ? 'fill-current text-slate-950' : 'text-slate-600'}`} />
            Continue Journey
          </span>
          {hasSaveData ? (
            <span className="text-[11px] font-mono px-2 py-0.5 bg-black/20 rounded text-slate-900">
              Checkpoint
            </span>
          ) : (
            <span className="text-[11px] font-mono text-slate-500">No Save</span>
          )}
        </button>

        {/* New Game Button */}
        <button
          onClick={handleStartNewGame}
          className="flex items-center justify-between px-5 py-3.5 rounded-lg border border-slate-700 bg-slate-900/90 text-slate-100 hover:bg-slate-800 hover:border-amber-400/50 hover:text-amber-300 text-sm font-semibold tracking-wide transition-all shadow-md active:scale-[0.98]"
        >
          <span className="flex items-center gap-3">
            <RotateCcw className="w-4 h-4 text-amber-400" />
            New Adventure
          </span>
          <span className="text-[11px] font-mono text-slate-400">Chapter 1</span>
        </button>

        {/* Settings Button */}
        <button
          onClick={() => {
            soundManager.playTileSnap();
            onOpenSettings();
          }}
          className="flex items-center justify-between px-5 py-3 rounded-lg border border-slate-800 bg-slate-900/80 text-slate-300 hover:bg-slate-800 hover:text-white text-sm font-medium transition-all active:scale-[0.98]"
        >
          <span className="flex items-center gap-3">
            <Settings className="w-4 h-4 text-slate-400" />
            Settings & Controls
          </span>
          <span className="text-[11px] font-mono text-slate-500">Audio · Controls</span>
        </button>

        {/* Credits & Lore Button */}
        <button
          onClick={() => {
            soundManager.playTileSnap();
            setShowCredits(true);
          }}
          className="flex items-center justify-between px-5 py-3 rounded-lg border border-slate-800 bg-slate-900/80 text-slate-300 hover:bg-slate-800 hover:text-white text-sm font-medium transition-all active:scale-[0.98]"
        >
          <span className="flex items-center gap-3">
            <Info className="w-4 h-4 text-slate-400" />
            Educational Brief & Credits
          </span>
          <span className="text-[11px] font-mono text-slate-500">GDD v1.0</span>
        </button>
      </div>

      {/* Footer System Badges */}
      <div className="relative z-10 pb-5 text-center text-xs text-slate-500 flex items-center justify-center gap-6">
        <span>Concrete · Representational · Abstract</span>
        <span>•</span>
        <span>Top-Down Pixel Exploration</span>
        <span>•</span>
        <span>Tactical Combat</span>
      </div>

      {/* Overwrite Save Confirmation Modal */}
      {showConfirmNewGame && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-amber-500/50 rounded-xl p-6 max-w-md w-full shadow-2xl text-center animate-scale-in">
            <h3 className="text-lg font-bold text-amber-300 mb-2">Overwrite Saved Journey?</h3>
            <p className="text-sm text-slate-300 mb-6">
              An active save file was detected. Starting a new adventure will reset your current quest milestones, Archive discoveries, and Outpost progression.
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setShowConfirmNewGame(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-sm font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmNewGame}
                className="px-5 py-2 rounded-lg bg-red-700 text-white hover:bg-red-600 text-sm font-semibold shadow-md"
              >
                Begin Fresh Game
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Credits & Design Brief Modal */}
      {showCredits && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 max-w-lg w-full max-h-[85vh] overflow-y-auto shadow-2xl text-left">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                MATHBOUND Project Overview
              </h3>
              <button
                onClick={() => setShowCredits(false)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              <p>
                <strong>MATHBOUND: Chronicles of the Infinite Knowledge</strong> is a story-driven educational fantasy RPG connecting mathematical reasoning with exploration, environmental puzzles, and real-time tactical combat.
              </p>
              <div>
                <h4 className="font-semibold text-amber-400 mb-1">Pillars of Design (GDD v1.0):</h4>
                <ul className="list-disc pl-5 space-y-1 text-slate-400">
                  <li><strong>Explore to Understand:</strong> Mathematical relationships govern the world's mechanisms.</li>
                  <li><strong>Concrete–Representational–Abstract (CRA):</strong> Manipulate physical tokens, view diagrams, deduce symbolic formulae.</li>
                  <li><strong>Safe Experimentation:</strong> Mistakes reveal informative clues rather than harsh punishments.</li>
                  <li><strong>Historian's Archive:</strong> Discoveries in People, Places, Documents, Objects, and Words persist for ongoing reference.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-amber-400 mb-1">Introductory Region: The Magical Academy Outpost</h4>
                <p className="text-slate-400">
                  You arrive as a newly enrolled scholar initiate. The Outpost's ancient sequence gate has lost its harmonic balance. Decode the geometric doubling ratio, solve the stone mechanism, master telegraphed combat against Pattern Wisps, and withstand the Sequence Warden's cadence trial.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800 text-slate-400 text-[11px] flex justify-between">
                <span>Prepared for INFINITE Club · October 2026</span>
                <span>Web-Game Vertical Slice</span>
              </div>
            </div>

            <button
              onClick={() => setShowCredits(false)}
              className="mt-6 w-full py-2.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider"
            >
              Return to Menu
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
