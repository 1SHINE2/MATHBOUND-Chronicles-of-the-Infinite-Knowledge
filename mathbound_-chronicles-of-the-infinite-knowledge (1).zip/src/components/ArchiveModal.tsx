import React, { useState } from 'react';
import { 
  ArchiveCategory, 
  ArchiveEntry 
} from '../types/game';
import { soundManager } from '../audio/soundManager';
import { 
  Search, 
  BookOpen, 
  User, 
  MapPin, 
  FileText, 
  Sparkles, 
  Hash, 
  X, 
  Link2, 
  Lock, 
  ShieldAlert, 
  GraduationCap, 
  Activity, 
  HelpCircle,
  Clock,
  ArrowUpDown
} from 'lucide-react';

interface ArchiveModalProps {
  entries: ArchiveEntry[];
  onClose: () => void;
  initialEntryId?: string;
}

export const ArchiveModal: React.FC<ArchiveModalProps> = ({
  entries,
  onClose,
  initialEntryId
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ArchiveCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'A-Z' | 'DISCOVERY'>('DISCOVERY');
  
  // Set initially selected entry
  const firstDiscovered = entries.find(e => e.discovered);
  const [selectedEntryId, setSelectedEntryId] = useState<string>(
    initialEntryId || (firstDiscovered ? firstDiscovered.id : entries[0]?.id)
  );

  const categories: (ArchiveCategory | 'All')[] = ['All', 'People', 'Places', 'Documents', 'Objects', 'Words'];

  const getCategoryIcon = (category: ArchiveCategory) => {
    switch (category) {
      case 'People': return <User className="w-4 h-4 text-sky-400" />;
      case 'Places': return <MapPin className="w-4 h-4 text-emerald-400" />;
      case 'Documents': return <FileText className="w-4 h-4 text-amber-400" />;
      case 'Objects': return <Sparkles className="w-4 h-4 text-purple-400" />;
      case 'Words': return <Hash className="w-4 h-4 text-pink-400" />;
    }
  };

  // Filter entries
  const filteredEntries = entries.filter(entry => {
    const matchesCategory = selectedCategory === 'All' || entry.category === selectedCategory;
    const matchesQuery = searchQuery === '' || 
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (entry.mathematicalConcept?.topic.toLowerCase().includes(searchQuery.toLowerCase()) ?? false);
    return matchesCategory && matchesQuery;
  });

  // Sort entries
  const sortedEntries = [...filteredEntries].sort((a, b) => {
    if (sortOrder === 'A-Z') {
      return a.title.localeCompare(b.title);
    }
    // Discovery order: discovered first, then title
    if (a.discovered && !b.discovered) return -1;
    if (!a.discovered && b.discovered) return 1;
    return a.title.localeCompare(b.title);
  });

  const selectedEntry = entries.find(e => e.id === selectedEntryId);

  // Stats
  const discoveredCount = entries.filter(e => e.discovered).length;
  const totalCount = entries.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-2xl max-w-5xl w-full h-[90vh] shadow-2xl flex flex-col text-white overflow-hidden">
        {/* Top Title Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                The Historian\'s Archive
                <span className="text-xs font-mono font-normal text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  {discoveredCount} / {totalCount} Recorded
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Official Codex of Persons, Locations, Inscriptions, Relics, and Core Mathematical Lexicon
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs & Search Bar */}
        <div className="px-6 py-3 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          {/* Categories Segmented Bar */}
          <div className="flex items-center gap-1 overflow-x-auto py-1">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => {
                  soundManager.playTileSnap();
                  setSelectedCategory(cat);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  selectedCategory === cat
                    ? 'bg-amber-600 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {cat !== 'All' && getCategoryIcon(cat as ArchiveCategory)}
                {cat}
              </button>
            ))}
          </div>

          {/* Search & Sort Controls */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search Archive..."
                className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 w-44 sm:w-56"
              />
            </div>

            <button
              onClick={() => {
                soundManager.playTileSnap();
                setSortOrder(prev => (prev === 'A-Z' ? 'DISCOVERY' : 'A-Z'));
              }}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-slate-300 hover:text-white text-xs flex items-center gap-1"
              title="Toggle Sort Order"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span className="hidden sm:inline font-mono text-[10px]">{sortOrder}</span>
            </button>
          </div>
        </div>

        {/* Master-Detail Split Pane */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left: Entry List */}
          <div className="w-full sm:w-80 md:w-96 border-r border-slate-800 overflow-y-auto p-3 space-y-1.5 bg-slate-950/40">
            {sortedEntries.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                No entries match your search criteria.
              </div>
            ) : (
              sortedEntries.map(entry => {
                const isSelected = entry.id === selectedEntryId;
                return (
                  <button
                    key={entry.id}
                    onClick={() => {
                      soundManager.playTileSnap();
                      setSelectedEntryId(entry.id);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-400/80 shadow-md'
                        : entry.discovered
                        ? 'bg-slate-800/60 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                        : 'bg-slate-950/60 border-slate-900 opacity-60 hover:opacity-80'
                    }`}
                  >
                    <div className="p-2 rounded-lg bg-slate-800 border border-slate-700 shrink-0 mt-0.5">
                      {entry.discovered ? (
                        getCategoryIcon(entry.category)
                      ) : (
                        <Lock className="w-4 h-4 text-slate-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className={`text-xs font-bold truncate ${
                          entry.discovered ? 'text-slate-100' : 'text-slate-500'
                        }`}>
                          {entry.discovered ? entry.title : 'Undiscovered Inscription'}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 uppercase">
                          {entry.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {entry.discovered ? entry.summary : 'Investigate the Outpost to record this knowledge.'}
                      </p>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Right: Detailed Entry View */}
          <div className="hidden sm:flex flex-1 flex-col overflow-y-auto p-6 bg-slate-900">
            {selectedEntry ? (
              selectedEntry.discovered ? (
                <div className="space-y-6 max-w-2xl">
                  {/* Entry Header */}
                  <div className="pb-4 border-b border-slate-800">
                    <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
                      {getCategoryIcon(selectedEntry.category)}
                      <span>{selectedEntry.category}</span>
                      <span>·</span>
                      <span className="text-slate-400">Archival ID: {selectedEntry.id}</span>
                    </div>
                    <h1 className="text-2xl font-bold text-slate-100">{selectedEntry.title}</h1>
                    <p className="text-xs text-amber-200/80 italic mt-1">{selectedEntry.summary}</p>
                  </div>

                  {/* Lore Narrative Section */}
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Historical Observation</h3>
                    <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 text-xs text-slate-200 leading-relaxed font-serif">
                      {selectedEntry.detailedText}
                    </div>
                  </div>

                  {/* Mathematical Concept Box (if applicable) */}
                  {selectedEntry.mathematicalConcept && (
                    <div className="bg-amber-500/10 border border-amber-500/40 rounded-xl p-4 space-y-3">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        Mathematical Principle: {selectedEntry.mathematicalConcept.topic}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
                          <span className="text-[10px] font-mono text-slate-400 uppercase block">Underlying Rule</span>
                          <span className="text-slate-200 font-medium">{selectedEntry.mathematicalConcept.rule}</span>
                        </div>
                        {selectedEntry.mathematicalConcept.formula && (
                          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
                            <span className="text-[10px] font-mono text-slate-400 uppercase block">Algebraic Model</span>
                            <span className="text-amber-300 font-mono font-bold text-sm">
                              {selectedEntry.mathematicalConcept.formula}
                            </span>
                          </div>
                        )}
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed">
                        {selectedEntry.mathematicalConcept.explanation}
                      </p>

                      <div className="text-[11px] text-slate-400 bg-slate-950/40 p-2 rounded border border-slate-800">
                        <strong>Concrete Example:</strong> {selectedEntry.mathematicalConcept.concreteExample}
                      </div>
                    </div>
                  )}

                  {/* Document 3-Question Investigation (GDD section 9.3) */}
                  {selectedEntry.documentQuestions && (
                    <div className="space-y-2">
                      <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                        <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                        Document Three-Question Inquiry
                      </h3>
                      <div className="space-y-2 text-xs">
                        <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                          <span className="font-semibold text-amber-300 block mb-0.5">1. Is it real?</span>
                          <span className="text-slate-300">{selectedEntry.documentQuestions.isItReal}</span>
                        </div>
                        <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                          <span className="font-semibold text-amber-300 block mb-0.5">2. What does it mean?</span>
                          <span className="text-slate-300">{selectedEntry.documentQuestions.whatDoesItMean}</span>
                        </div>
                        <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                          <span className="font-semibold text-amber-300 block mb-0.5">3. What can it tell us?</span>
                          <span className="text-slate-300">{selectedEntry.documentQuestions.whatCanItTellUs}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Cross-Linked Related Entries */}
                  {selectedEntry.relatedEntryIds.length > 0 && (
                    <div className="pt-2">
                      <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 mb-2 font-mono uppercase">
                        <Link2 className="w-3.5 h-3.5" />
                        Related Knowledge Nodes:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {selectedEntry.relatedEntryIds.map(relId => {
                          const rel = entries.find(e => e.id === relId);
                          if (!rel) return null;
                          return (
                            <button
                              key={rel.id}
                              onClick={() => {
                                soundManager.playTileSnap();
                                setSelectedEntryId(rel.id);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs border flex items-center gap-1.5 transition-colors ${
                                rel.discovered
                                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                                  : 'bg-slate-950 text-slate-500 border-slate-900 cursor-not-allowed'
                              }`}
                            >
                              {getCategoryIcon(rel.category)}
                              {rel.discovered ? rel.title : 'Undiscovered'}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* Undiscovered Placeholder */
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
                  <Lock className="w-12 h-12 text-slate-700 mb-3" />
                  <h3 className="text-base font-bold text-slate-400 mb-1">Knowledge Node Encrypted</h3>
                  <p className="text-xs max-w-sm">
                    This archive entry has not yet been discovered in the Outpost. Speak with scholars, inspect runic gates, or quell wild anomalies to decipher it.
                  </p>
                </div>
              )
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};
