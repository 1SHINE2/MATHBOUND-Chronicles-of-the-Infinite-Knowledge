import React, { useState } from 'react';
import { soundManager } from '../audio/soundManager';
import { X, Sparkles, BookOpen, Layers, CheckCircle2, HelpCircle, ArrowRight } from 'lucide-react';
import { ProtagonistId } from '../types/game';

interface ChalkboardModalProps {
  protagonist: ProtagonistId;
  onOpenDigitalBook: () => void;
  onOpenTwoTableMagic: () => void;
  onClose: () => void;
}

export const ChalkboardModal: React.FC<ChalkboardModalProps> = ({
  protagonist,
  onOpenDigitalBook,
  onOpenTwoTableMagic,
  onClose
}) => {
  const [selectedHypothesis, setSelectedHypothesis] = useState<'GEOMETRIC' | 'ARITHMETIC' | 'HIERARCHY'>('GEOMETRIC');
  const [testMultiplier, setTestMultiplier] = useState<number>(2);

  const isSamantha = protagonist === 'SAMANTHA';
  const leadName = isSamantha ? 'Samantha Yu' : 'Miguel Perez';
  const compName = isSamantha ? 'Miguel Perez' : 'Samantha Yu';
  const leadStyle = isSamantha ? 'Meditative Inquiry ("What does it mean?")' : 'Calculative Logic ("How does it work?")';
  const compStyle = isSamantha ? 'Calculative Logic ("How does it work?")' : 'Meditative Inquiry ("What does it mean?")';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-emerald-500/70 rounded-3xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-scale-in">
        {/* Header with Chalkboard Slate Theme */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-emerald-950 bg-emerald-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-900/60 border border-emerald-500 flex items-center justify-center text-emerald-400 font-bold">
              <span className="text-lg">📐</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
                  SCHOLASTIC STUDY STATION
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-900/80 border border-emerald-700/50 text-[10px] text-emerald-300 font-mono">
                  Book I: Foundations
                </span>
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Courtyard Working Slate & Companion Hypothesis
              </h2>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs for Slate Analysis */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6">
          <button
            onClick={() => {
              soundManager.playTileSnap();
              setSelectedHypothesis('GEOMETRIC');
            }}
            className={`py-3 px-4 font-mono text-xs font-bold border-b-2 flex items-center gap-2 transition-all ${
              selectedHypothesis === 'GEOMETRIC'
                ? 'border-emerald-400 text-emerald-300 bg-emerald-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>🌿</span>
            <span>Geometric Doubling (Ratio ×2)</span>
          </button>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              setSelectedHypothesis('ARITHMETIC');
            }}
            className={`py-3 px-4 font-mono text-xs font-bold border-b-2 flex items-center gap-2 transition-all ${
              selectedHypothesis === 'ARITHMETIC'
                ? 'border-emerald-400 text-emerald-300 bg-emerald-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>⚖️</span>
            <span>Arithmetic vs. Geometric Comparison</span>
          </button>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              setSelectedHypothesis('HIERARCHY');
            }}
            className={`py-3 px-4 font-mono text-xs font-bold border-b-2 flex items-center gap-2 transition-all ${
              selectedHypothesis === 'HIERARCHY'
                ? 'border-emerald-400 text-emerald-300 bg-emerald-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>🏛️</span>
            <span>Canonical Progression Hierarchy</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Dual Character Thought Banner */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-slate-950/70 border border-sky-900/60 rounded-xl p-3.5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-sky-400 font-bold uppercase tracking-wider block mb-1">
                  Lead Scholar: {leadName}
                </span>
                <p className="text-xs text-slate-300 leading-relaxed italic">
                  {isSamantha 
                    ? '"Every number isn\'t just an amount—it\'s an organism growing in space. When the energy doubles from 4 to 8 to 16, the shape of the world itself expands by factors."'
                    : '"Look at the factor relation: 4 × 2 = 8, 8 × 2 = 16, 16 × 2 = 32. It is not addition (+4, +8). The constant ratio r = 2 governs the whole system."'}
                </p>
              </div>
              <div className="mt-2 text-[10px] font-mono text-slate-500">
                Mode: {leadStyle}
              </div>
            </div>

            <div className="bg-slate-950/70 border border-amber-900/60 rounded-xl p-3.5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider block mb-1">
                  Collaborator: {compName}
                </span>
                <p className="text-xs text-slate-300 leading-relaxed italic">
                  {isSamantha
                    ? '"Samantha, if the multiplier is 2, the fifth socket after 32 must evaluate to 32 × 2 = 64. That unlocks the harmonic circuit!"'
                    : '"Miguel, the caretaker said Rule 2 warns us: what we believe may be wrong until tested. Let\'s verify the difference between constant slope and exponential curve."'}
                </p>
              </div>
              <div className="mt-2 text-[10px] font-mono text-slate-500">
                Mode: {compStyle}
              </div>
            </div>
          </div>

          {/* Interactive Blackboard Slate */}
          {selectedHypothesis === 'GEOMETRIC' && (
            <div className="bg-slate-950 border border-emerald-800/60 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs text-emerald-400 font-bold uppercase">
                  Chalk Inscription: The Sequence Sockets of Foundations
                </span>
                <span className="font-mono text-xs text-slate-400">
                  Formula: aₙ = a₁ · r^(n-1)
                </span>
              </div>

              {/* Sequence Visualizer */}
              <div className="grid grid-cols-5 gap-2 text-center font-mono">
                {[
                  { n: 1, val: 4, label: 'Socket I' },
                  { n: 2, val: 8, label: 'Socket II' },
                  { n: 3, val: 16, label: 'Socket III' },
                  { n: 4, val: 32, label: 'Socket IV' },
                  { n: 5, val: 64, label: 'Key Socket (Solved)' }
                ].map(step => (
                  <div
                    key={step.n}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all ${
                      step.n === 5
                        ? 'bg-emerald-950/60 border-emerald-400 shadow-lg shadow-emerald-500/20'
                        : 'bg-slate-900 border-slate-800'
                    }`}
                  >
                    <span className="text-[10px] text-slate-400 mb-1">{step.label}</span>
                    <span className="text-xl font-black text-white">{step.val}</span>
                    <span className="text-[9px] text-emerald-400 mt-1">2^{(step.n + 1)}</span>
                  </div>
                ))}
              </div>

              <div className="text-xs text-slate-300 bg-emerald-950/30 border border-emerald-900/50 rounded-xl p-3 leading-relaxed">
                <strong className="text-emerald-300">Observation:</strong> The ratio between consecutive terms is constant: <code className="text-emerald-200">8/4 = 2</code>, <code className="text-emerald-200">16/8 = 2</code>, <code className="text-emerald-200">32/16 = 2</code>. Therefore, the next term must be <code className="text-emerald-200">32 × 2 = 64</code>.
              </div>
            </div>
          )}

          {selectedHypothesis === 'ARITHMETIC' && (
            <div className="bg-slate-950 border border-emerald-800/60 rounded-2xl p-5 space-y-4">
              <span className="font-mono text-xs text-emerald-400 font-bold uppercase block">
                Rule 2 Verification: Arithmetic vs. Geometric Growth
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                  <div className="text-amber-400 font-bold">Arithmetic Sequence (Addition)</div>
                  <div className="text-slate-300">Common Difference: d = +4</div>
                  <div className="text-slate-400">4 → 8 → 12 → 16 → 20</div>
                  <p className="text-[11px] text-red-400/90 font-sans mt-2">
                    Does NOT match the gate sockets! The 3rd socket is 16, not 12.
                  </p>
                </div>

                <div className="p-4 bg-emerald-950/40 border border-emerald-500/60 rounded-xl space-y-2">
                  <div className="text-emerald-300 font-bold">Geometric Sequence (Multiplication)</div>
                  <div className="text-slate-300">Common Ratio: r = ×2</div>
                  <div className="text-emerald-200 font-bold">4 → 8 → 16 → 32 → 64</div>
                  <p className="text-[11px] text-emerald-300 font-sans mt-2">
                    Exact harmonic match! Confirms the resonance frequency of the Gate.
                  </p>
                </div>
              </div>
            </div>
          )}

          {selectedHypothesis === 'HIERARCHY' && (
            <div className="bg-slate-950 border border-emerald-800/60 rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-bold uppercase">
                <Layers className="w-4 h-4" />
                <span>Story Bible Progression Hierarchy (Canon Version 0.09)</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                Across all four Books of MATHBOUND, educational challenges and boss encounters strictly observe this architectural hierarchy:
              </p>

              <div className="space-y-2 font-mono text-xs">
                <div className="flex items-center gap-3 p-3 bg-red-950/40 border border-red-800/50 rounded-xl">
                  <span className="px-2 py-0.5 rounded bg-red-900 text-red-200 font-bold text-[10px]">BOOK</span>
                  <ArrowRight className="w-4 h-4 text-slate-500" />
                  <span className="font-bold text-red-300">BOOK BOSS</span>
                  <span className="text-[11px] text-slate-400 font-sans ml-auto">Supreme master of the Book's domain</span>
                </div>

                <div className="flex items-center gap-3 p-3 bg-amber-950/40 border border-amber-800/50 rounded-xl">
                  <span className="px-2 py-0.5 rounded bg-amber-900 text-amber-200 font-bold text-[10px]">VOLUME</span>
                  <ArrowRight className="w-4 h-4 text-slate-500" />
                  <span className="font-bold text-amber-300">SUB-BOSS</span>
                  <span className="text-[11px] text-slate-400 font-sans ml-auto">Guardian of major regional branch</span>
                </div>

                <div className="flex items-center gap-3 p-3 bg-emerald-950/40 border border-emerald-800/50 rounded-xl">
                  <span className="px-2 py-0.5 rounded bg-emerald-900 text-emerald-200 font-bold text-[10px]">CHAPTER</span>
                  <ArrowRight className="w-4 h-4 text-slate-500" />
                  <span className="font-bold text-emerald-300">ELITE ENCOUNTER</span>
                  <span className="text-[11px] text-slate-400 font-sans ml-auto">e.g. The Sequence Warden in the Sanctum</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundManager.playTileSnap();
                onOpenDigitalBook();
              }}
              className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Consult Digital Book</span>
            </button>
            <button
              onClick={() => {
                soundManager.playTileSnap();
                onOpenTwoTableMagic();
              }}
              className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Two-Table System</span>
            </button>
          </div>

          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="py-2 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shadow-emerald-600/20"
          >
            Return to Outpost
          </button>
        </div>
      </div>
    </div>
  );
};
