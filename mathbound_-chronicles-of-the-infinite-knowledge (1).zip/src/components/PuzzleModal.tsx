import React, { useState } from 'react';
import { PatternPuzzleState, PuzzleRune } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { Check, RotateCcw, HelpCircle, Sparkles, BookOpen, ChevronRight, X } from 'lucide-react';

interface PuzzleModalProps {
  puzzle: PatternPuzzleState;
  onSolveSuccess: (explanation: string) => void;
  onClose: () => void;
}

export const PuzzleModal: React.FC<PuzzleModalProps> = ({
  puzzle,
  onSolveSuccess,
  onClose
}) => {
  const [selectedSlot, setSelectedSlot] = useState<number>(puzzle.missingIndices[0]);
  const [playerSlots, setPlayerSlots] = useState<{ [index: number]: PuzzleRune | null }>({ ...puzzle.playerAnswers });
  const [feedback, setFeedback] = useState<{ type: 'idle' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: 'Select a candidate rune below to place it into the open socket of the sequence.'
  });
  const [currentHintLevel, setCurrentHintLevel] = useState<number>(puzzle.hintsUsed);
  const [showAbstractModal, setShowAbstractModal] = useState<boolean>(false);

  // Handle placing a rune into currently selected slot
  const handleSelectRune = (rune: PuzzleRune) => {
    soundManager.playTileSnap();
    setPlayerSlots(prev => ({
      ...prev,
      [selectedSlot]: rune
    }));
    setFeedback({
      type: 'idle',
      message: `Placed ${rune.label}. Click 'Activate Mechanism' to test the resonance.`
    });
  };

  // Clear slot
  const handleClearSlot = (slotIdx: number) => {
    soundManager.playTileSnap();
    setPlayerSlots(prev => ({
      ...prev,
      [slotIdx]: null
    }));
  };

  // Reset all placed runes
  const handleReset = () => {
    soundManager.playTileSnap();
    setPlayerSlots({ ...puzzle.playerAnswers });
    setFeedback({
      type: 'idle',
      message: 'Sockets reset. Observe the geometric pattern and select a replacement rune.'
    });
  };

  // Request next tier in the 3-step hint ladder
  const handleRequestHint = () => {
    soundManager.playTileSnap();
    if (currentHintLevel < puzzle.hintLadder.length) {
      const nextLevel = currentHintLevel + 1;
      setCurrentHintLevel(nextLevel);
    }
  };

  // Confirm and validate sequence
  const handleVerify = () => {
    const placed = playerSlots[4];
    if (!placed) {
      soundManager.playError();
      setFeedback({
        type: 'error',
        message: 'The fourth socket remains unoccupied. You must choose a harmonic rune to complete the circuit.'
      });
      return;
    }

    if (placed.value === 64) {
      soundManager.playPuzzleSuccess();
      setFeedback({
        type: 'success',
        message: 'Resonant lock unsealed! The geometric ratio (×2) is satisfied. The gate mechanisms begin to turn!'
      });
      setTimeout(() => {
        onSolveSuccess(puzzle.ruleExplanation);
      }, 1600);
    } else {
      soundManager.playError();
      setFeedback({
        type: 'error',
        message: `Runic frequency mismatch (${placed.value})! The sequence collapsed. Test whether each socket adds or multiplies the previous energy.`
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-amber-500/60 rounded-2xl max-w-2xl w-full p-6 shadow-2xl flex flex-col gap-5 text-white max-h-[92vh] overflow-y-auto">
        {/* Header Bar */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              Pattern Recognition & Geometric Sequences
            </div>
            <h2 className="text-xl font-bold text-slate-100 mt-0.5">{puzzle.title}</h2>
          </div>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Narrative Context Description */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-300 leading-relaxed">
          <p>{puzzle.description}</p>
        </div>

        {/* 1. Representational Layer: The Stone Sequence Diagram */}
        <div className="flex flex-col gap-2">
          <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Sequence of Stone Sockets</span>
            <span className="text-[11px] font-mono text-amber-400/80">CRA: Visual Representation</span>
          </div>

          <div className="bg-slate-950/80 border border-slate-700 rounded-xl p-4 flex flex-wrap items-center justify-center gap-3 md:gap-4">
            {puzzle.sequence.map((item, idx) => {
              const isMissing = puzzle.missingIndices.includes(idx);
              const placedRune = playerSlots[idx];

              if (!isMissing && item) {
                return (
                  <React.Fragment key={idx}>
                    {/* Fixed Rune Stone in Gate */}
                    <div className="flex flex-col items-center">
                      <div className="w-16 h-20 rounded-lg bg-slate-800 border-2 border-slate-600 shadow-md flex flex-col items-center justify-between p-2">
                        <span className="text-lg font-serif text-sky-300">{item.symbol}</span>
                        <div className="text-center">
                          <span className="font-mono text-base font-bold text-amber-300">{item.value}</span>
                          <span className="block text-[9px] text-slate-400">Node {idx + 1}</span>
                        </div>
                      </div>
                    </div>

                    {/* Multiplier Bridge Indicator */}
                    {idx < puzzle.sequence.length - 1 && (
                      <div className="flex flex-col items-center text-slate-400">
                        <span className="text-[10px] font-mono font-bold text-amber-400">×2</span>
                        <ChevronRight className="w-4 h-4 text-slate-500" />
                      </div>
                    )}
                  </React.Fragment>
                );
              }

              // Missing Socket Slot (Interactive)
              return (
                <React.Fragment key={idx}>
                  <div className="flex flex-col items-center">
                    <button
                      onClick={() => setSelectedSlot(idx)}
                      className={`w-16 h-20 rounded-lg border-2 border-dashed flex flex-col items-center justify-between p-2 transition-all ${
                        placedRune
                          ? 'bg-amber-500/10 border-amber-400 text-amber-200 shadow-lg shadow-amber-500/20'
                          : 'bg-slate-900/60 border-slate-500 hover:border-amber-400/70 text-slate-500'
                      }`}
                    >
                      {placedRune ? (
                        <>
                          <span className="text-lg font-serif text-amber-300">{placedRune.symbol}</span>
                          <div className="text-center">
                            <span className="font-mono text-base font-bold text-amber-300">{placedRune.value}</span>
                            <span className="block text-[9px] text-amber-400/80">Placed</span>
                          </div>
                        </>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400">
                          <span className="text-xl font-bold">?</span>
                          <span className="text-[9px] font-mono mt-1">Empty</span>
                        </div>
                      )}
                    </button>
                    {placedRune && (
                      <button
                        onClick={() => handleClearSlot(idx)}
                        className="text-[10px] text-red-400 hover:underline mt-1"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* 2. Concrete Layer: Available Rune Tiles for Placement */}
        <div className="flex flex-col gap-2">
          <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Scholar\'s Rune Inlay Choices</span>
            <span className="text-[11px] font-mono text-slate-400">Click to place into socket</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {puzzle.availableRunes.map(rune => {
              const isSelected = playerSlots[selectedSlot]?.id === rune.id;
              return (
                <button
                  key={rune.id}
                  onClick={() => handleSelectRune(rune)}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 shadow-md ring-2 ring-amber-400/30'
                      : 'bg-slate-800/80 border-slate-700 hover:bg-slate-750 hover:border-slate-500'
                  }`}
                >
                  <span className="text-xl font-serif text-sky-300">{rune.symbol}</span>
                  <span className="text-sm font-bold font-mono text-slate-100">{rune.value}</span>
                  <span className="text-[10px] text-slate-400 leading-tight">{rune.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Graduated Hint Ladder Section */}
        {currentHintLevel > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3.5 space-y-2 text-xs">
            <div className="font-semibold text-amber-300 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              Scholar\'s Guidance (Level {currentHintLevel} of 3):
            </div>
            {puzzle.hintLadder.slice(0, currentHintLevel).map((hintText, hIdx) => (
              <div key={hIdx} className="text-slate-200 pl-3 border-l-2 border-amber-500/40 py-0.5">
                {hintText}
              </div>
            ))}
          </div>
        )}

        {/* Status / Feedback Banner */}
        <div className={`p-3 rounded-xl text-xs flex items-center gap-2.5 ${
          feedback.type === 'success'
            ? 'bg-emerald-500/20 border border-emerald-500/50 text-emerald-200'
            : feedback.type === 'error'
            ? 'bg-red-500/20 border border-red-500/50 text-red-200'
            : 'bg-slate-800/60 border border-slate-700 text-slate-300'
        }`}>
          <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
          <span>{feedback.message}</span>
        </div>

        {/* Action Controls Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Sockets
            </button>
            <button
              onClick={handleRequestHint}
              disabled={currentHintLevel >= puzzle.hintLadder.length}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                currentHintLevel < puzzle.hintLadder.length
                  ? 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30'
                  : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              {currentHintLevel < puzzle.hintLadder.length
                ? `Need a Hint? (${currentHintLevel + 1}/3)`
                : 'All Hints Revealed'}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleVerify}
              className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs tracking-wider uppercase shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all active:scale-95"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              Activate Mechanism
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
