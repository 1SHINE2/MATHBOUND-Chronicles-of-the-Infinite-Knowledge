import React, { useState } from 'react';
import { InventoryItem } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { Briefcase, X, Sparkles, Heart, Edit3, Key, Gem, FlaskRound } from 'lucide-react';

interface InventoryModalProps {
  items: InventoryItem[];
  playerHp: number;
  playerMaxHp: number;
  onUseItem: (itemId: string) => void;
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  items,
  playerHp,
  playerMaxHp,
  onUseItem,
  onClose
}) => {
  const [selectedItemId, setSelectedItemId] = useState<string>(items[0]?.id || '');

  const selectedItem = items.find(i => i.id === selectedItemId);

  const getItemIcon = (icon: string) => {
    switch (icon) {
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-amber-400" />;
      case 'FlaskRound': return <FlaskRound className="w-5 h-5 text-emerald-400" />;
      case 'Edit3': return <Edit3 className="w-5 h-5 text-sky-400" />;
      case 'Key': return <Key className="w-5 h-5 text-yellow-400" />;
      case 'Gem': return <Gem className="w-5 h-5 text-purple-400" />;
      default: return <Sparkles className="w-5 h-5 text-slate-300" />;
    }
  };

  const handleUse = (item: InventoryItem) => {
    if (item.type === 'CONSUMABLE') {
      soundManager.playPuzzleSuccess();
      onUseItem(item.id);
    } else {
      soundManager.playTileSnap();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-2xl max-w-xl w-full p-5 shadow-2xl flex flex-col gap-4 text-white">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Briefcase className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">Scholar\'s Satchel & Relics</h2>
              <p className="text-[11px] text-slate-400">Tools, Consumables, and Mathematical Keys</p>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Inventory Content Grid & Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Items List */}
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {items.map(item => {
              const isSelected = item.id === selectedItemId;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    soundManager.playTileSnap();
                    setSelectedItemId(item.id);
                  }}
                  className={`w-full text-left p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-400 shadow-md'
                      : 'bg-slate-800/60 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-700">
                      {getItemIcon(item.icon)}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-200">{item.name}</div>
                      <div className="text-[10px] font-mono text-slate-400 uppercase">{item.type}</div>
                    </div>
                  </div>
                  <span className="font-mono text-xs text-amber-300 font-bold px-2 py-0.5 bg-slate-900 rounded">
                    ×{item.quantity}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Item Inspector Pane */}
          {selectedItem && (
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-700">
                    {getItemIcon(selectedItem.icon)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-amber-300">{selectedItem.name}</h3>
                    <span className="text-[10px] font-mono text-slate-400 uppercase">
                      Category: {selectedItem.type}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-serif">
                  {selectedItem.description}
                </p>

                {selectedItem.effect === 'HEAL' && (
                  <div className="text-xs text-emerald-400 flex items-center gap-1.5 bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/20">
                    <Heart className="w-3.5 h-3.5 fill-current" />
                    Restores +{selectedItem.effectValue} HP on consumption
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800 mt-4">
                {selectedItem.type === 'CONSUMABLE' ? (
                  <button
                    onClick={() => handleUse(selectedItem)}
                    disabled={playerHp >= playerMaxHp}
                    className={`w-full py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all ${
                      playerHp < playerMaxHp
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md active:scale-95'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    {playerHp >= playerMaxHp ? 'HP Already Full' : `Consume Elixir (+${selectedItem.effectValue} HP)`}
                  </button>
                ) : (
                  <div className="text-center text-[11px] font-mono text-slate-500 py-1">
                    Equipped & Ready in Quickslot
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
