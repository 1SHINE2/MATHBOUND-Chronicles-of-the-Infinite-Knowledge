import React, { useState } from 'react';
import { ProtagonistId } from '../types/game';
import { PROTAGONIST_PROFILES } from '../game/archiveData';
import { soundManager } from '../audio/soundManager';
import { User, Sparkles, Brain, Compass, ArrowRight, Shield, BookOpen } from 'lucide-react';

interface CharacterSelectModalProps {
  onSelectCharacter: (id: ProtagonistId) => void;
  onBack: () => void;
}

export const CharacterSelectModal: React.FC<CharacterSelectModalProps> = ({
  onSelectCharacter,
  onBack
}) => {
  const [selectedId, setSelectedId] = useState<ProtagonistId>('SAMANTHA');

  const profile = PROTAGONIST_PROFILES[selectedId];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-amber-500/60 rounded-3xl max-w-3xl w-full p-6 shadow-2xl flex flex-col gap-5 text-white max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="text-center pb-2 border-b border-slate-800">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-300 text-xs font-mono mb-1">
            <BookOpen className="w-3.5 h-3.5" />
            Version 0.07 Canon Foundation
          </div>
          <h2 className="text-2xl font-black text-slate-100 tracking-tight">Choose Your Lead Explorer</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-lg mx-auto">
            Samantha Yu and Miguel Perez are childhood friends from an ordinary school who entered MATHBOUND together through Book I. Neither is a chosen one; both explore driven by pure curiosity.
          </p>
        </div>

        {/* Character Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Samantha Yu */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              setSelectedId('SAMANTHA');
            }}
            className={`p-4 rounded-2xl border-2 text-left transition-all flex flex-col justify-between ${
              selectedId === 'SAMANTHA'
                ? 'bg-sky-950/40 border-sky-400 shadow-xl shadow-sky-500/20 ring-2 ring-sky-400/40'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 opacity-80 hover:opacity-100'
            }`}
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-sky-600/30 border border-sky-400 flex items-center justify-center text-sky-300">
                  <User className="w-6 h-6" />
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono text-sky-400 font-bold block">Age 10 · 4\'11"</span>
                  <span className="text-[10px] font-mono text-slate-400">Meditative Lens</span>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-sky-200">Samantha Yu</h3>
                <div className="inline-flex items-center gap-1 text-[11px] font-mono text-sky-400 italic">
                  <Brain className="w-3 h-3" />
                  "What does it mean?"
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed font-serif">
                Thoughtful, observant, and sensitive to symbolic harmony. Samantha focuses on why phenomena occur, the deeper philosophical questions behind mathematical patterns, and understanding reality through reflection.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-800/80 mt-3 text-[11px] font-mono text-sky-300 flex items-center justify-between">
              <span>Thinking: Meditative</span>
              <span className="text-slate-400">Book I Explorer</span>
            </div>
          </button>

          {/* Miguel Perez */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              setSelectedId('MIGUEL');
            }}
            className={`p-4 rounded-2xl border-2 text-left transition-all flex flex-col justify-between ${
              selectedId === 'MIGUEL'
                ? 'bg-amber-950/40 border-amber-400 shadow-xl shadow-amber-500/20 ring-2 ring-amber-400/40'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 opacity-80 hover:opacity-100'
            }`}
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-amber-600/30 border border-amber-400 flex items-center justify-center text-amber-300">
                  <User className="w-6 h-6" />
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono text-amber-400 font-bold block">Age 11 · 5\'4"</span>
                  <span className="text-[10px] font-mono text-slate-400">Calculative Lens</span>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-amber-200">Miguel Perez</h3>
                <div className="inline-flex items-center gap-1 text-[11px] font-mono text-amber-400 italic">
                  <Compass className="w-3 h-3" />
                  "How does it work?"
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed font-serif">
                Analytical, logical, and structured. Miguel excels at breaking down problems into measurable components, testing numerical hypotheses, calculating vector trajectories, and structural accuracy.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-800/80 mt-3 text-[11px] font-mono text-amber-300 flex items-center justify-between">
              <span>Thinking: Calculative</span>
              <span className="text-slate-400">Book I Explorer</span>
            </div>
          </button>
        </div>

        {/* Selected Profile Detailed Quote & Philosophy Box */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-bold font-mono text-[11px]">
            <Sparkles className="w-3.5 h-3.5" />
            Canonical Starting Principle (Version 0.07):
          </div>
          <p className="text-slate-300 italic">
            "Their limitation is not intelligence; it is perspective. Their knowledge is limited to what they currently know. As they encounter MATHBOUND, their understanding repeatedly expands. There is always more to discover."
          </p>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onBack();
            }}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            Back to Title
          </button>

          <button
            onClick={() => {
              soundManager.playPuzzleSuccess();
              onSelectCharacter(selectedId);
            }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
          >
            <span>Begin Journey as {profile.name}</span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      </div>
    </div>
  );
};
