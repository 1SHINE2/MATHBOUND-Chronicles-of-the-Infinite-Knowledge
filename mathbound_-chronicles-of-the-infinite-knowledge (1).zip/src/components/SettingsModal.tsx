import React from 'react';
import { GameSettings } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { Settings, Volume2, Music, Eye, Shield, Vibrate, X, Keyboard } from 'lucide-react';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose
}) => {
  const handleSfxChange = (val: number) => {
    const updated = { ...settings, sfxVolume: val };
    onUpdateSettings(updated);
    soundManager.setVolumes(updated.sfxVolume, updated.musicVolume);
    soundManager.playTileSnap();
  };

  const handleMusicChange = (val: number) => {
    const updated = { ...settings, musicVolume: val };
    onUpdateSettings(updated);
    soundManager.setVolumes(updated.sfxVolume, updated.musicVolume);
  };

  const handleToggleScreenShake = () => {
    soundManager.playTileSnap();
    onUpdateSettings({ ...settings, screenShake: !settings.screenShake });
  };

  const handleToggleRelaxedMode = () => {
    soundManager.playTileSnap();
    onUpdateSettings({ ...settings, relaxedMode: !settings.relaxedMode });
  };

  const handleToggleHighContrast = () => {
    soundManager.playTileSnap();
    onUpdateSettings({ ...settings, highContrast: !settings.highContrast });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-2xl max-w-xl w-full p-5 shadow-2xl flex flex-col gap-4 text-white max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">Settings & Accessibility</h2>
              <p className="text-[11px] text-slate-400">Audio, Visual Comfort, and Key Bindings</p>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Volume Controls */}
        <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
            <Volume2 className="w-3.5 h-3.5 text-amber-400" />
            Synthesizer Audio Controls
          </h3>

          {/* SFX Volume */}
          <div className="flex items-center justify-between gap-4 text-xs">
            <span className="text-slate-300 w-32 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-slate-400" />
              Sound FX ({settings.sfxVolume}%)
            </span>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.sfxVolume}
              onChange={e => handleSfxChange(Number(e.target.value))}
              className="flex-1 accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
          </div>

          {/* Music Volume */}
          <div className="flex items-center justify-between gap-4 text-xs">
            <span className="text-slate-300 w-32 flex items-center gap-1.5">
              <Music className="w-3.5 h-3.5 text-slate-400" />
              Music / Arpeggio ({settings.musicVolume}%)
            </span>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.musicVolume}
              onChange={e => handleMusicChange(Number(e.target.value))}
              className="flex-1 accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
          </div>
        </div>

        {/* Accessibility & Gameplay Options */}
        <div className="space-y-2.5 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            Accessibility & Learning Balance
          </h3>

          {/* Relaxed Learning Mode */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <div>
              <div className="font-semibold text-amber-300">Relaxed Learning Mode</div>
              <div className="text-[11px] text-slate-400">
                Extends enemy telegraph warning windows and increases player damage mitigation.
              </div>
            </div>
            <button
              onClick={handleToggleRelaxedMode}
              className={`px-3 py-1 rounded text-xs font-mono font-bold transition-colors ${
                settings.relaxedMode
                  ? 'bg-amber-600 text-slate-950'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {settings.relaxedMode ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>

          {/* Screen Shake */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <div>
              <div className="font-semibold text-slate-200">Screen Shake Feedback</div>
              <div className="text-[11px] text-slate-400">
                Toggles dynamic canvas camera vibration during critical strikes and gate tremors.
              </div>
            </div>
            <button
              onClick={handleToggleScreenShake}
              className={`px-3 py-1 rounded text-xs font-mono font-bold transition-colors ${
                settings.screenShake
                  ? 'bg-amber-600 text-slate-950'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {settings.screenShake ? 'ON' : 'OFF'}
            </button>
          </div>

          {/* High Contrast */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <div>
              <div className="font-semibold text-slate-200">High Contrast HUD Frames</div>
              <div className="text-[11px] text-slate-400">
                Enhances border borders and text luminosity for maximum legibility.
              </div>
            </div>
            <button
              onClick={handleToggleHighContrast}
              className={`px-3 py-1 rounded text-xs font-mono font-bold transition-colors ${
                settings.highContrast
                  ? 'bg-amber-600 text-slate-950'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {settings.highContrast ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        {/* Keyboard Bindings Table */}
        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
            <Keyboard className="w-3.5 h-3.5 text-amber-400" />
            Handheld Control Bindings
          </h3>

          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-300">
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Movement:</span>
              <span className="text-amber-300">WASD / Arrow Keys</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Interact / Confirm:</span>
              <span className="text-amber-300">E / Enter</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Arcane Pulse (Attack):</span>
              <span className="text-amber-300">J / Left Click</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Wave Burst (Ability):</span>
              <span className="text-amber-300">K / Right Click</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Vector Step (Dodge):</span>
              <span className="text-amber-300">Shift / Space</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Historian\'s Archive:</span>
              <span className="text-amber-300">Tab</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Satchel / Inventory:</span>
              <span className="text-amber-300">I</span>
            </div>
            <div className="flex justify-between p-1.5 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400">Quest Journal:</span>
              <span className="text-amber-300">Q</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
