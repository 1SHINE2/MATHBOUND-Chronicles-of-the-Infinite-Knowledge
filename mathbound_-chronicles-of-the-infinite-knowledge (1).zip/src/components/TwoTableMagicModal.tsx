import React, { useState } from 'react';
import { TwoTableSpell } from '../types/game';
import { CANONICAL_SPELLS } from '../game/archiveData';
import { soundManager } from '../audio/soundManager';
import { Sparkles, Brain, Code2, ArrowRight, X, Shield, Activity, RefreshCw } from 'lucide-react';

interface TwoTableMagicModalProps {
  onClose: () => void;
}

export const TwoTableMagicModal: React.FC<TwoTableMagicModalProps> = ({ onClose }) => {
  const [selectedSpellId, setSelectedSpellId] = useState<string>(CANONICAL_SPELLS[0].id);

  const selectedSpell = CANONICAL_SPELLS.find(s => s.id === selectedSpellId) || CANONICAL_SPELLS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-amber-500/70 rounded-3xl max-w-3xl w-full p-6 shadow-2xl flex flex-col gap-4 text-white max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 block font-bold">
                Canonical Magic Architecture (Version 0.07)
              </span>
              <h2 className="text-xl font-bold text-slate-100">The Two-Table Command System</h2>
            </div>
          </div>
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Core Canonical Principle Banner */}
        <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed font-serif">
          <p>
            <strong>"A vision does not determine reality. Reality determines what a vision can become."</strong> In MATHBOUND, humans possess no internal mana batteries; tools like the Resonant Focus act as interfaces. Caster intention is formulated in <em>ENVISION</em>, then transmitted through formal mathematical <em>COMMAND</em>.
          </p>
        </div>

        {/* Spell Tabs */}
        <div className="flex gap-2">
          {CANONICAL_SPELLS.map(spell => (
            <button
              key={spell.id}
              onClick={() => {
                soundManager.playTileSnap();
                setSelectedSpellId(spell.id);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                selectedSpellId === spell.id
                  ? 'bg-amber-600 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <span>{spell.name}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/20">
                {spell.element}
              </span>
            </button>
          ))}
        </div>

        {/* The Two Paired Tables Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Table 1: ENVISION (Left Side) */}
          <div className="bg-sky-950/20 border-2 border-sky-800/50 rounded-2xl p-4 flex flex-col justify-between space-y-3">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-sky-900/50">
                <span className="text-xs font-mono font-bold text-sky-400 uppercase flex items-center gap-1.5">
                  <Brain className="w-4 h-4" />
                  Table 1: ENVISION (Mental Intention)
                </span>
                <span className="text-[10px] font-mono text-slate-400">Left Side</span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-[10px] font-mono text-sky-300/80 uppercase block">Mental Concept</span>
                  <p className="text-slate-200 font-serif">{selectedSpell.envision.intent}</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-sky-300/80 uppercase block">Desired Outcome</span>
                  <p className="text-slate-200">{selectedSpell.envision.targetEffect}</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-sky-300/80 uppercase block">Conceptual Geometry</span>
                  <p className="text-sky-300 font-mono text-[11px]">{selectedSpell.envision.conceptualShape}</p>
                </div>
              </div>
            </div>

            <div className="text-[10px] font-mono text-slate-400 italic pt-2 border-t border-sky-950">
              Formulated in the scholar's mind via intuitive/meditative cognition.
            </div>
          </div>

          {/* Table 2: COMMAND (Right Side) */}
          <div className="bg-amber-950/20 border-2 border-amber-800/50 rounded-2xl p-4 flex flex-col justify-between space-y-3">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-amber-900/50">
                <span className="text-xs font-mono font-bold text-amber-400 uppercase flex items-center gap-1.5">
                  <Code2 className="w-4 h-4" />
                  Table 2: COMMAND (Formal Instruction)
                </span>
                <span className="text-[10px] font-mono text-slate-400">Right Side</span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-[10px] font-mono text-amber-300/80 uppercase block">Formal Command Instruction</span>
                  <p className="text-amber-200 font-mono text-[11px] font-bold">{selectedSpell.command.instruction}</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-amber-300/80 uppercase block">Mathematical Formula</span>
                  <p className="text-amber-300 font-mono text-[11px]">{selectedSpell.command.mathematicalFormula}</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-amber-300/80 uppercase block">Interface Medium</span>
                  <p className="text-slate-200">{selectedSpell.command.channelMedium}</p>
                </div>
              </div>
            </div>

            <div className="text-[10px] font-mono text-slate-400 italic pt-2 border-t border-amber-950">
              Transmitted through wand channels into ambient reality.
            </div>
          </div>
        </div>

        {/* Complete Flow Diagram: ENVISION -> COMMAND -> INTERPRETATION -> RESPONSE */}
        <div className="bg-slate-950/90 p-4 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-[11px] font-mono font-bold text-amber-400 uppercase flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5" />
            Execution Cycle:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase block font-semibold">
                3. Magical Interpretation
              </span>
              <p className="text-slate-300 font-serif mt-0.5">{selectedSpell.interpretation}</p>
            </div>
            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase block font-semibold">
                4. Physical Response
              </span>
              <p className="text-slate-300 font-serif mt-0.5">{selectedSpell.response}</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider"
          >
            Return to Exploration
          </button>
        </div>
      </div>
    </div>
  );
};
