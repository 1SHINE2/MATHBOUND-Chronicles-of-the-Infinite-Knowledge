import React from 'react';
import { 
  Heart, 
  Zap, 
  BookOpen, 
  Briefcase, 
  ScrollText, 
  Pause, 
  Compass, 
  Sparkles,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { Quest } from '../types/game';
import { soundManager } from '../audio/soundManager';

interface GameHUDProps {
  hp: number;
  maxHp: number;
  energy: number;
  maxEnergy: number;
  quest: Quest;
  interactPrompt: string | null;
  unreadArchiveCount: number;
  protagonist?: import('../types/game').ProtagonistId;
  onOpenDigitalBook: (layer?: import('../types/game').DigitalBookLayer) => void;
  onOpenTwoTableMagic: () => void;
  onOpenInventory: () => void;
  onOpenQuestJournal: () => void;
  onOpenPause: () => void;
  onInteract: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  hp,
  maxHp,
  energy,
  maxEnergy,
  quest,
  interactPrompt,
  unreadArchiveCount,
  protagonist = 'SAMANTHA',
  onOpenDigitalBook,
  onOpenTwoTableMagic,
  onOpenInventory,
  onOpenQuestJournal,
  onOpenPause,
  onInteract
}) => {
  const hpPercent = Math.max(0, Math.min(100, (hp / maxHp) * 100));
  const energyPercent = Math.max(0, Math.min(100, (energy / maxEnergy) * 100));

  const isSamantha = protagonist === 'SAMANTHA';
  const protagonistName = isSamantha ? 'Samantha Yu (10)' : 'Miguel Perez (11)';
  const thinkingStyle = isSamantha ? 'Meditative' : 'Calculative';

  // Find active objective description
  const activeObjective = quest.objectives.find(o => o.stage === quest.stage)?.description 
    || 'Explore the Outpost and uncover its mysteries.';

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 select-none font-sans">
      {/* Top Header Bar: Status & Quest Status */}
      <div className="w-full flex items-start justify-between gap-3">
        {/* Player Status Card */}
        <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 shadow-xl flex flex-col gap-2 min-w-[210px]">
          {/* Location & Title */}
          <div className="flex items-center justify-between text-xs text-slate-300 pb-1 border-b border-slate-800">
            <span className="flex items-center gap-1.5 font-semibold text-amber-300">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              The Academy Outpost
            </span>
            <span className="font-mono text-[10px] text-sky-400 bg-sky-950/60 px-1.5 py-0.5 rounded border border-sky-800/60">
              {protagonistName}
            </span>
          </div>

          {/* Health Bar */}
          <div>
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-0.5">
              <span className="flex items-center gap-1 text-red-400 font-semibold">
                <Heart className="w-3 h-3 fill-current text-red-400" />
                HP
              </span>
              <span>{hp} / {maxHp}</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
              <div 
                className="h-full bg-gradient-to-r from-red-600 via-red-500 to-amber-500 transition-all duration-200"
                style={{ width: `${hpPercent}%` }}
              />
            </div>
          </div>

          {/* Resonance / Interface Charge Bar */}
          <div>
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 mb-0.5">
              <span className="flex items-center gap-1 text-sky-400 font-semibold">
                <Zap className="w-3 h-3 fill-current text-sky-400" />
                INTERFACE CHARGE
              </span>
              <span>{Math.round(energy)} / {maxEnergy}</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-150"
                style={{ width: `${energyPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Quest Tracker (Compact Top Center) */}
        <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-amber-500/30 rounded-xl px-4 py-2.5 shadow-xl max-w-sm hidden sm:flex flex-col gap-1">
          <div className="flex items-center justify-between text-xs text-amber-300 font-semibold">
            <span className="flex items-center gap-1.5">
              <ScrollText className="w-3.5 h-3.5 text-amber-400" />
              {quest.title}
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-amber-500/10 rounded text-amber-400">
              {quest.stage === 'COMPLETED' ? 'Completed' : 'Active'}
            </span>
          </div>
          <p className="text-xs text-slate-200 leading-snug line-clamp-2">
            {activeObjective}
          </p>
        </div>

        {/* Quick Menu Action Buttons */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-1.5 shadow-xl">
          {/* Digital Book (Chronicle · Knowledge · Archive) */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenDigitalBook('CHRONICLE');
            }}
            title="Digital Book: Chronicle · Knowledge · Archive [Tab]"
            className="relative p-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-amber-300 transition-colors flex items-center justify-center"
          >
            <BookOpen className="w-4 h-4" />
            {unreadArchiveCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-slate-950 text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {unreadArchiveCount}
              </span>
            )}
          </button>

          {/* Two-Table Command System */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenTwoTableMagic();
            }}
            title="Two-Table Command Magic [ENVISION / COMMAND]"
            className="p-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-sky-300 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Inventory */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenInventory();
            }}
            title="Satchel / Inventory [I]"
            className="p-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-amber-300 transition-colors"
          >
            <Briefcase className="w-4 h-4" />
          </button>

          {/* Quest Log */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenQuestJournal();
            }}
            title="Quest Journal [Q]"
            className="p-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-amber-300 transition-colors"
          >
            <ScrollText className="w-4 h-4" />
          </button>

          {/* Pause */}
          <button
            onClick={() => {
              soundManager.playTileSnap();
              onOpenPause();
            }}
            title="Pause Menu [Esc]"
            className="p-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white transition-colors"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Center Contextual Interaction Banner (when player is near NPC or Gate) */}
      {interactPrompt && (
        <div className="pointer-events-auto self-center mb-6 animate-bounce">
          <button
            onClick={onInteract}
            className="flex items-center gap-2.5 px-5 py-2.5 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 text-slate-950 rounded-xl font-bold text-xs tracking-wider uppercase shadow-2xl border border-amber-300 hover:scale-105 active:scale-95 transition-all"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            {interactPrompt}
          </button>
        </div>
      )}

      {/* Bottom Footer: Hotkeys & Tool Indicator */}
      <div className="w-full flex items-end justify-between gap-3">
        {/* Selected Tool / Weapon */}
        <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md border border-slate-700 rounded-xl p-2.5 shadow-xl flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-mono text-slate-400 uppercase">Equipped Tool</div>
            <div className="text-xs font-bold text-slate-100">Resonant Focus</div>
          </div>
        </div>

        {/* Desktop Controls Legend */}
        <div className="hidden lg:flex items-center gap-4 bg-slate-900/80 backdrop-blur-sm border border-slate-800 rounded-lg px-4 py-1.5 text-[11px] font-mono text-slate-400">
          <span><kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200">WASD</kbd> Move</span>
          <span><kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200">J</kbd> Arcane Pulse</span>
          <span><kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200">K</kbd> Wave Burst</span>
          <span><kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200">Shift</kbd> Vector Step</span>
          <span><kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-slate-200">E</kbd> Interact</span>
        </div>

        {/* Mobile On-Screen Action Touch Pad */}
        <div className="flex md:hidden pointer-events-auto items-center gap-2">
          <button
            onClick={() => {
              window.dispatchEvent(new KeyboardEvent('keydown', { key: 'j' }));
            }}
            className="w-12 h-12 rounded-full bg-red-600/90 border border-red-400 text-white font-bold text-xs shadow-lg flex items-center justify-center active:bg-red-500"
          >
            Pulse
          </button>
          <button
            onClick={() => {
              window.dispatchEvent(new KeyboardEvent('keydown', { key: 'k' }));
            }}
            className="w-12 h-12 rounded-full bg-sky-600/90 border border-sky-400 text-white font-bold text-xs shadow-lg flex items-center justify-center active:bg-sky-500"
          >
            Wave
          </button>
          <button
            onClick={() => {
              window.dispatchEvent(new KeyboardEvent('keydown', { key: ' ' }));
            }}
            className="w-12 h-12 rounded-full bg-amber-600/90 border border-amber-400 text-white font-bold text-xs shadow-lg flex items-center justify-center active:bg-amber-500"
          >
            Step
          </button>
        </div>
      </div>
    </div>
  );
};
