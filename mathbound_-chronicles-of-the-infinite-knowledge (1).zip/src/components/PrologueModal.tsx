import React, { useState } from 'react';
import { ProtagonistId } from '../types/game';
import { PROTAGONIST_PROFILES } from '../game/archiveData';
import { soundManager } from '../audio/soundManager';
import { Sparkles, ChevronRight, BookOpen, Volume2, Shield } from 'lucide-react';

interface PrologueModalProps {
  protagonist: ProtagonistId;
  onCompletePrologue: () => void;
}

export const PrologueModal: React.FC<PrologueModalProps> = ({
  protagonist,
  onCompletePrologue
}) => {
  const [slide, setSlide] = useState(0);

  const profile = PROTAGONIST_PROFILES[protagonist];
  const companion = protagonist === 'SAMANTHA' ? PROTAGONIST_PROFILES.MIGUEL : PROTAGONIST_PROFILES.SAMANTHA;

  const slides = [
    {
      title: 'The Ordinary World & The School Library',
      subtitle: 'Ordinary School · Wednesday Afternoon',
      text: `In a quiet corner of the school library, ${profile.name} and ${companion.name} were browsing the reference stacks. They were not chosen ones, and no prophecy marked their names. They were simply two childhood friends whose natural curiosity noticed something strange: an ornate leather volume resting untouched on a high wooden shelf.`,
      highlight: 'Title stamped in gold leaf: "Chronicles of the Infinite Knowledge — Book I: Foundations"'
    },
    {
      title: 'The Ancient Engraving',
      subtitle: 'Geometric Circuit of Light',
      text: `Opening Book I revealed no ordinary printing. Deep crystalline grooves formed an intricate geometric engraving pulsing with a faint, chilling breath of frost. As ${profile.name} and ${companion.name} reached out together to inspect the mathematical symmetry, the lines snapped into alignment, releasing a brilliant surge of mysterious light.`,
      highlight: 'Reality dissolved. The ordinary library vanished into a cascade of numbers and crystalline air.'
    },
    {
      title: 'The Unknown Voice & The Five Rules',
      subtitle: 'Arrival in the Magical Academy Outpost',
      text: `When the light softened, you stood on the mossy stone courtyard of the Academy Outpost. Before you could take in the towering granite gates, an unknown voice resonated across the stones—clear, gentle, and undeniable:`,
      rules: [
        '1. "What you see, you can understand. What you cannot see, you must question."',
        '2. "What you believe may be true. It may also be wrong."',
        '3. "Question what you know. Question what you don\'t know."',
        '4. "The unknown is not something to fear. It is something to uncover."',
        '5. "Open your minds, have fun... and let\'s find out."'
      ]
    }
  ];

  const currentSlide = slides[slide];

  const handleNext = () => {
    soundManager.playTileSnap();
    if (slide < slides.length - 1) {
      setSlide(slide + 1);
    } else {
      soundManager.playArchiveUnlock();
      onCompletePrologue();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 select-none font-sans">
      <div className="bg-slate-900 border-2 border-amber-500/70 rounded-3xl max-w-2xl w-full p-6 shadow-2xl flex flex-col justify-between text-white min-h-[440px] animate-fade-in">
        {/* Header */}
        <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <div>
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider block">
                {currentSlide.subtitle}
              </span>
              <h2 className="text-lg font-bold text-slate-100">{currentSlide.title}</h2>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {slide + 1} / {slides.length}
          </span>
        </div>

        {/* Content Body */}
        <div className="my-auto py-4 space-y-4">
          <p className="text-sm text-slate-200 leading-relaxed font-serif">
            {currentSlide.text}
          </p>

          {currentSlide.highlight && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-200 font-mono italic">
              {currentSlide.highlight}
            </div>
          )}

          {currentSlide.rules && (
            <div className="space-y-2 bg-slate-950/80 p-4 rounded-xl border border-slate-800 text-xs">
              {currentSlide.rules.map((rule, idx) => (
                <div key={idx} className="font-serif italic text-amber-200/90 pl-2 border-l-2 border-amber-500/40">
                  {rule}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <div className="text-[11px] font-mono text-slate-400">
            Playing as <strong className="text-amber-300">{profile.name}</strong> ({profile.thinkingStyle} Lens)
          </div>

          <button
            onClick={handleNext}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
          >
            <span>{slide < slides.length - 1 ? 'Continue' : 'Enter the Academy Outpost'}</span>
            <ChevronRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      </div>
    </div>
  );
};
